package com.ras.autopicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.random.Random

class PickerService : AccessibilityService() {

    companion object { var instance: PickerService? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val EMERALD = Color.parseColor("#2ECC71")
    private val RED = Color.parseColor("#E53935")

    // Posiciones por defecto (fracción de pantalla) medidas en tus capturas
    private val cardDefaults = arrayOf(
        floatArrayOf(0.274f, 0.26f),
        floatArrayOf(0.725f, 0.26f),
        floatArrayOf(0.500f, 0.60f),
        floatArrayOf(0.500f, 0.43f)
    )
    private val nextDefault = floatArrayOf(0.739f, 0.752f)
    private val sellDefault = floatArrayOf(0.261f, 0.752f)

    // Posiciones por defecto del modo PACKS (fracción de pantalla, medidas en las capturas EN/ES)
    private val BLUE = Color.parseColor("#42A5F5")
    private val skipDefault = floatArrayOf(0.500f, 0.720f)
    private fun pNextDefault() = if (L.lang == "en") floatArrayOf(0.619f, 0.720f) else floatArrayOf(0.621f, 0.720f)
    private fun pSellDefault() = when {
        pmode == "sm" -> floatArrayOf(0.500f, 0.721f)
        L.lang == "en" -> floatArrayOf(0.257f, 0.721f)
        else -> floatArrayOf(0.244f, 0.721f)
    }
    private fun pSellKey() = if (pmode == "sm") "ps_sm" else "ps_sa"

    // Tiempos (ms): no dependen del idioma del juego
    private val CARD_TO_BUTTON = 650L
    private val SELL_TO_NEXT = 550L
    private val AFTER_NEXT = 900L
    private val STUCK_MS = 3500L
    private val CONFIRM_GAP = 450L      // espera entre la lectura y su confirmación
    private val MAX_CONFIRM = 6         // máximo de lecturas hasta que se estabilicen las cartas

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prefs by lazy { getSharedPreferences("ras", MODE_PRIVATE) }

    private val cardViews = ArrayList<TextView>()
    private val cardParams = ArrayList<WindowManager.LayoutParams>()
    private lateinit var nextView: TextView
    private lateinit var sellView: TextView
    private lateinit var skipV: TextView      // modo PACKS: puntero de Skip/Saltar
    private lateinit var psellV: TextView     // modo PACKS: puntero de vender (todo o repetidas)
    private lateinit var pnextV: TextView     // modo PACKS: puntero de Siguiente pack
    private lateinit var saBtn: TextView
    private lateinit var smBtn: TextView
    private val extraParams = ArrayList<WindowManager.LayoutParams>()
    private lateinit var panel: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var eyeBtn: TextView
    private lateinit var offBtn: TextView
    private lateinit var moneyBtn: TextView
    private lateinit var addBtn: TextView
    private lateinit var remBtn: TextView
    private lateinit var info: LinearLayout     // contador de picks + cronómetro
    private lateinit var pausedLbl: TextView
    // Estadísticas: una fila para PICKS y otra para PACKS (cada una con su ícono, contador y tiempo)
    private lateinit var kRow: LinearLayout
    private lateinit var kCountTv: TextView
    private lateinit var kTimeTv: TextView
    private lateinit var pRow: LinearLayout
    private lateinit var pCountTv: TextView
    private lateinit var pTimeTv: TextView
    private var wakeLock: PowerManager.WakeLock? = null
    private var fgOn = false
    private var tick = 0

    var running = false
        private set
    /** Contadores y cronómetros SEPARADOS: 0 = picks, 1 = packs. */
    private val cnt = IntArray(2)
    private val acc = LongArray(2)
    private fun mi() = if (mode == "packs") 1 else 0
    val packs: Int get() = cnt[mi()]
    var overlayShown = false
        private set
    var mode = ""              // "", "picks" o "packs"
        private set
    private var pmode = ""     // "", "sa" o "sm" (solo en modo packs)
    private var lastSkipTap = 0L
    private var lastSellTap = 0L
    private var lastNextTap = 0L
    private var hidden = false
    private var lastAction = 0L
    private var sizePx = 0
    private var targets: List<Search.Target> = emptyList()

    private var sellOn: Boolean
        get() = prefs.getBoolean("sell", false)
        set(v) { prefs.edit().putBoolean("sell", v).apply() }

    private class CardRead(val ovr: Int?, val isNew: Boolean, val rect: Rect)

    /**
     * Unidad de tamaño del PANEL: depende solo del ancho real de la pantalla en píxeles,
     * nunca del DPI. Así el panel mide lo mismo con cualquier DPI (auto o manual).
     */
    private fun unit(): Float = minOf(screenW(), screenH()) / 400f
    private fun dp(v: Int) = (v * unit()).toInt()
    private fun sp(v: Float) = v * unit()   // texto en píxeles (no cambia con DPI ni con la fuente del sistema)

    // ---------- DPI: tamaño de punteros + reubicación automática ----------
    private var curSys = 0
    /** DPI (densidad) que Android usa ahora mismo para dibujar la pantalla. NO es el ppi físico. */
    private fun sysDpi(): Int = (if (curSys > 0) curSys else resources.configuration.densityDpi).coerceIn(100, 800)
    /** DPI que usa la app: el que pusiste a mano o, si no hay, el detectado. */
    private fun effectiveDpi(): Int { val m = prefs.getInt("dpi", 0); return if (m in 100..800) m else sysDpi() }
    private fun baseDpi(): Int { val b = prefs.getInt("base_dpi", 0); return if (b in 100..800) b else effectiveDpi() }
    private fun layoutDpi(): Int { val l = prefs.getInt("layout_dpi", 0); return if (l in 100..800) l else baseDpi() }
    private fun autoAdj() = prefs.getBoolean("autoadj", true)
    private fun zoomFrac(v: Float, k: Float) = (0.5f + (v - 0.5f) * k).coerceIn(0.04f, 0.96f)
    private val posKeys = listOf("c0", "c1", "c2", "c3", "n", "s", "k", "ps_sa", "ps_sm", "pn")

    /**
     * Factor de los PUNTEROS: crecen/achican solo un poco con el DPI (0,85x a 1,25x),
     * tomando como 1,0 el DPI que tenía el celular la primera vez que se usó la app.
     */
    private fun pointerScale(): Float =
        Math.pow(effectiveDpi().toDouble() / baseDpi(), 0.35).toFloat().coerceIn(0.85f, 1.25f)
    private fun pointerPx() = (dp(40) * pointerScale()).toInt()

    /**
     * Si el DPI cambió, mueve los punteros guardados: la interfaz del juego se agranda o achica
     * alrededor del centro de la pantalla, así que cada puntero se aleja o acerca del centro
     * en la misma proporción (nuevo DPI / DPI anterior).
     */
    private fun syncLayoutDpi() {
        val eff = effectiveDpi()
        if (!prefs.contains("base_dpi")) { prefs.edit().putInt("base_dpi", eff).putInt("layout_dpi", eff).apply(); return }
        val old = layoutDpi()
        if (old == eff) return
        val e = prefs.edit()
        if (autoAdj()) {
            val k = (eff.toFloat() / old).coerceIn(0.4f, 2.5f)
            for (key in posKeys) if (prefs.contains("x_$key") && prefs.contains("y_$key")) {
                e.putFloat("x_$key", zoomFrac(prefs.getFloat("x_$key", 0.5f), k))
                e.putFloat("y_$key", zoomFrac(prefs.getFloat("y_$key", 0.5f), k))
            }
        }
        e.putInt("layout_dpi", eff).apply()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        val d = newConfig.densityDpi
        if (d > 0 && d != curSys) { curSys = d; handler.postDelayed({ applyDpi() }, 400) }
    }

    private fun now() = SystemClock.uptimeMillis()
    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun ring(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(maxOf(2, dp(3)), color)
    }

    private fun oval(fill: Int, stroke: Int?) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill); if (stroke != null) setStroke(dp(2), stroke)
    }

    override fun onServiceConnected() {
        instance = this
        L.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        curSys = resources.configuration.densityDpi
        syncLayoutDpi()
        sizePx = pointerPx()
        Search.createChannel(this)
        val n = prefs.getInt("cards", 3).coerceIn(1, 4)
        for (i in 0 until n) addCardPointer()
        nextView = makePointer("N", EMERALD, "n", nextDefault)
        sellView = makePointer("$", RED, "s", sellDefault)
        skipV = makePointer("S", BLUE, "k", skipDefault)
        psellV = makePointer("$", RED, "ps_sa", pSellDefault()) { pSellKey() }
        pnextV = makePointer("N", EMERALD, "pn", pNextDefault())
        buildPanel()
        applyVisibility()
        updatePanel()
        targets = Search.load(this)
        startFg()
    }

    // ---------- punteros ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(v: View, p: WindowManager.LayoutParams, onDrop: () -> Unit) {
        var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = p.x - e.rawX; dy = p.y - e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (e.rawX + dx).toInt(); p.y = (e.rawY + dy).toInt(); moved = true
                    wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> if (moved) onDrop() else v.performClick()
            }
            true
        }
    }

    private fun makePointer(label: String, color: Int, key: String, def: FloatArray, dropKey: (() -> String)? = null): TextView {
        val p = overlayParams(sizePx, sizePx, 0, 0)
        val v = TextView(this).apply {
            text = label; setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(11f) * pointerScale()); gravity = Gravity.CENTER
            setTextColor(IVORY); background = ring(color)
            tag = key
        }
        makeDraggable(v, p) { savePos(dropKey?.invoke() ?: key, v) }
        wm.addView(v, p)
        place(v, p, key, def)
        v.visibility = View.GONE   // applyVisibility() decide según el modo
        if (key == "n" || key == "s") extraParams.add(p)
        return v
    }

    private fun addCardPointer() {
        val i = cardViews.size
        val v = makePointer((i + 1).toString(), GOLD, "c$i", cardDefaults[i])
        cardViews.add(v)
        cardParams.add(v.layoutParams as WindowManager.LayoutParams)
    }

    private fun place(v: View, p: WindowManager.LayoutParams, key: String, def: FloatArray) {
        val kd = if (autoAdj()) layoutDpi().toFloat() / baseDpi() else 1f
        val fx = if (prefs.contains("x_$key")) prefs.getFloat("x_$key", def[0]) else zoomFrac(def[0], kd)
        val fy = if (prefs.contains("y_$key")) prefs.getFloat("y_$key", def[1]) else zoomFrac(def[1], kd)
        p.x = (fx * screenW()).toInt() - sizePx / 2
        p.y = (fy * screenH()).toInt() - sizePx / 2
        wm.updateViewLayout(v, p)
    }

    private fun centerOf(v: View): IntArray {
        val p = v.layoutParams as WindowManager.LayoutParams
        if (v.visibility == View.GONE || v.width == 0) return intArrayOf(p.x + sizePx / 2, p.y + sizePx / 2)
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        return intArrayOf(loc[0] + sizePx / 2, loc[1] + sizePx / 2)
    }

    private fun savePos(key: String, v: View) {
        val c = centerOf(v)
        prefs.edit().putFloat("x_$key", c[0].toFloat() / screenW()).putFloat("y_$key", c[1].toFloat() / screenH()).apply()
    }

    private fun pickPointers(): List<TextView> = cardViews + listOf(nextView, sellView)
    private fun packPointers(): List<TextView> = listOf(skipV, psellV, pnextV)
    private fun allPointers(): List<TextView> = pickPointers() + packPointers()

    private fun placeSell() = place(psellV, psellV.layoutParams as WindowManager.LayoutParams, pSellKey(), pSellDefault())

    private fun setPackMode(m: String) {
        if (running) return
        pmode = m
        psellV.text = if (m == "sm") "D" else "$"
        placeSell()
        applyVisibility()
        updatePanel()
        toast(L.t(if (m == "sm") "sm_on" else "sa_on"))
    }

    fun resetPositions() {
        val e = prefs.edit()
        for (k in listOf("c0", "c1", "c2", "c3", "n", "s", "k", "ps_sa", "ps_sm", "pn")) e.remove("x_$k").remove("y_$k")
        e.apply()
        for ((i, v) in cardViews.withIndex()) place(v, cardParams[i], "c$i", cardDefaults[i])
        place(nextView, nextView.layoutParams as WindowManager.LayoutParams, "n", nextDefault)
        place(sellView, sellView.layoutParams as WindowManager.LayoutParams, "s", sellDefault)
        place(skipV, skipV.layoutParams as WindowManager.LayoutParams, "k", skipDefault)
        placeSell()
        place(pnextV, pnextV.layoutParams as WindowManager.LayoutParams, "pn", pNextDefault())
    }

    /** Aplica el DPI elegido: agranda/achica un poco los punteros; el panel NO cambia de tamaño. */
    fun applyDpi() {
        if (!::wm.isInitialized) return
        // No se detiene el auto-pick ni el cronómetro: solo se reubica y se redimensiona
        syncLayoutDpi()
        sizePx = pointerPx()
        for (v in allPointers()) {
            val pp = v.layoutParams as WindowManager.LayoutParams
            pp.width = sizePx; pp.height = sizePx
            v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(11f) * pointerScale())
            wm.updateViewLayout(v, pp)
        }
        for ((i, v) in cardViews.withIndex()) place(v, cardParams[i], "c$i", cardDefaults[i])
        place(nextView, nextView.layoutParams as WindowManager.LayoutParams, "n", nextDefault)
        place(sellView, sellView.layoutParams as WindowManager.LayoutParams, "s", sellDefault)
        place(skipV, skipV.layoutParams as WindowManager.LayoutParams, "k", skipDefault)
        placeSell()
        place(pnextV, pnextV.layoutParams as WindowManager.LayoutParams, "pn", pNextDefault())
        try { wm.removeView(panel) } catch (e: Exception) { }
        buildPanel()
        applyVisibility()
        updatePanel()
    }

    private fun setTouchable(t: Boolean) {
        val base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        for (v in allPointers()) {
            val p = v.layoutParams as WindowManager.LayoutParams
            p.flags = if (t) base else base or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(v, p)
        }
    }

    private fun applyVisibility() {
        val picksOn = overlayShown && mode == "picks"
        val packsOn = overlayShown && mode == "packs" && pmode.isNotEmpty()
        for (v in pickPointers()) v.visibility = when {
            !picksOn -> View.GONE
            hidden -> View.INVISIBLE
            else -> View.VISIBLE
        }
        for (v in packPointers()) v.visibility = when {
            !packsOn -> View.GONE
            hidden -> View.INVISIBLE
            else -> View.VISIBLE
        }
        panel.visibility = if (overlayShown) View.VISIBLE else View.GONE
    }

    // ---------- panel ----------
    private fun roundBtn(label: String, size: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(16f)); gravity = Gravity.CENTER; setTextColor(IVORY)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { leftMargin = dp(6) }
    }

    private fun buildPanel() {
        val p = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(8), dp(90))
        // Mantiene la pantalla encendida mientras el panel está visible (evita pausas por ahorro de energía)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6000000")); cornerRadius = dp(28).toFloat(); setStroke(dp(2), GOLD)
            }
        }
        playBtn = roundBtn("▶", 44) { if (running) stop() else start() }.apply {
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(20f))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        eyeBtn = roundBtn("👁", 38) { togglePointers() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        offBtn = roundBtn("⏻", 38) { closeOverlay() }.apply { background = oval(Color.TRANSPARENT, RED) }
        moneyBtn = roundBtn("💲", 38) {
            sellOn = !sellOn
            toast(L.t(if (sellOn) "sell_on" else "sell_off"))
            updatePanel()
        }
        addBtn = roundBtn("➕", 38) { addCard() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        remBtn = roundBtn("➖", 38) { removeCard() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        saBtn = roundBtn("SA", 38) { setPackMode("sa") }.apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        smBtn = roundBtn("SM", 38) { setPackMode("sm") }.apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        // Estadísticas: [ícono del pick] cantidad  [reloj] tiempo
        pausedLbl = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(10f)); setTextColor(GOLD) }
        fun statsRow(iconRes: Int, iw: Int, ih: Int): Triple<LinearLayout, TextView, TextView> {
            val count = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTextColor(IVORY); setPadding(dp(5), 0, dp(10), 0); setSingleLine(true) }
            val time = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTextColor(IVORY); setPadding(dp(5), 0, 0, 0); typeface = android.graphics.Typeface.MONOSPACE; setSingleLine(true); minWidth = dp(46) }
            val icon = ImageView(this).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(iw), dp(ih))
            }
            val clock = ImageView(this).apply {
                setImageResource(R.drawable.ic_clock)
                layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(icon); addView(count); addView(clock); addView(time)
            }
            return Triple(row, count, time)
        }
        val k = statsRow(R.drawable.ic_pack, 18, 25)          // PICKS: ícono original
        kRow = k.first; kCountTv = k.second; kTimeTv = k.third
        val q = statsRow(R.drawable.ic_pack_packs, 22, 32)    // PACKS: ícono de la carta dorada
        pRow = q.first; pCountTv = q.second; pTimeTv = q.third
        info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, 0, 0)
            addView(pausedLbl); addView(kRow); addView(pRow)
        }
        for (v in listOf(playBtn, eyeBtn, offBtn, moneyBtn, addBtn, remBtn, saBtn, smBtn, info)) panel.addView(v)
        makeDraggable(panel, p) {}
        wm.addView(panel, p)
    }

    private fun updatePanel() {
        if (!::panel.isInitialized) return
        playBtn.text = if (running) "■" else "▶"
        playBtn.background = oval(if (running) RED else EMERALD, null)
        val extras = if (running || mode != "picks") View.GONE else View.VISIBLE
        for (v in listOf(moneyBtn, addBtn, remBtn)) v.visibility = extras
        val pk = if (running || mode != "packs") View.GONE else View.VISIBLE
        for (v in listOf(saBtn, smBtn)) v.visibility = pk
        saBtn.background = if (pmode == "sa") oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        smBtn.background = if (pmode == "sm") oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        saBtn.setTextColor(if (pmode == "sa") Color.BLACK else IVORY)
        smBtn.setTextColor(if (pmode == "sm") Color.BLACK else IVORY)
        info.visibility = View.VISIBLE
        moneyBtn.background = if (sellOn) oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        moneyBtn.alpha = if (sellOn) 1f else 0.5f
        eyeBtn.alpha = if (hidden) 0.45f else 1f
        updateInfo()
    }

    private fun elapsedMs(i: Int): Long = acc[i] + if (running && mi() == i) now() - runStart else 0L

    private fun fmtTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun updateInfo() {
        if (!::pTimeTv.isInitialized) return
        // Solo se muestra la fila del modo activo; no depende de si los punteros están ocultos o no
        kRow.visibility = if (mode == "packs") View.GONE else View.VISIBLE
        pRow.visibility = if (mode == "packs") View.VISIBLE else View.GONE
        kCountTv.text = cnt[0].toString(); kTimeTv.text = fmtTime(elapsedMs(0))
        pCountTv.text = cnt[1].toString(); pTimeTv.text = fmtTime(elapsedMs(1))
        pausedLbl.text = L.t("p_paused")
        pausedLbl.visibility = if (running) View.GONE else View.VISIBLE
    }

    // ---------- anti-freno: servicio en primer plano + wake lock ----------
    private fun startFg() {
        if (fgOn) return
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("ras_run", "RAS Auto-Picker", NotificationManager.IMPORTANCE_LOW)
            )
            val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, "ras_run")
                .setSmallIcon(android.R.drawable.star_big_on)
                .setContentTitle("RAS Auto-Picker")
                .setContentText(L.t("notif_running"))
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(77, n)
            fgOn = true
        } catch (e: Throwable) { }
    }

    private fun stopFg() {
        if (!fgOn) return
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Throwable) { }
        fgOn = false
    }

    private fun acquireWake() {
        try {
            if (wakeLock == null) {
                wakeLock = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ras:autopick")
                    .apply { setReferenceCounted(false) }
            }
            wakeLock?.acquire(120_000L)   // se renueva desde el ticker mientras corre
        } catch (e: Throwable) { }
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Throwable) { }
    }

    fun refreshTexts() { L.load(this); updatePanel() }
    fun reloadTargets() { targets = Search.load(this) }

    private fun addCard() {
        if (cardViews.size >= 4) { toast(L.t("max_ptr")); return }
        addCardPointer()
        prefs.edit().putInt("cards", cardViews.size).apply()
    }

    private fun removeCard() {
        if (cardViews.size <= 1) { toast(L.t("min_ptr")); return }
        val v = cardViews.removeAt(cardViews.size - 1)
        cardParams.removeAt(cardParams.size - 1)
        wm.removeView(v)
        prefs.edit().putInt("cards", cardViews.size).apply()
    }

    fun togglePointers() {
        hidden = !hidden
        applyVisibility()
        updatePanel()
    }

    /** Muestra el panel en modo "picks" o "packs". */
    fun showOverlay(m: String) {
        stop()
        mode = m
        pmode = ""
        hidden = false
        overlayShown = true
        applyVisibility()
        updatePanel()
        startFg()
    }

    /** Cierra panel y app sin quitar el permiso de Accesibilidad. */
    fun closeOverlay() {
        stop()
        stopFg()
        overlayShown = false
        mode = ""
        pmode = ""
        applyVisibility()
        updatePanel()
        MainActivity.current?.finishAndRemoveTask()
    }

    // ---------- ciclo ----------
    // Estado anti-traba y estadísticas
    private var gen = 0                 // cambia en cada start/stop: descarta callbacks viejos
    private var busy = false            // hay una captura/lectura en curso
    private var lastProgress = 0L       // última vez que el ciclo avanzó
    private var lastShot = 0L           // Android limita las capturas (~3 por segundo)
    private var runStart = 0L
    private var confirmSig: List<Int>? = null   // firma de la última lectura (OVR + NEW de cada carta)
    private var confirmTries = 0

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                updateInfo()
                // Watchdog: si el ciclo no avanzó en 4 s (captura o lectura colgada), lo relanza
                if (now() - lastProgress > 4000) restartLoop()
                // Mantiene despierto el CPU y el servicio en primer plano mientras corre
                if (++tick % 30 == 0) { acquireWake(); startFg() }
            } catch (e: Throwable) { }
            handler.postDelayed(this, 1000)
        }
    }

    private fun start() {
        if (mode == "packs" && pmode.isEmpty()) { toast(L.t("need_mode")); return }
        running = true
        gen++
        busy = false
        confirmSig = null; confirmTries = 0
        lastAction = now(); lastProgress = now()
        runStart = now()
        tick = 0
        startFg(); acquireWake()
        setTouchable(false)
        updatePanel()
        handler.post { step(gen) }
        handler.postDelayed(ticker, 1000)
    }

    private fun stop() {
        if (running) acc[mi()] += now() - runStart
        running = false
        gen++
        busy = false
        releaseWake()
        handler.removeCallbacksAndMessages(null)
        if (::panel.isInitialized) {
            setTouchable(true)
            for (v in cardViews) v.background = ring(GOLD)
            updatePanel()
        }
    }

    private fun restartLoop() {
        gen++
        busy = false
        confirmSig = null; confirmTries = 0
        lastProgress = now()
        val g = gen
        handler.postDelayed({ step(g) }, 150)
    }

    private fun next(ms: Long) {
        if (!running) return
        busy = false
        lastProgress = now()
        val g = gen
        handler.postDelayed({ step(g) }, ms)
    }

    private fun later(ms: Long, action: () -> Unit) {
        val g = gen
        handler.postDelayed({
            if (running && g == gen) {
                // Si algo falla, no dejamos caer el servicio: se relanza el ciclo
                try { action() } catch (e: Throwable) { restartLoop() }
            }
        }, ms)
    }

    private fun step(g: Int) {
        if (!running || g != gen || busy) return
        // Respeta el intervalo mínimo entre capturas (algunos Samsung fallan si es menor)
        val wait = 360 - (now() - lastShot)
        if (wait > 0) { handler.postDelayed({ step(g) }, wait); return }
        busy = true
        lastShot = now()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    if (g != gen) { try { r.hardwareBuffer.close() } catch (e: Exception) {}; return }
                    var bmp: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Throwable) {
                    } finally {
                        try { r.hardwareBuffer.close() } catch (e: Exception) {}
                    }
                    val b = bmp
                    if (b == null) { next(400); return }
                    try {
                        recognizer.process(InputImage.fromBitmap(b, 0))
                            .addOnSuccessListener { t ->
                                if (g != gen) { b.recycle(); return@addOnSuccessListener }
                                try { if (mode == "packs") analyzePacks(t) else analyze(b, t) } catch (e: Throwable) { next(400) }
                                b.recycle()
                            }
                            .addOnFailureListener { b.recycle(); if (g == gen) next(400) }
                    } catch (e: Throwable) {
                        b.recycle(); next(400)
                    }
                }
                override fun onFailure(errorCode: Int) { if (g == gen) next(450) }
            })
        } catch (e: Throwable) {
            next(500)
        }
    }

    /** Cierra el Bonus tocando OK/ACEPTAR donde esté. Devuelve true si tocó. */
    private fun handleBonus(lines: List<Text.Line>, els: List<Text.Element>): Boolean {
        if (lines.none { val n = Search.norm(it.text); n == "BONUS" || n == "BONO" }) return false
        val okWords = setOf("OK", "ACEPTAR")
        val box = lines.firstOrNull { Search.norm(it.text) in okWords }?.boundingBox
            ?: els.firstOrNull { Search.norm(it.text) in okWords }?.boundingBox
            ?: return false
        tap(box.exactCenterX(), box.exactCenterY())
        lastAction = now()
        next(900)
        return true
    }

    /** Caja de la primera línea (o palabra) del OCR que cumple la condición. */
    private fun boxOf(lines: List<Text.Line>, els: List<Text.Element>, match: (String) -> Boolean): Rect? {
        lines.firstOrNull { it.boundingBox != null && match(Search.norm(it.text)) }?.boundingBox?.let { return it }
        return els.firstOrNull { it.boundingBox != null && match(Search.norm(it.text)) }?.boundingBox
    }

    /** Toca el texto del botón si se lo ve en pantalla (no depende del DPI); si no, usa el puntero. */
    private fun tapSmart(box: Rect?, fallback: View) {
        if (box != null && autoAdj()) tap(box.exactCenterX(), box.exactCenterY()) else tapView(fallback)
    }

    private fun hasAny(lines: List<Text.Line>, els: List<Text.Element>, keys: List<String>): Boolean =
        lines.any { l -> val n = Search.norm(l.text); keys.any { n.contains(it) } } ||
        els.any { e -> val n = Search.norm(e.text); keys.any { n.contains(it) } }

    /**
     * Modo PACKS. Pantallas (EN / ES):
     *  1) animación: SKIP / SALTAR  -> 2 toques en el puntero Skip
     *  2) resultados: SELL ALL, SELL DUPLICATES, SAVE ALL / VENDER TODO, VENDER DUPLICADOS, GUARDAR TODO
     *     -> toca el puntero de vender (SA = todo, SM = repetidas)
     *  3) NEXT PACK / SIGUIENTE PACK -> toca el puntero de siguiente pack
     * Además cierra el Bonus igual que el auto-picker.
     */
    private fun analyzePacks(t: Text) {
        if (!running) return
        val lines = t.textBlocks.flatMap { it.lines }
        val els = lines.flatMap { it.elements }
        if (handleBonus(lines, els)) return
        val t0 = now()

        when {
            hasAny(lines, els, listOf("SKIP", "SALTAR")) -> {
                if (t0 - lastSkipTap < 1300) { next(350); return }
                lastSkipTap = t0
                val bSkip = boxOf(lines, els) { it.contains("SKIP") || it.contains("SALTAR") }
                tapSmart(bSkip, skipV)
                later(320) { tapSmart(bSkip, skipV); lastAction = now() }
                lastAction = now()
                next(1300)
            }
            hasAny(lines, els, listOf("SELL", "VENDER", "SAVE", "GUARDAR")) -> {
                if (t0 - lastSellTap < 1200) { next(350); return }
                lastSellTap = t0
                val bSell = boxOf(lines, els) { n ->
                    if (pmode == "sm") n.contains("DUPLIC")
                    else (n.contains("SELL") || n.contains("VENDER")) && (n.contains("ALL") || n.contains("TODO")) && !n.contains("DUPLIC")
                }
                tapSmart(bSell, psellV)
                lastAction = now()
                next(900)
            }
            hasAny(lines, els, listOf("NEXT", "SIGUIENTE")) -> {
                if (t0 - lastNextTap < 1500) { next(350); return }
                lastNextTap = t0
                tapSmart(boxOf(lines, els) { it.contains("NEXT") || it.contains("SIGUIENTE") }, pnextV)
                cnt[mi()]++
                updateInfo()
                lastAction = now()
                next(1100)
            }
            else -> next(300)
        }
    }

    private fun analyze(bmp: Bitmap, t: Text) {
        if (!running) return
        val lines = t.textBlocks.flatMap { it.lines }
        val els = lines.flatMap { it.elements }

        // 1) Bonus: tocar OK donde esté
        if (handleBonus(lines, els)) return

        // 2) Pantalla de cartas
        val reads = cardViews.indices.map { readCard(it, bmp, els) }
        if (reads.isNotEmpty() && reads.all { it.ovr != null }) {
            // Confirmación: solo elige cuando DOS lecturas seguidas (separadas ~0,45 s) coinciden
            // en el OVR y en el cartel NEW de TODAS las cartas. Así las animaciones de entrada
            // terminan antes de decidir y no se elige con una lectura a medias.
            val sig = reads.map { (it.ovr ?: 0) * 2 + if (it.isNew) 1 else 0 }
            if (sig != confirmSig && confirmTries < MAX_CONFIRM) {
                confirmSig = sig
                confirmTries++
                next(CONFIRM_GAP); return
            }
            confirmSig = null; confirmTries = 0
            var chosen = -1
            var hit: Search.Target? = null
            val pending = targets.filter { !it.found }
            loop@ for (i in reads.indices) {
                val r = reads[i]
                val texts = lines.filter { l ->
                    val b = l.boundingBox
                    b != null && r.rect.contains(b.centerX(), b.centerY())
                }.map { it.text }
                for (tg in pending) {
                    if (tg.ovr != null && tg.ovr != r.ovr) continue
                    if (texts.any { Search.nameMatches(tg.name, it) }) { chosen = i; hit = tg; break@loop }
                }
            }
            if (chosen < 0) chosen = choose(reads)
            flash(chosen)
            tapView(cardViews[chosen])
            lastAction = now()

            val tg = hit
            if (tg != null) {
                tg.found = true
                Search.setFound(this, tg.slot)
                Search.notify(this, 100 + tg.slot, L.t("notif_found"), tg.name)
                if (targets.all { it.found }) {
                    cnt[mi()]++
                    later(700) {
                        Search.notify(this, 200, L.t("notif_all"), "")
                        closeOverlay()
                    }
                    return
                }
            }

            val sell = sellOn && !reads[chosen].isNew && tg == null
            // El pick se cuenta cuando se toca SIGUIENTE PACK (pick realmente abierto)
            if (sell) {
                later(CARD_TO_BUTTON) { tapView(sellView); lastAction = now() }
                later(CARD_TO_BUTTON + SELL_TO_NEXT) { tapView(nextView); lastAction = now(); cnt[mi()]++; updateInfo() }
                next(CARD_TO_BUTTON + SELL_TO_NEXT + AFTER_NEXT)
            } else {
                later(CARD_TO_BUTTON) { tapView(nextView); lastAction = now(); cnt[mi()]++; updateInfo() }
                next(CARD_TO_BUTTON + AFTER_NEXT)
            }
            return
        }

        // Si la pantalla no es de cartas, la confirmación anterior ya no vale
        confirmSig = null; confirmTries = 0

        // 3) Respaldo: si quedó trabado en otra pantalla, tocar NEXT PACK
        if (now() - lastAction > STUCK_MS) {
            tapView(nextView)
            lastAction = now()
            next(AFTER_NEXT); return
        }
        next(300)
    }

    private fun readCard(i: Int, bmp: Bitmap, els: List<Text.Element>): CardRead {
        val c = centerOf(cardViews[i])
        val bw = (bmp.width * 0.28f).toInt()
        val bh = (bmp.height * 0.17f).toInt()
        val left = c[0] - bw / 2; val top = c[1] - bh / 2
        val rect = Rect(left, top, left + bw, top + bh)
        val ovrZone = Rect(left, top, left + bw * 50 / 100, top + bh * 42 / 100)
        val newZone = Rect(left + bw * 58 / 100, top, left + bw, top + bh * 38 / 100)

        val ovr = els.filter { e ->
            val b = e.boundingBox
            val s = e.text.trim()
            b != null && s.length == 2 && s.all { it.isDigit() } && ovrZone.contains(b.centerX(), b.centerY())
        }.minByOrNull { it.boundingBox!!.top }?.text?.trim()?.toInt()

        val newText = els.any { e ->
            val b = e.boundingBox
            val n = Search.norm(e.text)
            b != null && (n == "NEW" || n == "NUEVO") && newZone.contains(b.centerX(), b.centerY())
        }
        return CardRead(ovr, newText || redPixels(bmp, newZone) >= 60, rect)
    }

    private fun redPixels(bmp: Bitmap, z: Rect): Int {
        val r0 = Rect(z); if (!r0.intersect(0, 0, bmp.width, bmp.height)) return 0
        var n = 0
        var y = r0.top
        while (y < r0.bottom) {
            var x = r0.left
            while (x < r0.right) {
                val p = bmp.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (r > 170 && g < 120 && b < 110 && r - g > 80) n++
                x += 2
            }
            y += 2
        }
        return n
    }

    private fun choose(reads: List<CardRead>): Int {
        val idx = reads.indices.toList()
        val news = idx.filter { reads[it].isNew }
        val pool = if (news.isNotEmpty()) news else idx
        val best = pool.maxOf { reads[it].ovr!! }
        val tied = pool.filter { reads[it].ovr == best }
        return tied[Random.nextInt(tied.size)]
    }

    private fun flash(i: Int) {
        val v = cardViews[i]
        v.background = ring(EMERALD)
        handler.postDelayed({ if (i < cardViews.size) cardViews[i].background = ring(GOLD) }, 400)
    }

    private fun tapView(v: View) {
        val c = centerOf(v)
        tap(c[0].toFloat(), c[1].toFloat())
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    // Android lo llama en cambios de pantalla/foco en algunos equipos: antes frenaba el auto-pick solo.
    override fun onInterrupt() { }

    override fun onDestroy() {
        stop()
        stopFg()
        instance = null
        recognizer.close()
        super.onDestroy()
    }
}
