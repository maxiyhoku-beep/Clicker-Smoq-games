package com.ras.autopicker

import android.content.Context
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display

/** Lectura del DPI en cualquier celular. */
object Dpi {
    /**
     * DPI (densidad) con el que Android dibuja la pantalla AHORA MISMO: es el que usa el juego.
     * Se consulta la pantalla real y, si falla, el sistema y la configuración de la app.
     * Cambia solo si el usuario cambia "Tamaño de pantalla", "Ancho mínimo", la resolución, etc.
     */
    @Suppress("DEPRECATION")
    fun detect(c: Context): Int {
        val found = ArrayList<Int>()
        try {
            val d = (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
            val m = DisplayMetrics(); d.getRealMetrics(m); found.add(m.densityDpi)
        } catch (e: Throwable) { }
        try { found.add(android.content.res.Resources.getSystem().displayMetrics.densityDpi) } catch (e: Throwable) { }
        try { found.add(c.resources.configuration.densityDpi) } catch (e: Throwable) { }
        return found.firstOrNull { it in 100..800 } ?: 420
    }

    /** ppi físico de la pantalla (el de la ficha técnica). Solo informativo. */
    fun physical(c: Context): Int {
        val m = c.resources.displayMetrics
        return ((m.xdpi + m.ydpi) / 2f).toInt()
    }
}
