package com.ras.autopicker

/** Formaciones con sus puestos (de ataque a arco). Las etiquetas se pueden corregir a mano en la pantalla del plantel. */
object Formations {
    class Slot(val label: String, val x: Float, val y: Float)

    val all: LinkedHashMap<String, String> = linkedMapOf(
        "4-3-3" to "EI DC ED|MC MC MC|LI DFC DFC LD|POR",
        "4-4-2" to "DC DC|MI MC MC MD|LI DFC DFC LD|POR",
        "4-2-3-1" to "DC|MI MCO MD|MCD MCD|LI DFC DFC LD|POR",
        "4-1-4-1" to "DC|MI MC MC MD|MCD|LI DFC DFC LD|POR",
        "4-5-1" to "DC|MI MC MC MC MD|LI DFC DFC LD|POR",
        "4-4-1-1" to "DC|MCO|MI MC MC MD|LI DFC DFC LD|POR",
        "4-3-2-1" to "DC|MCO MCO|MC MC MC|LI DFC DFC LD|POR",
        "4-1-2-1-2" to "DC DC|MCO|MC MC|MCD|LI DFC DFC LD|POR",
        "4-2-2-2" to "DC DC|MCO MCO|MCD MCD|LI DFC DFC LD|POR",
        "4-3-1-2" to "DC DC|MCO|MC MC MC|LI DFC DFC LD|POR",
        "4-2-4" to "EI DC DC ED|MC MC|LI DFC DFC LD|POR",
        "3-5-2" to "DC DC|MI MCD MCO MCD MD|DFC DFC DFC|POR",
        "3-4-3" to "EI DC ED|MI MC MC MD|DFC DFC DFC|POR",
        "3-4-1-2" to "DC DC|MCO|MI MC MC MD|DFC DFC DFC|POR",
        "3-4-2-1" to "DC|MCO MCO|MI MC MC MD|DFC DFC DFC|POR",
        "5-3-2" to "DC DC|MC MC MC|LI DFC DFC DFC LD|POR",
        "5-2-3" to "EI DC ED|MC MC|LI DFC DFC DFC LD|POR",
        "5-4-1" to "DC|MI MC MC MD|LI DFC DFC DFC LD|POR"
    )

    fun slots(name: String): List<Slot> {
        val rows = (all[name] ?: all.values.first()).split("|")
        val out = ArrayList<Slot>()
        val n = rows.size
        for ((i, r) in rows.withIndex()) {
            val labels = r.split(" ")
            val y = 0.09f + 0.82f * i / (n - 1)
            val span = when (labels.size) { 1 -> 0f; 2 -> 0.34f; 3 -> 0.62f; 4 -> 0.76f; else -> 0.82f }
            for ((j, l) in labels.withIndex()) {
                val x = if (labels.size == 1) 0.5f else 0.5f - span / 2 + span * j / (labels.size - 1)
                out.add(Slot(l, x, y))
            }
        }
        return out
    }
}
