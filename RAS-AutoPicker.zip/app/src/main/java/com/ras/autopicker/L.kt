package com.ras.autopicker

import android.content.Context

object L {
    var lang = ""

    fun load(c: Context) {
        lang = c.getSharedPreferences("ras", Context.MODE_PRIVATE).getString("lang", "") ?: ""
    }

    fun set(c: Context, l: String) {
        lang = l
        c.getSharedPreferences("ras", Context.MODE_PRIVATE).edit().putString("lang", l).apply()
    }

    fun t(k: String): String = (if (lang == "en") en else es)[k] ?: k

    private val es = mapOf(
        "choose_lang" to "Elegí tu idioma",
        "lang_info" to "Tocá una bandera para elegir el idioma de la app. Lo podés cambiar después desde el menú.",
        "status_off" to "● Servicio DESACTIVADO",
        "status_hidden" to "● Servicio activo · panel cerrado",
        "status_on" to "● Servicio activo · packs: ",
        "btn_activate" to "Activar servicio / mostrar panel",
        "btn_reset" to "Reiniciar posición de punteros",
        "btn_search" to "BÚSQUEDA ESPECÍFICA",
        "btn_channels" to "CANALES",
        "btn_lang" to "🌐 Idioma / Language",
        "home_info" to "MENÚ PRINCIPAL\nActivar servicio: la primera vez te lleva a Accesibilidad; después vuelve a mostrar el panel si lo cerraste.\nReiniciar punteros: vuelve todos los punteros a su lugar original.\n\nPANEL FLOTANTE\n▶ / ■  Iniciar o pausar el auto-pick.\n👁  Ocultar o mostrar los punteros (siguen funcionando aunque no se vean).\n⏻  Cerrar el panel y la app (el permiso queda activado).\n💲  Vender repetidas: dorado = vende las repetidas, apagado = guarda todas.\n➕ / ➖  Agregar o quitar un puntero de carta (para packs de 2 cartas).\nMientras está en marcha solo se ven ■, 👁 y ⏻; el resto aparece al pausar.\n\nPUNTEROS\n1 a 4 dorados: centro de cada carta.\nN verde: botón SIGUIENTE PACK / NEXT PACK.\n$ rojo: botón VENDER / SELL.\nSe arrastran solo con el auto-pick pausado.\n\nREGLA DE ELECCIÓN\nBúsqueda específica → NEW → mayor OVR → empate al azar.\nEl bonus se cierra solo tocando OK, esté a la izquierda o a la derecha.\n\nSIN PAUSAS\nTocá «Evitar que se frene» y elegí Permitir: así el auto-pick no se detiene solo cuando la pantalla o el sistema ahorran batería.\nEn el panel se ve la cantidad de picks abiertos y el tiempo que lleva en marcha.\n\nMODO PACKS\nSA: salta la animación (2 toques en SALTAR), toca VENDER TODO y después SIGUIENTE PACK.\nSM: igual, pero toca VENDER DUPLICADOS.\nPunteros: S azul = Skip/Saltar, $ rojo = vender todo, D rojo = vender repetidas, N verde = siguiente pack.\nSe arrastran con el auto-pick pausado. También cierra el Bonus solo.\nSi los punteros se ven chicos o grandes, ajustá el DPI desde el botón DPI.",
        "need_service" to "Primero activá el servicio",
        "reset_done" to "Punteros reiniciados",
        "panel_shown" to "Panel visible",
        "ch_info" to "CANALES\nTocá un canal para abrirlo en YouTube.",
        "search_info" to "BÚSQUEDA ESPECÍFICA\nSubí hasta 3 capturas de las cartas que querés conseguir. La app lee el nombre y el OVR de cada una: revisalos y corregilos si hace falta, y tocá Guardar.\nCada vez que salga una, te llega la notificación y la elige sola. Cuando salgan todas, el auto-pick se detiene y se cierran el panel y la app.\nPara sacar una carta de la búsqueda, tocá Quitar.",
        "slot" to "Carta ",
        "upload" to "Subir captura",
        "remove" to "Quitar",
        "name_hint" to "Nombre del jugador",
        "ovr_hint" to "OVR (opcional)",
        "found" to "  ✔ Conseguida",
        "reading" to "Leyendo captura...",
        "read_fail" to "No pude leer el nombre, escribilo a mano",
        "save" to "Guardar",
        "saved" to "Búsqueda guardada",
        "back" to "← Volver",
        "notif_found" to "HAZ CONSEGUIDO TU CARTA ESPECIFICA",
        "notif_all" to "Búsqueda completa: auto-pick detenido",
        "p_paused" to "RAS · pausado",
        "p_packs" to "packs: ",
        "min_ptr" to "Mínimo 1 puntero de carta",
        "max_ptr" to "Máximo 4 punteros de carta",
        "sell_on" to "Venta de repetidas ACTIVADA",
        "sell_off" to "Venta desactivada: se guardan todas",
        "btn_battery" to "⚡ Evitar que se frene",
        "battery_done" to "Listo: la batería ya no limita la app",
        "notif_running" to "Auto-pick activo",
        "btn_picks" to "🃏 PICKS",
        "btn_packs" to "📦 PACKS",
        "btn_dpi" to "📐 DPI de pantalla",
        "dpi_detected" to "DPI detectado en este celular: ",
        "dpi_using" to "DPI que usa la app: ",
        "dpi_auto_word" to "automático",
        "dpi_res" to "Resolución de pantalla: ",
        "dpi_hint" to "DPI (100 a 800)",
        "dpi_apply" to "Aplicar DPI",
        "dpi_auto" to "Usar automático",
        "dpi_saved" to "DPI aplicado",
        "dpi_reset" to "DPI automático",
        "dpi_invalid" to "Poné un número entre 100 y 800",
        "dpi_info" to "CÓMO VER TU DPI\nEl número de arriba (\"DPI detectado\") es el que usa tu celular ahora mismo; normalmente lo dejás en automático.\n\nPara verlo en tu celular:\n1) Ajustes > Acerca del teléfono > Información de software, y tocá 7 veces «Número de compilación» para activar Opciones de desarrollador.\n2) Ajustes > Opciones de desarrollador > «Ancho mínimo» (Smallest width). Ese número son dp.\n3) DPI = ancho de pantalla en píxeles × 160 ÷ ancho mínimo. Ejemplo: 720 × 160 ÷ 360 = 320.\nOtra forma: en Ajustes > Pantalla > «Tamaño de pantalla» o «Zoom de pantalla» se cambia el DPI.\n\nPARA QUÉ SIRVE\nEl DPI cambia el tamaño de los punteros y del panel. Si se ven muy chicos o muy grandes, probá otro valor (más alto = más grandes) y tocá Aplicar. Las posiciones se ajustan solas al tamaño de tu pantalla y igual podés arrastrar los punteros con el auto-pick pausado.",
        "need_mode" to "Elegí SA o SM antes de iniciar",
        "sa_on" to "SA: vende todo (VENDER TODO)",
        "sm_on" to "SM: vende repetidas (VENDER DUPLICADOS)"
    )

    private val en = mapOf(
        "choose_lang" to "Choose your language",
        "lang_info" to "Tap a flag to choose the app language. You can change it later from the menu.",
        "status_off" to "● Service OFF",
        "status_hidden" to "● Service on · panel closed",
        "status_on" to "● Service on · packs: ",
        "btn_activate" to "Enable service / show panel",
        "btn_reset" to "Reset pointer positions",
        "btn_search" to "SPECIFIC SEARCH",
        "btn_channels" to "CHANNELS",
        "btn_lang" to "🌐 Idioma / Language",
        "home_info" to "MAIN MENU\nEnable service: the first time it opens Accessibility; afterwards it shows the panel again if you closed it.\nReset pointers: puts every pointer back in its original place.\n\nFLOATING PANEL\n▶ / ■  Start or pause auto-pick.\n👁  Hide or show the pointers (they keep working while hidden).\n⏻  Close the panel and the app (the permission stays on).\n💲  Sell duplicates: gold = sells duplicates, off = keeps every card.\n➕ / ➖  Add or remove a card pointer (for 2-card packs).\nWhile running only ■, 👁 and ⏻ are shown; the rest appears when paused.\n\nPOINTERS\n1 to 4 gold: center of each card.\nN green: NEXT PACK button.\n$ red: SELL button.\nThey can only be dragged while auto-pick is paused.\n\nPICK RULE\nSpecific search → NEW → highest OVR → random on a tie.\nThe bonus is closed automatically by tapping OK, left or right.\n\nNO PAUSES\nTap \"Keep it running\" and choose Allow: this way auto-pick doesn't stop by itself when the screen or the system save battery.\nThe panel shows the number of packs opened and how long it has been running.\n\nPACKS MODE\nSA: skips the animation (2 taps on SKIP), taps SELL ALL and then NEXT PACK.\nSM: same, but taps SELL DUPLICATES.\nPointers: blue S = Skip, red $ = sell all, red D = sell duplicates, green N = next pack.\nThey can be dragged while auto-pick is paused. The Bonus is closed automatically too.\nIf the pointers look too small or too big, adjust the DPI from the DPI button.",
        "need_service" to "Enable the service first",
        "reset_done" to "Pointers reset",
        "panel_shown" to "Panel visible",
        "ch_info" to "CHANNELS\nTap a channel to open it on YouTube.",
        "search_info" to "SPECIFIC SEARCH\nUpload up to 3 screenshots of the cards you want. The app reads each name and OVR: check them, fix them if needed and tap Save.\nEvery time one appears you get a notification and it is picked automatically. When all of them appear, auto-pick stops and the panel and app close.\nTo take a card out of the search, tap Remove.",
        "slot" to "Card ",
        "upload" to "Upload screenshot",
        "remove" to "Remove",
        "name_hint" to "Player name",
        "ovr_hint" to "OVR (optional)",
        "found" to "  ✔ Obtained",
        "reading" to "Reading screenshot...",
        "read_fail" to "Couldn't read the name, type it in",
        "save" to "Save",
        "saved" to "Search saved",
        "back" to "← Back",
        "notif_found" to "YOU GOT YOUR SPECIFIC CARD",
        "notif_all" to "Search complete: auto-pick stopped",
        "p_paused" to "RAS · paused",
        "p_packs" to "packs: ",
        "min_ptr" to "At least 1 card pointer",
        "max_ptr" to "Up to 4 card pointers",
        "sell_on" to "Selling duplicates ON",
        "sell_off" to "Selling off: every card is kept",
        "btn_battery" to "⚡ Keep it running",
        "battery_done" to "Done: battery no longer limits the app",
        "notif_running" to "Auto-pick active",
        "btn_picks" to "🃏 PICKS",
        "btn_packs" to "📦 PACKS",
        "btn_dpi" to "📐 Screen DPI",
        "dpi_detected" to "DPI detected on this phone: ",
        "dpi_using" to "DPI used by the app: ",
        "dpi_auto_word" to "automatic",
        "dpi_res" to "Screen resolution: ",
        "dpi_hint" to "DPI (100 to 800)",
        "dpi_apply" to "Apply DPI",
        "dpi_auto" to "Use automatic",
        "dpi_saved" to "DPI applied",
        "dpi_reset" to "Automatic DPI",
        "dpi_invalid" to "Enter a number between 100 and 800",
        "dpi_info" to "HOW TO SEE YOUR DPI\nThe number above (\"DPI detected\") is what your phone uses right now; you can normally leave it on automatic.\n\nTo check it on your phone:\n1) Settings > About phone > Software information, and tap \"Build number\" 7 times to enable Developer options.\n2) Settings > Developer options > \"Smallest width\". That number is in dp.\n3) DPI = screen width in pixels × 160 ÷ smallest width. Example: 720 × 160 ÷ 360 = 320.\nAnother way: Settings > Display > \"Display size\" or \"Screen zoom\" changes the DPI.\n\nWHAT IT DOES\nDPI changes the size of the pointers and the panel. If they look too small or too big, try another value (higher = bigger) and tap Apply. Positions adapt to your screen size by themselves and you can still drag the pointers while auto-pick is paused.",
        "need_mode" to "Pick SA or SM before starting",
        "sa_on" to "SA: sells all (SELL ALL)",
        "sm_on" to "SM: sells duplicates (SELL DUPLICATES)"
    )
}
