package com.ras.autopicker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : Activity() {
    companion object { var current: MainActivity? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val RED = Color.parseColor("#E53935")
    private val GREEN = Color.parseColor("#2ECC71")
    private lateinit var content: LinearLayout
    private var screen = "home"
    private val prefs by lazy { getSharedPreferences("ras", MODE_PRIVATE) }
    private val nameEdits = arrayOfNulls<EditText>(3)
    private val ovrEdits = arrayOfNulls<EditText>(3)

    private val channels = listOf(
        "CANAL FELCOR" to "https://youtube.com/@felcor?si=h24n3RTS_8o2Ljlu",
        "CANAL comer305" to "https://youtube.com/@comer305?si=XJDEP0JpTCxKhfww",
        "CANAL DYLANFUT" to "https://youtube.com/@dylanfut2322?si=ujxpJ9Wj_I8IDr5c",
        "CANAL FRYKKO" to "https://youtube.com/@frykko57?si=QygSlJB8722jEyET"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        L.load(this)
        Search.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.menu_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), 0, dp(28), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(content) }, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = (resources.displayMetrics.heightPixels * 0.33f).toInt()
        })
        setContentView(root)
        if (L.lang.isEmpty()) showLang() else showHome()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (screen == "home") showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen == "home" || (screen == "lang" && L.lang.isEmpty())) super.onBackPressed() else showHome()
    }

    // ---------- piezas visuales ----------
    private fun goldButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(IVORY)
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#E6000000"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), GOLD)
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(10) }
        setOnClickListener { action() }
    }

    private fun box() = GradientDrawable().apply {
        setColor(Color.parseColor("#D9000000"))
        cornerRadius = dp(12).toFloat()
        setStroke(dp(1), GOLD)
    }

    private fun infoBox(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(IVORY)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = box()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun label(text: String, color: Int = IVORY, size: Float = 15f) = TextView(this).apply {
        this.text = text; textSize = size; gravity = Gravity.CENTER; setTextColor(color)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    // ---------- pantallas ----------
    private fun showLang() {
        screen = "lang"
        content.removeAllViews()
        content.addView(label("Elegí tu idioma / Choose your language", GOLD, 18f))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        }
        fun flag(emoji: String, name: String, code: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = box()
            addView(label(emoji, IVORY, 54f))
            addView(label(name, IVORY, 15f))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(10), 0, dp(10), 0) }
            setOnClickListener {
                L.set(this@MainActivity, code)
                PickerService.instance?.refreshTexts()
                showHome()
            }
        }
        row.addView(flag("🇺🇸", "English", "en"))
        row.addView(flag("🇦🇷", "Español", "es"))
        content.addView(row)
        content.addView(infoBox("ES: Tocá una bandera para elegir el idioma de la app.\nEN: Tap a flag to choose the app language."))
    }

    private fun showHome() {
        screen = "home"
        content.removeAllViews()
        val s = PickerService.instance
        val st = when {
            s == null -> L.t("status_off")
            !s.overlayShown -> L.t("status_hidden")
            else -> L.t("status_on") + s.packs
        }
        content.addView(label(st, if (s == null) RED else GREEN))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        content.addView(label("v$ver", GOLD, 11f))
        if (s != null) content.addView(statsBlock())
        if (s == null) {
            // Paso 1: activar el permiso de Accesibilidad
            content.addView(goldButton(L.t("btn_activate")) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        } else {
            // Paso 2: con el permiso dado, el botón se reemplaza por PICKS y PACKS
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(goldButton(L.t("btn_picks")) {
                s.showOverlay("picks"); toast(L.t("panel_shown")); showHome()
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f).apply { rightMargin = dp(6); topMargin = dp(10) } })
            row.addView(goldButton(L.t("btn_packs")) {
                s.showOverlay("packs"); toast(L.t("panel_shown")); showHome()
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f).apply { leftMargin = dp(6); topMargin = dp(10) } })
            content.addView(row)
        }
        content.addView(goldButton(L.t("btn_reset")) {
            val svc = PickerService.instance
            if (svc == null) toast(L.t("need_service")) else { svc.resetPositions(); toast(L.t("reset_done")) }
        })
        content.addView(goldButton(L.t("btn_battery")) { askBattery() })
        content.addView(goldButton(L.t("btn_dpi")) { showDpi() })
        content.addView(goldButton("🔍 " + L.t("btn_search")) { showSearch() })
        content.addView(goldButton("▶️ " + L.t("btn_channels")) { showChannels() })
        content.addView(goldButton(L.t("btn_lang")) { showLang() })
        content.addView(infoBox(L.t("home_info")))
    }

    // ---------- contadores en el menú (mismas imágenes que en los paneles) ----------
    private var pickStatTv: TextView? = null
    private var packStatTv: TextView? = null
    private val statsTick = object : Runnable {
        override fun run() {
            if (screen != "home") return
            refreshStats()
            content.postDelayed(this, 1000)
        }
    }

    private fun refreshStats() {
        val s = PickerService.instance ?: return
        pickStatTv?.text = "PICKS   ${s.statCount(0)}   ⏱ ${s.statTime(0)}"
        packStatTv?.text = "PACKS   ${s.statCount(1)}   ⏱ ${s.statTime(1)}"
    }

    private fun statsBlock(): LinearLayout {
        fun row(icon: Int, w: Int, h: Int): Pair<LinearLayout, TextView> {
            val tv = TextView(this).apply { textSize = 15f; setTextColor(IVORY); setPadding(dp(12), 0, 0, 0) }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon); scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(w), dp(h))
                })
                addView(tv)
            }
            return Pair(r, tv)
        }
        val a = row(R.drawable.ic_pack, 26, 36)
        val b = row(R.drawable.ic_pack_packs, 26, 38)
        pickStatTv = a.second; packStatTv = b.second
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = box()
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            addView(a.first)
            addView(b.first.apply { setPadding(0, dp(8), 0, 0) })
        }
        refreshStats()
        content.removeCallbacks(statsTick)
        content.postDelayed(statsTick, 1000)
        return box
    }

    private fun showDpi() {
        screen = "dpi"
        content.removeAllViews()
        content.addView(label(L.t("btn_dpi"), GOLD, 20f))
        val dm = resources.displayMetrics
        val detected = Dpi.detect(this)
        val saved = prefs.getInt("dpi", 0)
        content.addView(infoBox(
            L.t("dpi_detected") + detected + "\n" +
            L.t("dpi_phys") + Dpi.physical(this) + "\n" +
            L.t("dpi_using") + (if (saved > 0) saved.toString() else L.t("dpi_auto_word")) + "\n" +
            L.t("dpi_res") + dm.widthPixels + " x " + dm.heightPixels
        ))
        // Recuadro: por qué el DPI de Android no coincide con el ppi físico
        content.addView(label(L.t("dpi_why_title"), GOLD, 15f).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        })
        content.addView(infoBox(L.t("dpi_why")).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6101010")); cornerRadius = dp(12).toFloat(); setStroke(dp(2), GOLD)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        })
        // Recuadro destacado: cómo saber el DPI del celular
        content.addView(label(L.t("dpi_how_title"), GOLD, 15f).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        })
        content.addView(infoBox(L.t("dpi_how")).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6101010")); cornerRadius = dp(12).toFloat(); setStroke(dp(2), GOLD)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(10) }
        })
        val edit = EditText(this).apply {
            hint = L.t("dpi_hint")
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(IVORY); setHintTextColor(Color.GRAY); isSingleLine = true
            gravity = Gravity.CENTER
            if (saved > 0) setText(saved.toString())
        }
        content.addView(edit)
        content.addView(goldButton(L.t("dpi_apply")) {
            val v = edit.text.toString().trim().toIntOrNull()
            if (v == null || v < 100 || v > 800) toast(L.t("dpi_invalid"))
            else {
                prefs.edit().putInt("dpi", v).apply()
                PickerService.instance?.applyDpi()
                toast(L.t("dpi_saved")); showDpi()
            }
        })
        content.addView(goldButton(L.t("dpi_auto")) {
            prefs.edit().remove("dpi").apply()
            PickerService.instance?.applyDpi()
            toast(L.t("dpi_reset")); showDpi()
        })
        content.addView(goldButton(L.t(if (prefs.getBoolean("autoadj", true)) "adj_on" else "adj_off")) {
            prefs.edit().putBoolean("autoadj", !prefs.getBoolean("autoadj", true)).apply()
            PickerService.instance?.applyDpi()
            showDpi()
        })
        content.addView(infoBox(L.t("adj_info")))
        content.addView(infoBox(L.t("dpi_info")))
        content.addView(goldButton(L.t("back")) { showHome() })
    }

    /** Pide quitar la restricción de batería para que Android no frene el auto-pick. */
    private fun askBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) { toast(L.t("battery_done")); return }
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    private fun showChannels() {
        screen = "channels"
        content.removeAllViews()
        content.addView(label(L.t("btn_channels"), GOLD, 20f))
        content.addView(infoBox(L.t("ch_info")))
        for ((name, url) in channels) {
            content.addView(goldButton(name) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast(url) }
            })
        }
        content.addView(goldButton(L.t("back")) { showHome() })
    }

    private fun showSearch() {
        screen = "search"
        content.removeAllViews()
        content.addView(label(L.t("btn_search"), GOLD, 20f))
        content.addView(infoBox(L.t("search_info")))
        for (i in 0..2) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = box()
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            }
            val found = prefs.getBoolean("t${i}_found", false)
            card.addView(label(L.t("slot") + (i + 1) + (if (found) L.t("found") else ""), if (found) GREEN else GOLD, 16f))
            val uri = prefs.getString("t${i}_uri", null)
            if (uri != null) {
                try {
                    val bmp = contentResolver.openInputStream(Uri.parse(uri)).use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })
                    }
                    if (bmp != null) card.addView(ImageView(this).apply {
                        setImageBitmap(bmp)
                        adjustViewBounds = true
                        layoutParams = LinearLayout.LayoutParams(-1, dp(140)).apply { topMargin = dp(6) }
                    })
                } catch (e: Exception) { }
            }
            val name = EditText(this).apply {
                hint = L.t("name_hint"); setText(prefs.getString("t${i}_name", ""))
                setTextColor(IVORY); setHintTextColor(Color.GRAY); isSingleLine = true
            }
            val ovr = EditText(this).apply {
                hint = L.t("ovr_hint"); setText(prefs.getString("t${i}_ovr", ""))
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(IVORY); setHintTextColor(Color.GRAY)
            }
            nameEdits[i] = name; ovrEdits[i] = ovr
            card.addView(name); card.addView(ovr)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(goldButton(L.t("upload")) {
                persistEdits()
                val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                }
                startActivityForResult(it, 10 + i)
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) } })
            row.addView(goldButton(L.t("remove")) {
                persistEdits()
                prefs.edit().remove("t${i}_name").remove("t${i}_ovr").remove("t${i}_uri").remove("t${i}_found").apply()
                PickerService.instance?.reloadTargets()
                showSearch()
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f) })
            card.addView(row)
            content.addView(card)
        }
        content.addView(goldButton("💾 " + L.t("save")) {
            persistEdits()
            val e = prefs.edit()
            for (i in 0..2) e.putBoolean("t${i}_found", false)
            e.apply()
            PickerService.instance?.reloadTargets()
            toast(L.t("saved"))
            showSearch()
        })
        content.addView(goldButton(L.t("back")) { persistEdits(); showHome() })
    }

    private fun persistEdits() {
        val e = prefs.edit()
        for (i in 0..2) {
            nameEdits[i]?.let { e.putString("t${i}_name", it.text.toString().trim()) }
            ovrEdits[i]?.let { e.putString("t${i}_ovr", it.text.toString().trim()) }
        }
        e.apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode !in 10..12 || resultCode != RESULT_OK || uri == null) return
        val slot = requestCode - 10
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        prefs.edit().putString("t${slot}_uri", uri.toString()).putBoolean("t${slot}_found", false).apply()
        toast(L.t("reading"))
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            recognizer.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { text ->
                    val (n, o) = Search.extract(text)
                    if (n.isEmpty()) toast(L.t("read_fail"))
                    prefs.edit().putString("t${slot}_name", n).putString("t${slot}_ovr", o?.toString() ?: "").apply()
                    PickerService.instance?.reloadTargets()
                    showSearch()
                }
                .addOnFailureListener { toast(L.t("read_fail")); showSearch() }
        } catch (e: Exception) {
            toast(L.t("read_fail")); showSearch()
        }
    }
}
