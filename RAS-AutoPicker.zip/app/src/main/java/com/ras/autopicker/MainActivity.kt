package com.ras.autopicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun goldButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.parseColor("#F5F0E1"))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#E6000000"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), Color.parseColor("#D4AF37"))
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(56)
        ).apply { topMargin = dp(12) }
        setOnClickListener { action() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.menu_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), 0, dp(32), dp(24))
        }
        val scroll = ScrollView(this).apply { addView(col) }
        // deja libre la zona del logo
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = (resources.displayMetrics.heightPixels * 0.34f).toInt()
        })

        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F5F0E1"))
        }
        col.addView(status)

        col.addView(goldButton("1 · Activar servicio (Accesibilidad)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(goldButton("2 · Reiniciar posición de punteros") {
            val s = PickerService.instance
            if (s == null) toast("Primero activá el servicio") else { s.resetPositions(); toast("Punteros reiniciados") }
        })
        col.addView(goldButton("3 · Abrir el juego y apretar ▶") {
            toast("Abrí el juego en la pantalla de las 3 cartas y tocá el botón ▶ flotante")
        })
        col.addView(goldButton("👁 · Ocultar / mostrar punteros") {
            val s = PickerService.instance
            if (s == null) toast("Primero activá el servicio") else s.togglePointers()
        })
        col.addView(goldButton("⏻ · Desactivar auto-pick") {
            val s = PickerService.instance
            if (s == null) toast("El auto-pick ya está desactivado")
            else { s.shutdown(); toast("Auto-pick desactivado"); onResume() }
        })

        col.addView(TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#F5F0E1"))
            setPadding(0, dp(18), 0, 0)
            text = "Punteros dorados 1, 2 y 3: centro de cada carta.\n" +
                "Puntero verde N: botón NEXT PACK (respaldo).\n" +
                "Se arrastran solo cuando el auto-picker está detenido.\n\n" +
                "Regla: NEW primero → mayor OVR → empate al azar.\n" +
                "El bonus se cierra solo tocando OK, esté a la izquierda o a la derecha."
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val s = PickerService.instance
        status.text = if (s == null) "● Servicio DESACTIVADO" else "● Servicio activo · packs abiertos: ${s.packs}"
        status.setTextColor(Color.parseColor(if (s == null) "#E53935" else "#2ECC71"))
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
