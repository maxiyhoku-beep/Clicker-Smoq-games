package com.ras.autopicker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : Activity() {
    companion object { var current: MainActivity? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val RED = Color.parseColor("#E53935")
    private val GREEN = Color.parseColor("#2ECC71")
    private lateinit var content: LinearLayout
    private var screen = "home"
    private val prefs by lazy { getSharedPreferences("ras", MODE_PRIVATE) }
    private val nameEdits = arrayOfNulls<EditText>(3)
    private val ovrEdits = arrayOfNulls<EditText>(3)

    private val channels = listOf(
        "CANAL FELCOR" to "https://youtube.com/@felcor?si=h24n3RTS_8o2Ljlu",
        "CANAL comer305" to "https://youtube.com/@comer305?si=XJDEP0JpTCxKhfww",
        "CANAL DYLANFUT" to "https://youtube.com/@dylanfut2322?si=ujxpJ9Wj_I8IDr5c",
        "CANAL FRYKKO" to "https://youtube.com/@frykko57?si=QygSlJB8722jEyET"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        L.load(this)
        Search.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.menu_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), 0, dp(28), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(content) }, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = (resources.displayMetrics.heightPixels * 0.33f).toInt()
        })
        setContentView(root)
        if (L.lang.isEmpty()) showLang() else showHome()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        PickerService.instance?.recheckDpi()
        if (screen == "home") showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen == "home" || (screen == "lang" && L.lang.isEmpty())) super.onBackPressed() else showHome()
    }

    // ---------- piezas visuales ----------
    private fun goldButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(IVORY)
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#E6000000"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), GOLD)
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(10) }
        setOnClickListener { action() }
    }

    /** Botón dorado con una imagen a la izquierda del texto. */
    private fun iconButton(icon: Int, w: Int, h: Int, label: String, action: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#E6000000"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), GOLD)
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(10) }
        addView(ImageView(this@MainActivity).apply {
            setImageResource(icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(dp(w), dp(h))
        })
        addView(TextView(this@MainActivity).apply {
            text = label; textSize = 16f; setTextColor(IVORY); setPadding(dp(10), 0, 0, 0)
        })
        setOnClickListener { action() }
    }

    private fun box() = GradientDrawable().apply {
        setColor(Color.parseColor("#D9000000"))
        cornerRadius = dp(12).toFloat()
        setStroke(dp(1), GOLD)
    }

    private fun infoBox(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(IVORY)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = box()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun label(text: String, color: Int = IVORY, size: Float = 15f) = TextView(this).apply {
        this.text = text; textSize = size; gravity = Gravity.CENTER; setTextColor(color)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    // ---------- pantallas ----------
    private fun showLang() {
        screen = "lang"
        content.removeAllViews()
        content.addView(label("Elegí tu idioma / Choose your language", GOLD, 18f))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        }
        fun flag(emoji: String, name: String, code: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = box()
            addView(label(emoji, IVORY, 54f))
            addView(label(name, IVORY, 15f))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(10), 0, dp(10), 0) }
            setOnClickListener {
                L.set(this@MainActivity, code)
                PickerService.instance?.refreshTexts()
                showHome()
            }
        }
        row.addView(flag("🇺🇸", "English", "en"))
        row.addView(flag("🇦🇷", "Español", "es"))
        content.addView(row)
        content.addView(infoBox("ES: Tocá una bandera para elegir el idioma de la app.\nEN: Tap a flag to choose the app language."))
    }

    private fun showHome() {
        screen = "home"
        content.removeAllViews()
        val s = PickerService.instance
        val st = when {
            s == null -> L.t("status_off")
            !s.overlayShown -> L.t("status_hidden")
            else -> L.t("status_on") + s.packs
        }
        content.addView(label(st, if (s == null) RED else GREEN))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        content.addView(label("v$ver", GOLD, 11f))
        if (s == null) {
            // Paso 1: activar el permiso de Accesibilidad
            content.addView(goldButton(L.t("btn_activate")) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        } else {
            // Paso 2: con el permiso dado, el botón se reemplaza por PICKS y PACKS
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(iconButton(R.drawable.ic_pack, 26, 36, "PICKS") {
                s.showOverlay("picks"); toast(L.t("panel_shown")); showHome()
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f).apply { rightMargin = dp(6); topMargin = dp(10) } })
            row.addView(iconButton(R.drawable.ic_pack_packs, 25, 37, "PACKS") {
                s.showOverlay("packs"); toast(L.t("panel_shown")); showHome()
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f).apply { leftMargin = dp(6); topMargin = dp(10) } })
            content.addView(row)
            content.addView(iconButton(R.drawable.ic_champions, 30, 40, "CHAMPIONS") {
                s.showOverlay("champions"); toast(L.t("panel_shown")); showHome()
            })
        }
        content.addView(goldButton(L.t("btn_reset")) {
            val svc = PickerService.instance
            if (svc == null) toast(L.t("need_service")) else { svc.resetPositions(); toast(L.t("reset_done")) }
        })
        content.addView(goldButton("👥 PLANTEL CHAMPIONS") { loadRoster(); showRoster() })
        content.addView(goldButton("🔧 DIAGNÓSTICO") { showDiag() })
        content.addView(goldButton(L.t("btn_battery")) { askBattery() })
        content.addView(goldButton(L.t("btn_dpi")) { showDpi() })
        content.addView(goldButton("🔍 " + L.t("btn_search")) { showSearch() })
        content.addView(goldButton("▶️ " + L.t("btn_channels")) { showChannels() })
        content.addView(goldButton(L.t("btn_lang")) { showLang() })
        content.addView(infoBox(L.t("home_info")))
    }

    private fun showDpi() {
        screen = "dpi"
        content.removeAllViews()
        content.addView(label(L.t("btn_dpi"), GOLD, 20f))
        val dm = resources.displayMetrics
        content.addView(infoBox(
            L.t("dpi_detected") + Dpi.detect(this) + "\n" +
            L.t("dpi_phys") + Dpi.physical(this) + "\n" +
            L.t("dpi_res") + dm.widthPixels + " x " + dm.heightPixels
        ))
        content.addView(label(L.t("dpi_why_title"), GOLD, 15f).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        })
        content.addView(infoBox(L.t("dpi_why")).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6101010")); cornerRadius = dp(12).toFloat(); setStroke(dp(2), GOLD)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
        })
        content.addView(label(L.t("dpi_how_title"), GOLD, 15f).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        })
        content.addView(infoBox(L.t("dpi_how")).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6101010")); cornerRadius = dp(12).toFloat(); setStroke(dp(2), GOLD)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(10) }
        })
        content.addView(goldButton(L.t(if (prefs.getBoolean("autoadj", true)) "adj_on" else "adj_off")) {
            prefs.edit().putBoolean("autoadj", !prefs.getBoolean("autoadj", true)).apply()
            PickerService.instance?.applyDpi()
            showDpi()
        })
        content.addView(infoBox(L.t("adj_info")))
        content.addView(infoBox(L.t("dpi_info")))
        content.addView(goldButton(L.t("back")) { showHome() })
    }

    /** Pide quitar la restricción de batería para que Android no frene el auto-pick. */
    private fun askBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) { toast(L.t("battery_done")); return }
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    private fun showDiag() {
        val hints = "\n\nSi algo falla en tu celular:\n" +
            "• Si el permiso de Accesibilidad aparece bloqueado: Ajustes → Aplicaciones → RAS Auto-Picker → menú ⋮ (arriba a la derecha) → «Permitir ajustes restringidos», y activalo de nuevo.\n" +
            "• Samsung: Ajustes → Batería → Límites de uso en segundo plano → «Apps que nunca se suspenden» → agregar RAS Auto-Picker. Además desactivá Auto Blocker (Ajustes → Seguridad y privacidad) mientras lo usás.\n" +
            "• Desactivá y volvé a activar el servicio en Ajustes → Accesibilidad → Apps instaladas → RAS Auto-Picker."
        fun dialog(text: String) {
            val tv = TextView(this).apply {
                this.text = text + hints; textSize = 13f; setPadding(dp(18), dp(14), dp(18), dp(6)); setTextIsSelectable(true)
            }
            android.app.AlertDialog.Builder(this)
                .setTitle("Diagnóstico")
                .setView(ScrollView(this).apply { addView(tv) })
                .setPositiveButton("Compartir") { _, _ ->
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
                    }, "Diagnóstico"))
                }
                .setNegativeButton("Cerrar", null).show()
        }
        val svc = PickerService.instance
        if (svc == null) {
            dialog("Equipo: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "Servicio de accesibilidad: NO está activo. Sin eso no hay clics ni capturas. Activalo en Ajustes → Accesibilidad.")
        } else {
            toast("Probando... (unos segundos)")
            svc.diagnose { r -> runOnUiThread { dialog(r) } }
        }
    }

    // ---------- plantel de CHAMPIONS ----------
    private class RP(
        var kind: String, var name: String = "", var nat: String = "", var ovr: String = "", var pos: String = "",
        var extras: String = "", var img: String = "", var slot: Int = -1, var slotLabel: String = "", var sig: String = "", var thumb: String = ""
    )
    private val roster = ArrayList<RP>()
    private var formation = "4-3-3"

    private class Ed(
        val name: EditText, val nat: EditText, val ovr: EditText, val pos: EditText, val extras: EditText,
        val preview: ImageView, var img: String
    )
    private var curEd: Ed? = null

    private fun loadRoster() {
        roster.clear()
        formation = prefs.getString("ch_form", "4-3-3") ?: "4-3-3"
        for (line in (prefs.getString("ch_roster", "") ?: "").split("\n")) {
            val p = line.split("|")
            if (p.size >= 6) roster.add(RP(p[0], p[1], p[2], p[3], p[4], p[5],
                p.getOrElse(6) { "" }, p.getOrElse(7) { "-1" }.toIntOrNull() ?: -1, p.getOrElse(8) { "" }, p.getOrElse(9) { "" }, p.getOrElse(10) { "" }))
        }
    }

    private fun saveRoster() {
        val c = { s: String -> s.replace("|", " ").replace("\n", " ").trim() }
        val txt = roster.filter { it.pos.isNotBlank() }
            .joinToString("\n") { "${it.kind}|${c(it.name)}|${c(it.nat)}|${c(it.ovr)}|${c(it.pos)}|${c(it.extras)}|${c(it.img)}|${it.slot}|${c(it.slotLabel)}|${c(it.sig)}|${c(it.thumb)}" }
        prefs.edit().putString("ch_roster", txt).putString("ch_form", formation).apply()
    }

    private fun rosterEdit(hint: String, value: String, number: Boolean = false, caps: Boolean = false) = EditText(this).apply {
        setHint(hint); setText(value)
        setTextColor(IVORY); setHintTextColor(Color.parseColor("#88F5F0E1")); textSize = 14f
        setSingleLine(true)
        inputType = if (number) InputType.TYPE_CLASS_NUMBER
        else if (caps) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        else InputType.TYPE_CLASS_TEXT
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    private fun cardImage(name: String) = try {
        if (name.isBlank()) null else BitmapFactory.decodeFile(java.io.File(filesDir, name).absolutePath)
    } catch (e: Throwable) { null }

    /** Editor de un jugador. kind "F" = titular de un puesto de la cancha; "B" = suplente (benchIdx es su lugar en el banco). */
    private fun editPlayer(kind: String, slot: Int, label: String, benchIdx: Int) {
        val existing = if (kind == "F") roster.firstOrNull { it.kind == "F" && it.slot == slot }
        else roster.filter { it.kind == "B" }.getOrNull(benchIdx)
        val e = existing ?: RP(kind, slot = slot, slotLabel = label, pos = if (kind == "F") label else "")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(6)) }
        val preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(-1, dp(150))
            (cardImage(e.img) ?: cardImage(e.thumb))?.let { setImageBitmap(it) }
        }
        box.addView(preview)
        box.addView(TextView(this).apply {
            text = if (e.thumb.isNotEmpty()) "Esta es la carta como se ve en el juego. Subí la captura de detalle de ESTA misma carta: la app lee sus posiciones extra y las une a ella. Revisá lo que lea."
            else "Subí la captura de la pantalla de detalle del jugador. La app lee el OVR, la posición, el apellido y las posiciones extra; revisá lo que lea."
            setTextColor(IVORY); textSize = 12f
        })
        val up = Button(this).apply { text = "📷 SUBIR CAPTURA"; isAllCaps = false; setTextColor(GOLD) }
        box.addView(up)
        val name = rosterEdit("Nombre / apellido", e.name); val nat = rosterEdit("Nacionalidad", e.nat)
        val ovr = rosterEdit("OVR", e.ovr, number = true); val pos = rosterEdit("Posición (ej. MC)", e.pos, caps = true)
        val ex = rosterEdit("Otras posiciones (ej. MD, ED)", e.extras, caps = true)
        box.addView(name); box.addView(nat)
        box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(ovr, LinearLayout.LayoutParams(0, -2, 1f)); addView(pos, LinearLayout.LayoutParams(0, -2, 1f))
        })
        box.addView(ex)
        val ed = Ed(name, nat, ovr, pos, ex, preview, e.img)
        up.setOnClickListener {
            curEd = ed
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
        }
        val title = if (kind == "F") "Titular · puesto $label" else "Suplente · slot ${benchIdx + 1}"
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Guardar") { _, _ ->
                e.name = name.text.toString(); e.nat = nat.text.toString(); e.ovr = ovr.text.toString()
                e.pos = pos.text.toString(); e.extras = ex.text.toString(); e.img = ed.img
                if (kind == "F") { e.slot = slot; e.slotLabel = label }
                if (existing == null) roster.add(e)
                saveRoster(); curEd = null; showRoster()
            }
            .setNeutralButton("Borrar") { _, _ -> if (existing != null) roster.remove(existing); saveRoster(); curEd = null; showRoster() }
            .setNegativeButton("Cancelar") { _, _ -> curEd = null }
            .show()
    }

    private fun rosterResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != 77 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val ed = curEd ?: return
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sample = 1
            while (maxOf(o.outWidth, o.outHeight) / sample > 1600) sample *= 2
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return
            val fname = "ros_${System.currentTimeMillis()}.jpg"
            java.io.FileOutputStream(java.io.File(filesDir, fname)).use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
            ed.img = fname
            ed.preview.setImageBitmap(bmp)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { t ->
                    val r = Roster.parse(t, bmp.width, bmp.height)
                    if (r.ovr.isNotEmpty()) ed.ovr.setText(r.ovr)
                    if (r.pos.isNotEmpty()) ed.pos.setText(r.pos)
                    if (r.extras.isNotEmpty()) ed.extras.setText(r.extras.joinToString(", "))
                    if (r.name.isNotEmpty()) ed.name.setText(r.name)
                    toast("Leí: OVR ${r.ovr.ifEmpty { "?" }} · ${r.pos.ifEmpty { "?" }} · extras ${if (r.extras.isEmpty()) "ninguna" else r.extras.joinToString(",")} · ${r.name.ifEmpty { "sin apellido" }}. Revisalo.")
                }
                .addOnFailureListener { toast("No pude leer la captura. Cargá los datos a mano.") }
        } catch (e: Throwable) { toast("No pude abrir esa imagen.") }
    }

    private fun benchCard(e: RP?, n: Int): android.view.View {
        val gold = GOLD
        val fl = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61A1A1A")); cornerRadius = dp(10).toFloat(); setStroke(dp(2), gold)
            }
            layoutParams = LinearLayout.LayoutParams(dp(78), dp(108)).apply { rightMargin = dp(8) }
        }
        if (e == null) {
            fl.addView(TextView(this).apply { text = "+"; textSize = 30f; setTextColor(gold); gravity = Gravity.CENTER },
                FrameLayout.LayoutParams(-1, -1))
        } else {
            (cardImage(e.thumb) ?: cardImage(e.img))?.let { bm ->
                fl.addView(ImageView(this).apply { setImageBitmap(bm); scaleType = ImageView.ScaleType.CENTER_CROP; alpha = if (e.thumb.isNotEmpty()) 0.8f else 0.55f },
                    FrameLayout.LayoutParams(-1, -1))
            }
            fl.addView(TextView(this).apply {
                text = (e.ovr.ifBlank { "--" }) + "\n" + e.pos; setTextColor(IVORY); textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(6), dp(4), 0, 0)
            }, FrameLayout.LayoutParams(-2, -2))
            fl.addView(TextView(this).apply {
                text = e.name; setTextColor(GOLD); textSize = 10f; gravity = Gravity.CENTER; setSingleLine(true)
            }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(3) })
        }
        fl.addView(TextView(this).apply { text = "$n"; textSize = 9f; setTextColor(Color.parseColor("#AAF5F0E1")) },
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = dp(2); rightMargin = dp(5) })
        return fl
    }

    /** Cartas del banco que leyó el auto clicker dentro del juego: ovr, pos, nombre, firma, miniatura. */
    private fun learned(): List<List<String>> =
        (prefs.getString("ch_learn", "") ?: "").split("\n").filter { it.isNotBlank() }
            .map { l -> l.split("|").let { p -> List(5) { p.getOrElse(it) { "" } } } }

    /** Histograma de tonos (12 grupos) de los colores vivos de una imagen: sirve para comparar el color de dos cartas. */
    private fun hueHist(b: android.graphics.Bitmap): FloatArray {
        val t = android.graphics.Bitmap.createScaledBitmap(b, 48, 48, true)
        val h = FloatArray(12); var n = 0f
        val hsv = FloatArray(3)
        for (y in 0 until 48) for (x in 0 until 48) {
            Color.colorToHSV(t.getPixel(x, y), hsv)
            if (hsv[1] > 0.25f && hsv[2] > 0.25f) { h[(hsv[0] / 30f).toInt().coerceIn(0, 11)] += 1f; n += 1f }
        }
        if (n > 0f) for (i in 0 until 12) h[i] /= n
        return h
    }

    private fun hueSim(a: FloatArray, b: FloatArray): Double { var s = 0.0; for (i in 0 until 12) s += minOf(a[i], b[i]); return s }

    /** Reemplaza los suplentes por el banco leído en el juego, conservando lo que ya cargaste (extras, nacionalidad, captura). */
    private fun useLearned() {
        val ln = learned().filter { it[1] != "?" && it[1].isNotBlank() }
        if (ln.isEmpty()) {
            toast("Todavía no leí tu banco. Abrí Champions con el auto clicker: la primera vez que haga un cambio lee el banco completo.")
            return
        }
        val old = roster.filter { it.kind == "B" }.toMutableList()
        val fresh = ArrayList<RP>()
        val ts = System.currentTimeMillis()
        val nrm = { t: String -> t.uppercase().filter { ch -> ch.isLetter() } }
        for ((i, l) in ln.withIndex()) {
            var th = ""
            if (l[4].isNotEmpty()) try {
                th = "th_${ts}_$i.jpg"
                java.io.File(filesDir, l[4]).copyTo(java.io.File(filesDir, th), true)
            } catch (e: Throwable) { th = "" }
            val cands = old.filter { it.ovr.trim() == l[0] && it.pos.trim().equals(l[1], true) }
            var m: RP? = if (cands.size == 1) cands[0] else null
            if (cands.size > 1) {
                // varias cargadas con el mismo OVR y posición: gana el mismo apellido y, si no, la captura de colores más parecidos
                val tb = cardImage(th)
                val hb = if (tb != null) hueHist(tb) else null
                m = cands.maxByOrNull { c ->
                    val a = nrm(c.name); val b = nrm(l[2])
                    var sc = if (a.length >= 3 && b.length >= 3 && (a.contains(b) || b.contains(a) || a.take(4) == b.take(4))) 1.0 else 0.0
                    val sb = cardImage(c.img)
                    if (sb != null && hb != null) sc += hueSim(hueHist(sb), hb)
                    sc
                }
            }
            if (m != null) {
                old.remove(m)
                if (m.thumb.isNotEmpty()) try { java.io.File(filesDir, m.thumb).delete() } catch (e: Throwable) { }
                m.sig = l[3]; m.thumb = th; fresh.add(m); continue
            }
            fresh.add(RP("B", l[2], "", l[0], l[1], "", "", -1, "", l[3], th))
        }
        val keep = old.size
        roster.removeAll { it.kind == "B" }
        roster.addAll(fresh); roster.addAll(old)
        saveRoster()
        toast("Banco cargado: ${fresh.size} cartas." + if (keep > 0) " $keep de las que habías cargado no aparecen en el banco leído y quedaron al final." else "")
        showRoster()
    }

    private fun showRoster() {
        screen = "roster"
        content.removeAllViews()
        content.addView(label("👥 PLANTEL CHAMPIONS", GOLD, 20f))
        content.addView(infoBox(
            "1) Elegí tu formación.\n2) Tocá cada puesto y cargá al jugador: escribiendo o subiendo la captura de su carta (la app lee los datos).\n" +
            "3) Cargá tus suplentes en el mismo orden del banco: el slot 1 es el de más a la izquierda.\n" +
            "Con esto el auto clicker sabe quién puede jugar dónde. Si cambiás tu equipo, actualizalo."
        ))
        // formaciones
        content.addView(label("FORMACIÓN", GOLD, 14f).apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) } })
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
        for (f in Formations.all.keys) {
            chips.addView(TextView(this).apply {
                text = f; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(if (f == formation) Color.parseColor("#1A1405") else IVORY)
                background = GradientDrawable().apply {
                    setColor(if (f == formation) GOLD else Color.parseColor("#D9000000"))
                    cornerRadius = dp(18).toFloat(); setStroke(dp(1), GOLD)
                }
                setPadding(dp(14), dp(8), dp(14), dp(8))
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) }
                setOnClickListener { formation = f; saveRoster(); showRoster() }
            })
        }
        content.addView(HorizontalScrollView(this).apply { addView(chips); isHorizontalScrollBarEnabled = false })
        // cancha
        val slots = Formations.slots(formation)
        content.addView(PitchView(this, slots, { i ->
            val e = roster.firstOrNull { it.kind == "F" && it.slot == i }
            if (e != null && (e.ovr.isNotBlank() || e.name.isNotBlank())) Pair(e.ovr, e.name) else null
        }) { i -> editPlayer("F", i, slots[i].label, -1) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        // banco
        content.addView(label("SUPLENTES · banco (slot 1 = izquierda)", GOLD, 14f).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        val bench = roster.filter { it.kind == "B" }
        for ((i, b) in bench.withIndex()) {
            row.addView(benchCard(b, i + 1).apply { setOnClickListener { editPlayer("B", -1, "", i) } })
        }
        row.addView(benchCard(null, bench.size + 1).apply { setOnClickListener { editPlayer("B", -1, "", bench.size) } })
        content.addView(HorizontalScrollView(this).apply { addView(row); isHorizontalScrollBarEnabled = false })
        // banco leído por el auto clicker dentro del juego
        content.addView(label("📖 BANCO LEÍDO EN EL JUEGO", GOLD, 14f).apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        })
        val ln = learned()
        if (ln.isEmpty()) {
            content.addView(infoBox("Todavía no se leyó. Cuando el auto clicker abra tu banco para hacer un cambio, lo recorre completo y guarda cada carta (OVR, posición, apellido y su aspecto). Después tocá el botón de abajo para usarlo como tu banco sin escribir nada."))
        } else {
            val lr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
            for ((i, l) in ln.withIndex()) {
                val fl = FrameLayout(this).apply {
                    background = GradientDrawable().apply { setColor(Color.parseColor("#E61A1A1A")); cornerRadius = dp(8).toFloat(); setStroke(dp(1), GOLD) }
                    layoutParams = LinearLayout.LayoutParams(dp(58), dp(78)).apply { rightMargin = dp(6) }
                }
                cardImage(l[4])?.let { bm -> fl.addView(ImageView(this).apply { setImageBitmap(bm); scaleType = ImageView.ScaleType.CENTER_CROP }, FrameLayout.LayoutParams(-1, -1)) }
                fl.addView(TextView(this).apply {
                    text = (i + 1).toString() + "\n" + (if (l[1] == "?") "?" else l[0] + " " + l[1]); textSize = 9f; setTextColor(IVORY)
                    setBackgroundColor(Color.parseColor("#99000000")); setPadding(dp(3), dp(1), dp(3), dp(1))
                }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM))
                lr.addView(fl)
            }
            content.addView(HorizontalScrollView(this).apply { addView(lr); isHorizontalScrollBarEnabled = false })
        }
        content.addView(goldButton("📖 USAR ESTE BANCO COMO MIS SUPLENTES") { useLearned() })
        content.addView(goldButton(L.t("back")) { saveRoster(); showHome() })
    }

    private fun showChannels() {
        screen = "channels"
        content.removeAllViews()
        content.addView(label(L.t("btn_channels"), GOLD, 20f))
        content.addView(infoBox(L.t("ch_info")))
        for ((name, url) in channels) {
            content.addView(goldButton(name) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast(url) }
            })
        }
        content.addView(goldButton(L.t("back")) { showHome() })
    }

    private fun showSearch() {
        screen = "search"
        content.removeAllViews()
        content.addView(label(L.t("btn_search"), GOLD, 20f))
        content.addView(infoBox(L.t("search_info")))
        for (i in 0..2) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = box()
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            }
            val found = prefs.getBoolean("t${i}_found", false)
            card.addView(label(L.t("slot") + (i + 1) + (if (found) L.t("found") else ""), if (found) GREEN else GOLD, 16f))
            val uri = prefs.getString("t${i}_uri", null)
            if (uri != null) {
                try {
                    val bmp = contentResolver.openInputStream(Uri.parse(uri)).use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })
                    }
                    if (bmp != null) card.addView(ImageView(this).apply {
                        setImageBitmap(bmp)
                        adjustViewBounds = true
                        layoutParams = LinearLayout.LayoutParams(-1, dp(140)).apply { topMargin = dp(6) }
                    })
                } catch (e: Exception) { }
            }
            val name = EditText(this).apply {
                hint = L.t("name_hint"); setText(prefs.getString("t${i}_name", ""))
                setTextColor(IVORY); setHintTextColor(Color.GRAY); isSingleLine = true
            }
            val ovr = EditText(this).apply {
                hint = L.t("ovr_hint"); setText(prefs.getString("t${i}_ovr", ""))
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(IVORY); setHintTextColor(Color.GRAY)
            }
            nameEdits[i] = name; ovrEdits[i] = ovr
            card.addView(name); card.addView(ovr)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(goldButton(L.t("upload")) {
                persistEdits()
                val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                }
                startActivityForResult(it, 10 + i)
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) } })
            row.addView(goldButton(L.t("remove")) {
                persistEdits()
                prefs.edit().remove("t${i}_name").remove("t${i}_ovr").remove("t${i}_uri").remove("t${i}_found").apply()
                PickerService.instance?.reloadTargets()
                showSearch()
            }.apply { layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f) })
            card.addView(row)
            content.addView(card)
        }
        content.addView(goldButton("💾 " + L.t("save")) {
            persistEdits()
            val e = prefs.edit()
            for (i in 0..2) e.putBoolean("t${i}_found", false)
            e.apply()
            PickerService.instance?.reloadTargets()
            toast(L.t("saved"))
            showSearch()
        })
        content.addView(goldButton(L.t("back")) { persistEdits(); showHome() })
    }

    private fun persistEdits() {
        val e = prefs.edit()
        for (i in 0..2) {
            nameEdits[i]?.let { e.putString("t${i}_name", it.text.toString().trim()) }
            ovrEdits[i]?.let { e.putString("t${i}_ovr", it.text.toString().trim()) }
        }
        e.apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) { rosterResult(requestCode, resultCode, data); return }
        val uri = data?.data
        if (requestCode !in 10..12 || resultCode != RESULT_OK || uri == null) return
        val slot = requestCode - 10
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        prefs.edit().putString("t${slot}_uri", uri.toString()).putBoolean("t${slot}_found", false).apply()
        toast(L.t("reading"))
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            recognizer.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { text ->
                    val (n, o) = Search.extract(text)
                    if (n.isEmpty()) toast(L.t("read_fail"))
                    prefs.edit().putString("t${slot}_name", n).putString("t${slot}_ovr", o?.toString() ?: "").apply()
                    PickerService.instance?.reloadTargets()
                    showSearch()
                }
                .addOnFailureListener { toast(L.t("read_fail")); showSearch() }
        } catch (e: Exception) {
            toast(L.t("read_fail")); showSearch()
        }
    }
}
