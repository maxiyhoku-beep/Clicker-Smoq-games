package com.ras.autopicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.random.Random

class PickerService : AccessibilityService() {

    companion object { var instance: PickerService? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val EMERALD = Color.parseColor("#2ECC71")
    private val RED = Color.parseColor("#E53935")

    // Posiciones por defecto (fracción de pantalla) medidas en tus capturas
    private val cardDefaults = arrayOf(
        floatArrayOf(0.274f, 0.26f),
        floatArrayOf(0.725f, 0.26f),
        floatArrayOf(0.500f, 0.60f),
        floatArrayOf(0.500f, 0.43f)
    )
    private val nextDefault = floatArrayOf(0.739f, 0.752f)
    private val sellDefault = floatArrayOf(0.261f, 0.752f)

    // Posiciones por defecto del modo PACKS (fracción de pantalla, medidas en las capturas EN/ES)
    private val BLUE = Color.parseColor("#42A5F5")
    private val skipDefault = floatArrayOf(0.500f, 0.720f)
    private fun pNextDefault() = if (L.lang == "en") floatArrayOf(0.619f, 0.720f) else floatArrayOf(0.621f, 0.720f)
    private fun pSellDefault() = when {
        pmode == "sm" -> floatArrayOf(0.500f, 0.721f)
        L.lang == "en" -> floatArrayOf(0.257f, 0.721f)
        else -> floatArrayOf(0.244f, 0.721f)
    }
    private fun pSellKey() = if (pmode == "sm") "ps_sm" else "ps_sa"

    // Tiempos (ms): no dependen del idioma del juego
    private val CARD_TO_BUTTON = 650L
    private val SELL_TO_NEXT = 550L
    private val AFTER_NEXT = 900L
    private val STUCK_MS = 3500L
    private val CONFIRM_GAP = 450L      // espera entre la lectura y su confirmación
    private val MAX_CONFIRM = 6         // máximo de lecturas hasta que se estabilicen las cartas

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prefs by lazy { getSharedPreferences("ras", MODE_PRIVATE) }

    private val cardViews = ArrayList<TextView>()
    private val cardParams = ArrayList<WindowManager.LayoutParams>()
    private lateinit var nextView: TextView
    private lateinit var sellView: TextView
    private lateinit var skipV: TextView      // modo PACKS: puntero de Skip/Saltar
    private lateinit var psellV: TextView     // modo PACKS: puntero de vender (todo o repetidas)
    private lateinit var pnextV: TextView     // modo PACKS: puntero de Siguiente pack
    private lateinit var saBtn: TextView
    private lateinit var smBtn: TextView
    private val extraParams = ArrayList<WindowManager.LayoutParams>()
    private lateinit var panel: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var eyeBtn: TextView
    private lateinit var offBtn: TextView
    private lateinit var moneyBtn: TextView
    private lateinit var addBtn: TextView
    private lateinit var remBtn: TextView
    private lateinit var info: LinearLayout     // contador de picks + cronómetro
    private lateinit var pausedLbl: TextView
    // Estadísticas: una fila para PICKS y otra para PACKS (cada una con su ícono, contador y tiempo)
    private lateinit var kRow: LinearLayout
    private lateinit var kCountTv: TextView
    private lateinit var kTimeTv: TextView
    private lateinit var pRow: LinearLayout
    private lateinit var cRow: LinearLayout
    private lateinit var cTimeTv: TextView
    private lateinit var cRow2: LinearLayout
    private lateinit var winTv: TextView
    private lateinit var lossTv: TextView
    private lateinit var pCountTv: TextView
    private lateinit var pTimeTv: TextView
    private var wakeLock: PowerManager.WakeLock? = null
    private var fgOn = false
    private var tick = 0

    var running = false
        private set
    /** Contadores y cronómetros SEPARADOS: 0 = picks, 1 = packs. */
    private val cnt = IntArray(3)
    private val acc = LongArray(3)
    private fun mi() = when (mode) { "packs" -> 1; "champions" -> 2; else -> 0 }
    val packs: Int get() = cnt[mi()]
    fun statCount(i: Int): Int = cnt[i]
    fun statTime(i: Int): String = fmtTime(elapsedMs(i))
    private var wins = 0
    private var losses = 0
    private fun resetStats() { cnt.fill(0); acc.fill(0L); wins = 0; losses = 0 }
    var overlayShown = false
        private set
    var mode = ""              // "", "picks" o "packs"
        private set
    private var pmode = ""     // "", "sa" o "sm" (solo en modo packs)
    private var phase = 0              // PICKS: 0 = elegir carta, 1 = esperando la pantalla de resultado
    private var phaseSince = 0L
    private var wantSell = false
    private var lastSkipTap = 0L
    private var lastSellTap = 0L
    private var lastNextTap = 0L
    private var hidden = false
    private var lastAction = 0L
    private var sizePx = 0
    private var targets: List<Search.Target> = emptyList()

    private var sellOn: Boolean
        get() = prefs.getBoolean("sell", false)
        set(v) { prefs.edit().putBoolean("sell", v).apply() }

    private class CardRead(val ovr: Int?, val isNew: Boolean, val rect: Rect, val tx: Int = -1, val ty: Int = -1)

    /**
     * Unidad de tamaño del PANEL: depende solo del ancho real de la pantalla en píxeles,
     * nunca del DPI. Así el panel mide lo mismo con cualquier DPI (auto o manual).
     */
    private fun unit(): Float = minOf(screenW(), screenH()) / 400f
    private fun dp(v: Int) = (v * unit()).toInt()
    private fun sp(v: Float) = v * unit()   // texto en píxeles (no cambia con DPI ni con la fuente del sistema)

    // ---------- DPI: tamaño de punteros + reubicación automática ----------
    private var curSys = 0
    /** DPI (densidad) que Android usa ahora mismo para dibujar la pantalla. NO es el ppi físico. */
    private fun sysDpi(): Int = (if (curSys > 0) curSys else Dpi.detect(this)).coerceIn(100, 800)
    /** DPI que usa la app: el que pusiste a mano o, si no hay, el detectado. */
    private fun effectiveDpi(): Int = sysDpi()
    private fun baseDpi(): Int { val b = prefs.getInt("base_dpi", 0); return if (b in 100..800) b else effectiveDpi() }
    private fun layoutDpi(): Int { val l = prefs.getInt("layout_dpi", 0); return if (l in 100..800) l else baseDpi() }
    private fun autoAdj() = prefs.getBoolean("autoadj", true)
    private fun zoomFrac(v: Float, k: Float) = (0.5f + (v - 0.5f) * k).coerceIn(0.04f, 0.96f)
    private val posKeys = listOf("c0", "c1", "c2", "c3", "n", "s", "k", "ps_sa", "ps_sm", "pn")

    /**
     * Factor de los PUNTEROS: crecen/achican solo un poco con el DPI (0,85x a 1,25x),
     * tomando como 1,0 el DPI que tenía el celular la primera vez que se usó la app.
     */
    private fun pointerScale(): Float =
        Math.pow(effectiveDpi().toDouble() / baseDpi(), 0.35).toFloat().coerceIn(0.85f, 1.25f)
    private fun pointerPx() = (dp(40) * pointerScale()).toInt()

    /**
     * Si el DPI cambió, mueve los punteros guardados: la interfaz del juego se agranda o achica
     * alrededor del centro de la pantalla, así que cada puntero se aleja o acerca del centro
     * en la misma proporción (nuevo DPI / DPI anterior).
     */
    private fun syncLayoutDpi() {
        val eff = effectiveDpi()
        if (!prefs.contains("base_dpi")) { prefs.edit().putInt("base_dpi", eff).putInt("layout_dpi", eff).apply(); return }
        val old = layoutDpi()
        if (old == eff) return
        val e = prefs.edit()
        if (autoAdj()) {
            val k = (eff.toFloat() / old).coerceIn(0.4f, 2.5f)
            for (key in posKeys) if (prefs.contains("x_$key") && prefs.contains("y_$key")) {
                e.putFloat("x_$key", zoomFrac(prefs.getFloat("x_$key", 0.5f), k))
                e.putFloat("y_$key", zoomFrac(prefs.getFloat("y_$key", 0.5f), k))
            }
        }
        e.putInt("layout_dpi", eff).apply()
    }

    /** Revisa si el DPI del sistema cambió desde la última vez y, si es así, reubica y redimensiona. */
    fun recheckDpi() {
        if (!::wm.isInitialized) return
        val d = Dpi.detect(this)
        if (d != curSys) { curSys = d; applyDpi() }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        val d = Dpi.detect(this)
        if (d > 0 && d != curSys) { curSys = d; handler.postDelayed({ applyDpi() }, 400) }
    }

    private fun now() = SystemClock.uptimeMillis()
    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun ring(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(maxOf(2, dp(3)), color)
    }

    private fun oval(fill: Int, stroke: Int?) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill); if (stroke != null) setStroke(dp(2), stroke)
    }

    override fun onServiceConnected() {
        instance = this
        L.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        curSys = Dpi.detect(this)
        if (prefs.getInt("dpi_model", 0) < 2) {
            // Versiones viejas guardaban un DPI escrito a mano que bloqueaba la detección automática
            prefs.edit().remove("dpi").remove("base_dpi").remove("layout_dpi").putInt("dpi_model", 2).apply()
        }
        syncLayoutDpi()
        sizePx = pointerPx()
        Search.createChannel(this)
        val n = prefs.getInt("cards", 3).coerceIn(1, 4)
        for (i in 0 until n) addCardPointer()
        nextView = makePointer("N", EMERALD, "n", nextDefault)
        sellView = makePointer("$", RED, "s", sellDefault)
        skipV = makePointer("S", BLUE, "k", skipDefault)
        psellV = makePointer("$", RED, "ps_sa", pSellDefault()) { pSellKey() }
        pnextV = makePointer("N", EMERALD, "pn", pNextDefault())
        buildPanel()
        applyVisibility()
        updatePanel()
        targets = Search.load(this)
        startFg()
    }

    // ---------- punteros ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(v: View, p: WindowManager.LayoutParams, onDrop: () -> Unit) {
        var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = p.x - e.rawX; dy = p.y - e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (e.rawX + dx).toInt(); p.y = (e.rawY + dy).toInt(); moved = true
                    wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> if (moved) onDrop() else v.performClick()
            }
            true
        }
    }

    private fun makePointer(label: String, color: Int, key: String, def: FloatArray, dropKey: (() -> String)? = null): TextView {
        val p = overlayParams(sizePx, sizePx, 0, 0)
        val v = TextView(this).apply {
            text = label; setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(11f) * pointerScale()); gravity = Gravity.CENTER
            setTextColor(IVORY); background = ring(color)
            tag = key
        }
        makeDraggable(v, p) { savePos(dropKey?.invoke() ?: key, v) }
        wm.addView(v, p)
        place(v, p, key, def)
        v.visibility = View.GONE   // applyVisibility() decide según el modo
        if (key == "n" || key == "s") extraParams.add(p)
        return v
    }

    private fun addCardPointer() {
        val i = cardViews.size
        val v = makePointer((i + 1).toString(), GOLD, "c$i", cardDefaults[i])
        cardViews.add(v)
        cardParams.add(v.layoutParams as WindowManager.LayoutParams)
    }

    private fun place(v: View, p: WindowManager.LayoutParams, key: String, def: FloatArray) {
        val kd = if (autoAdj()) layoutDpi().toFloat() / baseDpi() else 1f
        val fx = if (prefs.contains("x_$key")) prefs.getFloat("x_$key", def[0]) else zoomFrac(def[0], kd)
        val fy = if (prefs.contains("y_$key")) prefs.getFloat("y_$key", def[1]) else zoomFrac(def[1], kd)
        p.x = (fx * screenW()).toInt() - sizePx / 2
        p.y = (fy * screenH()).toInt() - sizePx / 2
        wm.updateViewLayout(v, p)
    }

    private fun centerOf(v: View): IntArray {
        val p = v.layoutParams as WindowManager.LayoutParams
        if (v.visibility == View.GONE || v.width == 0) return intArrayOf(p.x + sizePx / 2, p.y + sizePx / 2)
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        return intArrayOf(loc[0] + sizePx / 2, loc[1] + sizePx / 2)
    }

    private fun savePos(key: String, v: View) {
        val c = centerOf(v)
        prefs.edit().putFloat("x_$key", c[0].toFloat() / screenW()).putFloat("y_$key", c[1].toFloat() / screenH()).apply()
    }

    private fun pickPointers(): List<TextView> = cardViews + listOf(nextView, sellView)
    private fun packPointers(): List<TextView> = listOf(skipV, psellV, pnextV)
    private fun allPointers(): List<TextView> = pickPointers() + packPointers()

    private fun placeSell() = place(psellV, psellV.layoutParams as WindowManager.LayoutParams, pSellKey(), pSellDefault())

    private fun setPackMode(m: String) {
        if (running) return
        pmode = m
        psellV.text = if (m == "sm") "D" else "$"
        placeSell()
        applyVisibility()
        updatePanel()
        toast(L.t(if (m == "sm") "sm_on" else "sa_on"))
    }

    fun resetPositions() {
        val e = prefs.edit()
        for (k in listOf("c0", "c1", "c2", "c3", "n", "s", "k", "ps_sa", "ps_sm", "pn")) e.remove("x_$k").remove("y_$k")
        e.apply()
        for ((i, v) in cardViews.withIndex()) place(v, cardParams[i], "c$i", cardDefaults[i])
        place(nextView, nextView.layoutParams as WindowManager.LayoutParams, "n", nextDefault)
        place(sellView, sellView.layoutParams as WindowManager.LayoutParams, "s", sellDefault)
        place(skipV, skipV.layoutParams as WindowManager.LayoutParams, "k", skipDefault)
        placeSell()
        place(pnextV, pnextV.layoutParams as WindowManager.LayoutParams, "pn", pNextDefault())
    }

    /** Aplica el DPI elegido: agranda/achica un poco los punteros; el panel NO cambia de tamaño. */
    fun applyDpi() {
        if (!::wm.isInitialized) return
        // No se detiene el auto-pick ni el cronómetro: solo se reubica y se redimensiona
        syncLayoutDpi()
        sizePx = pointerPx()
        for (v in allPointers()) {
            val pp = v.layoutParams as WindowManager.LayoutParams
            pp.width = sizePx; pp.height = sizePx
            v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(11f) * pointerScale())
            wm.updateViewLayout(v, pp)
        }
        for ((i, v) in cardViews.withIndex()) place(v, cardParams[i], "c$i", cardDefaults[i])
        place(nextView, nextView.layoutParams as WindowManager.LayoutParams, "n", nextDefault)
        place(sellView, sellView.layoutParams as WindowManager.LayoutParams, "s", sellDefault)
        place(skipV, skipV.layoutParams as WindowManager.LayoutParams, "k", skipDefault)
        placeSell()
        place(pnextV, pnextV.layoutParams as WindowManager.LayoutParams, "pn", pNextDefault())
        try { wm.removeView(panel) } catch (e: Exception) { }
        buildPanel()
        applyVisibility()
        updatePanel()
    }

    private fun setTouchable(t: Boolean) {
        val base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        for (v in allPointers()) {
            val p = v.layoutParams as WindowManager.LayoutParams
            p.flags = if (t) base else base or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(v, p)
        }
    }

    private fun applyVisibility() {
        val picksOn = overlayShown && mode == "picks"
        val packsOn = overlayShown && mode == "packs" && pmode.isNotEmpty()
        for (v in pickPointers()) v.visibility = when {
            !picksOn -> View.GONE
            hidden -> View.INVISIBLE
            else -> View.VISIBLE
        }
        for (v in packPointers()) v.visibility = when {
            !packsOn -> View.GONE
            hidden -> View.INVISIBLE
            else -> View.VISIBLE
        }
        panel.visibility = if (overlayShown) View.VISIBLE else View.GONE
    }

    // ---------- panel ----------
    private fun roundBtn(label: String, size: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(16f)); gravity = Gravity.CENTER; setTextColor(IVORY)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { leftMargin = dp(6) }
    }

    private fun buildPanel() {
        val p = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(8), dp(90))
        // Mantiene la pantalla encendida mientras el panel está visible (evita pausas por ahorro de energía)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6000000")); cornerRadius = dp(28).toFloat(); setStroke(dp(2), GOLD)
            }
        }
        playBtn = roundBtn("▶", 44) { if (running) stop() else start() }.apply {
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(20f))
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        eyeBtn = roundBtn("👁", 38) { togglePointers() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        offBtn = roundBtn("X", 38) { closeOverlay() }.apply { background = oval(Color.TRANSPARENT, RED) }
        moneyBtn = roundBtn("💲", 38) {
            sellOn = !sellOn
            toast(L.t(if (sellOn) "sell_on" else "sell_off"))
            updatePanel()
        }
        addBtn = roundBtn("➕", 38) { addCard() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        remBtn = roundBtn("➖", 38) { removeCard() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        saBtn = roundBtn("SA", 38) { setPackMode("sa") }.apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        smBtn = roundBtn("SM", 38) { setPackMode("sm") }.apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        // Estadísticas: [ícono del pick] cantidad  [reloj] tiempo
        pausedLbl = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(10f)); setTextColor(GOLD) }
        fun statsRow(iconRes: Int, iw: Int, ih: Int): Triple<LinearLayout, TextView, TextView> {
            val count = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTextColor(IVORY); setPadding(dp(5), 0, dp(10), 0); setSingleLine(true) }
            val time = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTextColor(IVORY); setPadding(dp(5), 0, 0, 0); typeface = android.graphics.Typeface.MONOSPACE; setSingleLine(true); minWidth = dp(46) }
            val icon = ImageView(this).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(iw), dp(ih))
            }
            val clock = ImageView(this).apply {
                setImageResource(R.drawable.ic_clock)
                layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(icon); addView(count); addView(clock); addView(time)
            }
            return Triple(row, count, time)
        }
        val k = statsRow(R.drawable.ic_pack, 18, 25)          // PICKS: ícono original
        kRow = k.first; kCountTv = k.second; kTimeTv = k.third
        val q = statsRow(R.drawable.ic_pack_packs, 22, 32)    // PACKS: ícono de la carta dorada
        pRow = q.first; pCountTv = q.second; pTimeTv = q.third
        cTimeTv = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTextColor(IVORY); setPadding(dp(5), 0, 0, 0); typeface = android.graphics.Typeface.MONOSPACE; setSingleLine(true); minWidth = dp(46) }
        cRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(this@PickerService).apply {
                setImageResource(R.drawable.ic_clock)
                layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
            })
            addView(cTimeTv)
        }
        fun wlTv() = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, sp(13f)); setTextColor(IVORY); setPadding(dp(4), 0, dp(10), 0); typeface = android.graphics.Typeface.MONOSPACE; setSingleLine(true); minWidth = dp(18) }
        winTv = wlTv(); lossTv = wlTv()
        cRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
            addView(ImageView(this@PickerService).apply {
                setImageResource(R.drawable.ic_win); scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
            })
            addView(winTv)
            addView(ImageView(this@PickerService).apply {
                setImageResource(R.drawable.ic_loss); scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
            })
            addView(lossTv)
        }
        info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, 0, 0)
            addView(pausedLbl); addView(kRow); addView(pRow); addView(cRow); addView(cRow2)
        }
        for (v in listOf(playBtn, eyeBtn, offBtn, moneyBtn, addBtn, remBtn, saBtn, smBtn, info)) panel.addView(v)
        makeDraggable(panel, p) {}
        wm.addView(panel, p)
    }

    private fun updatePanel() {
        if (!::panel.isInitialized) return
        playBtn.text = if (running) "■" else "▶"
        playBtn.background = oval(if (running) RED else EMERALD, null)
        val extras = if (running || mode != "picks") View.GONE else View.VISIBLE
        for (v in listOf(moneyBtn, addBtn, remBtn)) v.visibility = extras
        val pk = if (running || mode != "packs") View.GONE else View.VISIBLE
        for (v in listOf(saBtn, smBtn)) v.visibility = pk
        saBtn.background = if (pmode == "sa") oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        smBtn.background = if (pmode == "sm") oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        saBtn.setTextColor(if (pmode == "sa") Color.BLACK else IVORY)
        smBtn.setTextColor(if (pmode == "sm") Color.BLACK else IVORY)
        info.visibility = View.VISIBLE
        moneyBtn.background = if (sellOn) oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        moneyBtn.alpha = if (sellOn) 1f else 0.5f
        eyeBtn.alpha = if (hidden) 0.45f else 1f
        eyeBtn.visibility = if (mode == "champions") View.GONE else View.VISIBLE
        updateInfo()
    }

    private fun elapsedMs(i: Int): Long = acc[i] + if (running && mi() == i) now() - runStart else 0L

    private fun fmtTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun updateInfo() {
        if (!::pTimeTv.isInitialized) return
        // Solo se muestra la fila del modo activo; no depende de si los punteros están ocultos o no
        kRow.visibility = if (mode == "packs" || mode == "champions") View.GONE else View.VISIBLE
        pRow.visibility = if (mode == "packs") View.VISIBLE else View.GONE
        cRow.visibility = if (mode == "champions") View.VISIBLE else View.GONE
        cRow2.visibility = if (mode == "champions") View.VISIBLE else View.GONE
        cTimeTv.text = fmtTime(elapsedMs(2))
        winTv.text = wins.toString(); lossTv.text = losses.toString()
        kCountTv.text = cnt[0].toString(); kTimeTv.text = fmtTime(elapsedMs(0))
        pCountTv.text = cnt[1].toString(); pTimeTv.text = fmtTime(elapsedMs(1))
        pausedLbl.text = L.t("p_paused")
        pausedLbl.visibility = if (running) View.GONE else View.VISIBLE
    }

    // ---------- anti-freno: servicio en primer plano + wake lock ----------
    private fun startFg() {
        if (fgOn) return
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("ras_run", "RAS Auto-Picker", NotificationManager.IMPORTANCE_LOW)
            )
            val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, "ras_run")
                .setSmallIcon(android.R.drawable.star_big_on)
                .setContentTitle("RAS Auto-Picker")
                .setContentText(L.t("notif_running"))
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(77, n)
            fgOn = true
        } catch (e: Throwable) { }
    }

    private fun stopFg() {
        if (!fgOn) return
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Throwable) { }
        fgOn = false
    }

    private fun acquireWake() {
        try {
            if (wakeLock == null) {
                wakeLock = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ras:autopick")
                    .apply { setReferenceCounted(false) }
            }
            wakeLock?.acquire(120_000L)   // se renueva desde el ticker mientras corre
        } catch (e: Throwable) { }
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Throwable) { }
    }

    fun refreshTexts() { L.load(this); updatePanel() }
    fun reloadTargets() { targets = Search.load(this) }

    private fun addCard() {
        if (cardViews.size >= 4) { toast(L.t("max_ptr")); return }
        addCardPointer()
        prefs.edit().putInt("cards", cardViews.size).apply()
    }

    private fun removeCard() {
        if (cardViews.size <= 1) { toast(L.t("min_ptr")); return }
        val v = cardViews.removeAt(cardViews.size - 1)
        cardParams.removeAt(cardParams.size - 1)
        wm.removeView(v)
        prefs.edit().putInt("cards", cardViews.size).apply()
    }

    fun togglePointers() {
        hidden = !hidden
        applyVisibility()
        updatePanel()
    }

    /** Muestra el panel en modo "picks" o "packs". */
    fun showOverlay(m: String) {
        recheckDpi()
        stop()
        resetStats()      // cada vez que se saca o cambia el panel, los contadores vuelven a cero
        saveOut(emptyList())
        chReset()
        mode = m
        pmode = ""
        hidden = false
        overlayShown = true
        applyVisibility()
        updatePanel()
        startFg()
    }

    /** Cierra panel y app sin quitar el permiso de Accesibilidad. */
    fun closeOverlay() {
        stop()
        resetStats()
        stopFg()
        overlayShown = false
        mode = ""
        pmode = ""
        applyVisibility()
        updatePanel()
        MainActivity.current?.finishAndRemoveTask()
    }

    // ---------- ciclo ----------
    // Estado anti-traba y estadísticas
    private var gen = 0                 // cambia en cada start/stop: descarta callbacks viejos
    private var busy = false            // hay una captura/lectura en curso
    private var lastProgress = 0L       // última vez que el ciclo avanzó
    private var lastShot = 0L           // Android limita las capturas (~3 por segundo)
    private var runStart = 0L
    private var confirmSig: List<Int>? = null   // firma de la última lectura (OVR + NEW de cada carta)
    private var confirmTries = 0

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                updateInfo()
                // Watchdog: si el ciclo no avanzó en 4 s (captura o lectura colgada), lo relanza
                if (now() - lastProgress > 4000) restartLoop()
                // Mantiene despierto el CPU y el servicio en primer plano mientras corre
                if (++tick % 30 == 0) { acquireWake(); startFg() }
            } catch (e: Throwable) { }
            handler.postDelayed(this, 1000)
        }
    }

    private fun start() {
        if (mode == "packs" && pmode.isEmpty()) { toast(L.t("need_mode")); return }
        running = true
        gen++
        busy = false
        confirmSig = null; confirmTries = 0
        phase = 0; wantSell = false
        if (mode == "champions") { chKnownAt = now(); chRedSince = 0L; chInMatch = false; chFinished = false; chStage = 0 }
        lastAction = now(); lastProgress = now()
        runStart = now()
        tick = 0
        startFg(); acquireWake()
        setTouchable(false)
        // En PACKS los punteros quedan encima del texto de los botones (SKIP, VENDER, SIGUIENTE):
        // si se ven, el OCR no puede leerlos. Se vuelven transparentes mientras corre.
        if (mode == "packs") for (v in packPointers()) v.alpha = 0f
        else { nextView.alpha = 0f; sellView.alpha = 0f }
        updatePanel()
        handler.post { step(gen) }
        handler.postDelayed(ticker, 1000)
    }

    private fun stop() {
        if (running) acc[mi()] += now() - runStart
        // en CHAMPIONS, al desactivar el auto clicker el tiempo y los contadores de victorias/derrotas vuelven a cero
        if (mode == "champions") resetStats()
        running = false
        gen++
        busy = false
        releaseWake()
        handler.removeCallbacksAndMessages(null)
        if (::panel.isInitialized) {
            setTouchable(true)
            for (v in allPointers()) v.alpha = 1f
            for (v in cardViews) v.background = ring(GOLD)
            updatePanel()
        }
    }

    private fun restartLoop() {
        gen++
        busy = false
        confirmSig = null; confirmTries = 0
        lastProgress = now()
        val g = gen
        handler.postDelayed({ step(g) }, 150)
    }

    private fun next(ms: Long) {
        if (!running) return
        busy = false
        lastProgress = now()
        val g = gen
        handler.postDelayed({ step(g) }, ms)
    }

    private fun later(ms: Long, action: () -> Unit) {
        val g = gen
        handler.postDelayed({
            if (running && g == gen) {
                // Si algo falla, no dejamos caer el servicio: se relanza el ciclo
                try { action() } catch (e: Throwable) { restartLoop() }
            }
        }, ms)
    }

    private fun step(g: Int) {
        if (!running || g != gen || busy) return
        // Respeta el intervalo mínimo entre capturas (algunos Samsung fallan si es menor)
        val wait = 360 - (now() - lastShot)
        if (wait > 0) { handler.postDelayed({ step(g) }, wait); return }
        busy = true
        lastShot = now()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    if (g != gen) { try { r.hardwareBuffer.close() } catch (e: Exception) {}; return }
                    var bmp: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Throwable) {
                    } finally {
                        try { r.hardwareBuffer.close() } catch (e: Exception) {}
                    }
                    val b = bmp
                    if (b == null) { next(400); return }
                    try {
                        recognizer.process(InputImage.fromBitmap(b, 0))
                            .addOnSuccessListener { t ->
                                if (g != gen) { b.recycle(); return@addOnSuccessListener }
                                try { when (mode) { "packs" -> analyzePacks(t); "champions" -> analyzeChamp(b, t); else -> analyze(b, t) } } catch (e: Throwable) { next(400) }
                                b.recycle()
                            }
                            .addOnFailureListener { b.recycle(); if (g == gen) next(400) }
                    } catch (e: Throwable) {
                        b.recycle(); next(400)
                    }
                }
                override fun onFailure(errorCode: Int) { if (g == gen) next(450) }
            })
        } catch (e: Throwable) {
            next(500)
        }
    }

    /** Cierra el Bonus tocando OK/ACEPTAR donde esté. Devuelve true si tocó. */
    private fun handleBonus(lines: List<Text.Line>, els: List<Text.Element>): Boolean {
        if (lines.none { val n = Search.norm(it.text); n == "BONUS" || n == "BONO" }) return false
        val okWords = setOf("OK", "ACEPTAR")
        val box = lines.firstOrNull { Search.norm(it.text) in okWords }?.boundingBox
            ?: els.firstOrNull { Search.norm(it.text) in okWords }?.boundingBox
            ?: return false
        tap(box.exactCenterX(), box.exactCenterY())
        lastAction = now()
        next(900)
        return true
    }

    /** Caja de la primera línea (o palabra) del OCR que cumple la condición. */
    private fun boxOf(lines: List<Text.Line>, els: List<Text.Element>, match: (String) -> Boolean): Rect? {
        lines.firstOrNull { it.boundingBox != null && match(Search.norm(it.text)) }?.boundingBox?.let { return it }
        return els.firstOrNull { it.boundingBox != null && match(Search.norm(it.text)) }?.boundingBox
    }

    /** Toca el texto del botón si se lo ve en pantalla (no depende del DPI); si no, usa el puntero. */
    private fun tapSmart(box: Rect?, fallback: View) {
        if (box != null && autoAdj()) tap(box.exactCenterX(), box.exactCenterY()) else tapView(fallback)
    }

    private fun hasAny(lines: List<Text.Line>, els: List<Text.Element>, keys: List<String>): Boolean =
        lines.any { l -> val n = Search.norm(l.text); keys.any { n.contains(it) } } ||
        els.any { e -> val n = Search.norm(e.text); keys.any { n.contains(it) } }

    /**
     * Modo PACKS. Pantallas (EN / ES):
     *  1) animación: SKIP / SALTAR  -> 2 toques en el puntero Skip
     *  2) resultados: SELL ALL, SELL DUPLICATES, SAVE ALL / VENDER TODO, VENDER DUPLICADOS, GUARDAR TODO
     *     -> toca el puntero de vender (SA = todo, SM = repetidas)
     *  3) NEXT PACK / SIGUIENTE PACK -> toca el puntero de siguiente pack
     * Además cierra el Bonus igual que el auto-picker.
     */
    private fun analyzePacks(t: Text) {
        if (!running) return
        val lines = t.textBlocks.flatMap { it.lines }
        val els = lines.flatMap { it.elements }
        if (handleBonus(lines, els)) return
        val t0 = now()

        when {
            hasAny(lines, els, listOf("SKIP", "SALTAR")) -> {
                if (t0 - lastSkipTap < 1300) { next(350); return }
                lastSkipTap = t0
                val bSkip = boxOf(lines, els) { it.contains("SKIP") || it.contains("SALTAR") }
                tapSmart(bSkip, skipV)
                later(320) { tapSmart(bSkip, skipV); lastAction = now() }
                lastAction = now()
                next(1300)
            }
            hasAny(lines, els, listOf("SELL", "VENDER", "SAVE", "GUARDAR")) -> {
                if (t0 - lastSellTap < 1200) { next(350); return }
                lastSellTap = t0
                val bSell = boxOf(lines, els) { n ->
                    if (pmode == "sm") n.contains("DUPLIC")
                    else (n.contains("SELL") || n.contains("VENDER")) && (n.contains("ALL") || n.contains("TODO")) && !n.contains("DUPLIC")
                }
                tapSmart(bSell, psellV)
                lastAction = now()
                next(900)
            }
            hasAny(lines, els, listOf("NEXT", "SIGUIENTE")) -> {
                if (t0 - lastNextTap < 1500) { next(350); return }
                lastNextTap = t0
                tapSmart(boxOf(lines, els) { it.contains("NEXT") || it.contains("SIGUIENTE") }, pnextV)
                cnt[mi()]++
                updateInfo()
                lastAction = now()
                next(1100)
            }
            else -> next(300)
        }
    }

    private fun analyze(bmp: Bitmap, t: Text) {
        if (!running) return
        val lines = t.textBlocks.flatMap { it.lines }
        val els = lines.flatMap { it.elements }

        // 1) Bonus: tocar OK donde esté
        if (handleBonus(lines, els)) return

        // 1b) Ya elegí una carta: tocar VENDER / SIGUIENTE PACK leyendo el texto de los botones
        if (phase == 1 && afterPick(lines, els)) return

        // 2) Pantalla de cartas (por los punteros; si no coinciden, ubica las cartas por su OVR)
        var reads: List<CardRead> = cardViews.indices.map { readCard(it, bmp, els) }
        if (!(reads.isNotEmpty() && reads.all { it.ovr != null }) && autoAdj()) {
            val auto = autoReads(bmp, els)
            if (auto != null) reads = auto
        }
        if (reads.isNotEmpty() && reads.all { it.ovr != null }) {
            // Confirmación: solo elige cuando DOS lecturas seguidas (separadas ~0,45 s) coinciden
            // en el OVR y en el cartel NEW de TODAS las cartas. Así las animaciones de entrada
            // terminan antes de decidir y no se elige con una lectura a medias.
            val sig = reads.map { (it.ovr ?: 0) * 2 + if (it.isNew) 1 else 0 }
            if (sig != confirmSig && confirmTries < MAX_CONFIRM) {
                confirmSig = sig
                confirmTries++
                next(CONFIRM_GAP); return
            }
            confirmSig = null; confirmTries = 0
            var chosen = -1
            var hit: Search.Target? = null
            val pending = targets.filter { !it.found }
            loop@ for (i in reads.indices) {
                val r = reads[i]
                val texts = lines.filter { l ->
                    val b = l.boundingBox
                    b != null && r.rect.contains(b.centerX(), b.centerY())
                }.map { it.text }
                for (tg in pending) {
                    if (tg.ovr != null && tg.ovr != r.ovr) continue
                    if (texts.any { Search.nameMatches(tg.name, it) }) { chosen = i; hit = tg; break@loop }
                }
            }
            if (chosen < 0) chosen = choose(reads)
            flash(chosen)
            val cr = reads[chosen]
            if (cr.tx >= 0) tap(cr.tx.toFloat(), cr.ty.toFloat()) else tapView(cardViews[chosen])
            lastAction = now()

            val tg = hit
            if (tg != null) {
                tg.found = true
                Search.setFound(this, tg.slot)
                Search.notify(this, 100 + tg.slot, L.t("notif_found"), tg.name)
                if (targets.all { it.found }) {
                    cnt[mi()]++
                    later(700) {
                        Search.notify(this, 200, L.t("notif_all"), "")
                        closeOverlay()
                    }
                    return
                }
            }

            // El pick se cuenta cuando se toca SIGUIENTE PACK (pick realmente abierto)
            phase = 1
            phaseSince = now()
            wantSell = sellOn && !reads[chosen].isNew && tg == null
            next(CARD_TO_BUTTON)
            return
        }

        // Si la pantalla no es de cartas, la confirmación anterior ya no vale
        confirmSig = null; confirmTries = 0

        // 3) Respaldo: si quedó trabado en otra pantalla, tocar NEXT PACK
        if (now() - lastAction > STUCK_MS) {
            tapView(nextView)
            lastAction = now()
            next(AFTER_NEXT); return
        }
        next(300)
    }

    /**
     * Después de elegir la carta: busca en pantalla los botones VENDER / SELL y SIGUIENTE PACK / NEXT PACK
     * y toca su texto (no depende del DPI ni de los punteros). Si no los encuentra en ~3 s, usa los punteros.
     */
    private fun afterPick(lines: List<Text.Line>, els: List<Text.Element>): Boolean {
        val nextBox = boxOf(lines, els) { it.contains("NEXTPACK") || it.contains("SIGUIENTEPACK") }
        val sellBox = boxOf(lines, els) {
            (it.startsWith("SELL") || it.startsWith("VENDER")) && !it.contains("DUPLIC") && !it.contains("ALL") && !it.contains("TODO")
        }
        val elapsed = now() - phaseSince
        if (wantSell && sellBox != null) {
            tap(sellBox.exactCenterX(), sellBox.exactCenterY())
            wantSell = false; lastAction = now(); next(SELL_TO_NEXT)
            return true
        }
        if (nextBox != null) {
            if (wantSell && elapsed < 1500) { next(250); return true }
            if (wantSell) {
                tapView(sellView); wantSell = false; lastAction = now(); next(SELL_TO_NEXT)
                return true
            }
            tap(nextBox.exactCenterX(), nextBox.exactCenterY())
            cnt[mi()]++; updateInfo()
            phase = 0; lastAction = now(); next(AFTER_NEXT)
            return true
        }
        if (elapsed > 3200) {
            if (wantSell) {
                tapView(sellView); wantSell = false; lastAction = now(); next(SELL_TO_NEXT)
                return true
            }
            tapView(nextView)
            cnt[mi()]++; updateInfo()
            phase = 0; lastAction = now(); next(AFTER_NEXT)
            return true
        }
        next(300)
        return true
    }

    /**
     * Respaldo sin punteros: ubica cada carta por su OVR (el número grande de arriba a la izquierda).
     * Solo se usa si la cantidad de OVR grandes coincide con la cantidad de punteros de carta.
     */
    private fun autoReads(bmp: Bitmap, els: List<Text.Element>): List<CardRead>? {
        val n = cardViews.size
        if (n < 2) return null
        val nums = els.filter { e ->
            val s = e.text.trim()
            e.boundingBox != null && s.length == 2 && s.all { it.isDigit() } && s.toInt() in 40..99
        }
        if (nums.size < n) return null
        val maxH = nums.maxOf { it.boundingBox!!.height() }
        val big = nums.filter { it.boundingBox!!.height() >= maxH * 0.8f }
        if (big.size != n) return null
        val bw = (bmp.width * 0.28f).toInt()
        val bh = (bmp.height * 0.17f).toInt()
        return big.sortedWith(compareBy<Text.Element>({ it.boundingBox!!.top / 60 }, { it.boundingBox!!.left })).map { e ->
            val b = e.boundingBox!!
            val left = b.left - bw * 12 / 100
            val top = b.top - bh * 10 / 100
            val rect = Rect(left, top, left + bw, top + bh)
            val newZone = Rect(left + bw * 58 / 100, top, left + bw, top + bh * 38 / 100)
            val newText = els.any { x ->
                val bb = x.boundingBox
                val nn = Search.norm(x.text)
                bb != null && (nn == "NEW" || nn == "NUEVO") && newZone.contains(bb.centerX(), bb.centerY())
            }
            CardRead(e.text.trim().toInt(), newText || redPixels(bmp, newZone) >= 60, rect, b.centerX(), b.centerY())
        }
    }

    private fun readCard(i: Int, bmp: Bitmap, els: List<Text.Element>): CardRead {
        val c = centerOf(cardViews[i])
        val bw = (bmp.width * 0.28f).toInt()
        val bh = (bmp.height * 0.17f).toInt()
        val left = c[0] - bw / 2; val top = c[1] - bh / 2
        val rect = Rect(left, top, left + bw, top + bh)
        val ovrZone = Rect(left, top, left + bw * 50 / 100, top + bh * 42 / 100)
        val newZone = Rect(left + bw * 58 / 100, top, left + bw, top + bh * 38 / 100)

        val ovr = els.filter { e ->
            val b = e.boundingBox
            val s = e.text.trim()
            b != null && s.length == 2 && s.all { it.isDigit() } && ovrZone.contains(b.centerX(), b.centerY())
        }.minByOrNull { it.boundingBox!!.top }?.text?.trim()?.toInt()

        val newText = els.any { e ->
            val b = e.boundingBox
            val n = Search.norm(e.text)
            b != null && (n == "NEW" || n == "NUEVO") && newZone.contains(b.centerX(), b.centerY())
        }
        return CardRead(ovr, newText || redPixels(bmp, newZone) >= 60, rect)
    }

    private fun redPixels(bmp: Bitmap, z: Rect): Int {
        val r0 = Rect(z); if (!r0.intersect(0, 0, bmp.width, bmp.height)) return 0
        var n = 0
        var y = r0.top
        while (y < r0.bottom) {
            var x = r0.left
            while (x < r0.right) {
                val p = bmp.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (r > 170 && g < 120 && b < 110 && r - g > 80) n++
                x += 2
            }
            y += 2
        }
        return n
    }

    private fun choose(reads: List<CardRead>): Int {
        val idx = reads.indices.toList()
        val news = idx.filter { reads[it].isNew }
        val pool = if (news.isNotEmpty()) news else idx
        val best = pool.maxOf { reads[it].ovr!! }
        val tied = pool.filter { reads[it].ovr == best }
        return tied[Random.nextInt(tied.size)]
    }

    private fun flash(i: Int) {
        val v = cardViews[i]
        v.background = ring(EMERALD)
        handler.postDelayed({ if (i < cardViews.size) cardViews[i].background = ring(GOLD) }, 400)
    }

    private fun tapView(v: View) {
        val c = centerOf(v)
        tap(c[0].toFloat(), c[1].toFloat())
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(g, null, null)
    }

    // =====================================================================
    //                            MODO CHAMPIONS
    // =====================================================================
    private class Pc(val ovr: Int, val pos: String, val tx: Int, val ty: Int, val st: Int) {
        /** st: 0 normal, 1 una amarilla, 2 lesión, 3 roja, 4 doble amarilla */
        val bad: Boolean get() = st >= 2
        val out: Boolean get() = st == 3 || st == 4
    }
    /** Sancionado que salió: ovr/pos, quién entró (sOvr/sPos), partido en que salió (c), slot del banco (idx) y lugar en el campo (fx,fy en milésimas). */
    private class Out(
        val ovr: Int, val pos: String, val sOvr: Int, val sPos: String,
        var c: Int, val idx: Int, val fx: Int, val fy: Int, var tries: Int, val inj: Boolean
    )
    private class Cand(val ovr: Int, val pos: String, val st: Int, val page: Int)

    private val POS = setOf(
        "POR", "DFC", "DFI", "DFD", "LI", "LD", "CAI", "CAD", "MCD", "MC", "MCO",
        "MI", "MD", "MDI", "MDD", "MVI", "MVD", "MP", "EI", "ED", "DC", "SD", "SDI"
    )

    private var chKnownAt = 0L
    private var chRedSince = 0L
    private var chTapAt = 0L
    private var chBackAt = 0L
    private var chNeedFinish = false
    private var chRun = 0
    private var chInMatch = false
    private var chFinished = false
    private var chMinute = -1
    private var chMinuteAt = 0L
    private var chEventosAt = 0L
    private var chMatchNo = 0
    private var chMatchTotal = 15
    private var chDoneTaps = 0
    // cambios de jugadores
    private var chStage = 0
    private var chOpAt = 0L
    private var chSquadAt = 0L
    private var chSwaps = 0
    private var chSkip = false
    private var chReturning = false
    private var chRetEntry = -1
    private var chGk = false
    private var chSlotOvr = 0
    private var chSlotPos = ""
    private var chSlotOut = false
    private var chSlotX = 0
    private var chSlotY = 0
    private var chWantOvr = 0
    private var chWantPos = ""
    private val chSeen = ArrayList<Cand>()
    private var chAttempts: List<Int> = emptyList()
    private var chAtt = 0
    private var chMiss = 0
    private var chPage = 0
    private var chPrev = ""
    private var chSwipes = 0
    private var chBenchX = 0
    private var chBenchY = 0
    private var chGlowBase = 0
    private var chExact = false
    private var chDone = 0          // partidos ya terminados (según el contador "Partido x/y")
    private var chStartSynced = false
    private var chRetIdx = -1
    private var chBenchIdx = -1
    private var chSlotInj = false
    private var chRetInj = false
    private var chRetNotFound = false
    private var chViewStart = -1
    private var chNav = 0
    private var chRewinding = false
    private var chRewind = 0
    private var chEmpty = 0
    private var chPrevFirst = ""
    private var chSame = 0
    private val chAgg = HashMap<String, ArrayList<Pc>>()
    private var chAggN = 0
    private var chVerTries = 0
    private var chRead2 = false
    private var chPrevView: List<Pc> = emptyList()
    private var chRescan = 0
    private var chRetUnknown = false
    private var chRetStill = false
    private var chRetTries = 0
    private val chBackoff = HashMap<String, Int>()
    private val chFailKeys = HashSet<String>()
    private val chTried = HashSet<Int>()
    private var chCurKey = ""
    private var chLastKey = ""
    private var chRepeat = 0
    private var chScoreL = -1
    private var chScoreR = -1
    private var chSlotFx = 0
    private var chSlotFy = 0

    private fun chReset() {
        chKnownAt = now(); chRedSince = 0L; chTapAt = 0L; chBackAt = 0L
        chNeedFinish = false; chRun = 0; chInMatch = false; chFinished = false
        chMinute = -1; chMatchNo = 0; chStage = 0; chSwaps = 0; chSkip = false
        chReturning = false; chSquadAt = 0L; chDone = 0; chStartSynced = false
        chFailKeys.clear(); chTried.clear(); chLastKey = ""; chRepeat = 0
    }

    private fun outList(): MutableList<Out> {
        val raw = prefs.getString("ch_out", "") ?: ""
        val l = ArrayList<Out>()
        for (e in raw.split(";")) {
            val p = e.split(",")
            if (p.size < 10) continue
            val a = p[0].toIntOrNull(); val c = p[2].toIntOrNull()
            val cc = p[4].toIntOrNull(); val ix = p[5].toIntOrNull()
            val fx = p[6].toIntOrNull(); val fy = p[7].toIntOrNull(); val tr = p[8].toIntOrNull()
            if (a != null && c != null && cc != null && ix != null && fx != null && fy != null && tr != null)
                l.add(Out(a, p[1], c, p[3], cc, ix, fx, fy, tr, p[9] == "1"))
        }
        return l
    }

    private fun saveOut(l: List<Out>) {
        prefs.edit().putString("ch_out", l.joinToString(";") {
            "${it.ovr},${it.pos},${it.sOvr},${it.sPos},${it.c},${it.idx},${it.fx},${it.fy},${it.tries},${if (it.inj) 1 else 0}"
        }).apply()
    }

    /** Slot del banco que se usó la última vez para reemplazar a este jugador del campo (-1 si no hay). */
    private fun prefSlot(ovr: Int, pos: String): Int {
        val raw = prefs.getString("ch_pref", "") ?: ""
        for (e in raw.split(";")) {
            val p = e.split(",")
            if (p.size == 3 && p[0] == ovr.toString() && p[1] == pos) return p[2].toIntOrNull() ?: -1
        }
        return -1
    }

    private fun setPref(ovr: Int, pos: String, idx: Int) {
        val raw = prefs.getString("ch_pref", "") ?: ""
        val l = ArrayList<String>()
        for (e in raw.split(";")) {
            val p = e.split(",")
            if (p.size == 3 && !(p[0] == ovr.toString() && p[1] == pos)) l.add(e)
        }
        l.add("$ovr,$pos,$idx")
        prefs.edit().putString("ch_pref", l.takeLast(40).joinToString(";")).apply()
    }

    /** Marcador grande de arriba ("2:1"): [izquierda, derecha] o null si no se lee. */
    private fun chReadScore(lines: List<Text.Line>, els: List<Text.Element>, W: Int, H: Int): IntArray? {
        val reg = Regex("^(\\d{1,2})\\s*[:;.\\-–]\\s*(\\d{1,2})$")
        fun inside(b: Rect?) = b != null && b.centerY() > H * 0.07f && b.centerY() < H * 0.15f &&
            b.centerX() > W * 0.28f && b.centerX() < W * 0.72f
        for (e in els) {
            if (!inside(e.boundingBox)) continue
            val m = reg.find(e.text.trim()) ?: continue
            return intArrayOf(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }
        for (l in lines) {
            if (!inside(l.boundingBox)) continue
            val m = reg.find(l.text.trim()) ?: continue
            return intArrayOf(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }
        val ds = els.filter { inside(it.boundingBox) && it.text.trim().matches(Regex("^\\d{1,2}$")) }
            .sortedBy { it.boundingBox!!.centerX() }
        if (ds.size == 2 && ds[0].boundingBox!!.centerX() < W * 0.5f && ds[1].boundingBox!!.centerX() > W * 0.5f)
            return intArrayOf(ds[0].text.trim().toInt(), ds[1].text.trim().toInt())
        return null
    }

    private fun goBack() { try { performGlobalAction(GLOBAL_ACTION_BACK) } catch (e: Throwable) { } }
    private fun tapBox(b: Rect) = tap(b.exactCenterX(), b.exactCenterY())

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    /** Desliza el banco de suplentes. revealLeft = true muestra las cartas de la izquierda. */
    private fun chSwipe(w: Int, h: Int, revealLeft: Boolean) {
        val y = h * 0.748f
        // desplazamiento corto y suave: 0,35 del ancho en 600 ms (casi sin impulso)
        if (revealLeft) swipe(w * 0.34f, y, w * 0.69f, y, 600) else swipe(w * 0.69f, y, w * 0.34f, y, 600)
    }

    private fun isRedScreen(bmp: Bitmap): Boolean {
        var n = 0; var tot = 0
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                val p = bmp.getPixel(x, y)
                val r = Color.red(p)
                if (r > 140 && Color.green(p) < r * 0.45f && Color.blue(p) < r * 0.45f) n++
                tot++
                x += 12
            }
            y += 12
        }
        return tot > 0 && n.toFloat() / tot > 0.30f
    }

    /** Mayor bloque de la máscara unido con lo que tenga pegado. Devuelve [minx, maxx, miny, maxy, cantidad]. */
    private fun bigBlob(m: BooleanArray, w: Int, h: Int, pad: Int): IntArray? {
        val seen = BooleanArray(m.size)
        val stack = IntArray(m.size)
        var bestN = 0
        var bx0 = 0; var bx1 = 0; var by0 = 0; var by1 = 0
        for (s in m.indices) {
            if (!m[s] || seen[s]) continue
            var sp = 0
            stack[sp++] = s; seen[s] = true
            var minx = w; var maxx = 0; var miny = h; var maxy = 0; var n = 0
            while (sp > 0) {
                val c = stack[--sp]
                val cx = c % w; val cy = c / w
                n++
                if (cx < minx) minx = cx
                if (cx > maxx) maxx = cx
                if (cy < miny) miny = cy
                if (cy > maxy) maxy = cy
                if (cx > 0 && m[c - 1] && !seen[c - 1]) { seen[c - 1] = true; stack[sp++] = c - 1 }
                if (cx < w - 1 && m[c + 1] && !seen[c + 1]) { seen[c + 1] = true; stack[sp++] = c + 1 }
                if (cy > 0 && m[c - w] && !seen[c - w]) { seen[c - w] = true; stack[sp++] = c - w }
                if (cy < h - 1 && m[c + w] && !seen[c + w]) { seen[c + w] = true; stack[sp++] = c + w }
            }
            if (n > bestN) { bestN = n; bx0 = minx; bx1 = maxx; by0 = miny; by1 = maxy }
        }
        if (bestN == 0) return null
        val x0 = maxOf(0, bx0 - pad); val x1 = minOf(w - 1, bx1 + pad)
        val y0 = maxOf(0, by0 - pad); val y1 = minOf(h - 1, by1 + pad)
        var ux0 = w; var ux1 = 0; var uy0 = h; var uy1 = 0; var total = 0
        for (yy in y0..y1) for (xx in x0..x1) {
            if (m[yy * w + xx]) {
                total++
                if (xx < ux0) ux0 = xx
                if (xx > ux1) ux1 = xx
                if (yy < uy0) uy0 = yy
                if (yy > uy1) uy1 = yy
            }
        }
        return intArrayOf(ux0, ux1, uy0, uy1, total)
    }

    /** Ícono de estado a la derecha del OVR: 0 nada, 1 amarilla, 2 lesión, 3 roja, 4 doble amarilla. */
    private fun chStatus(bmp: Bitmap, cx: Int, cy: Int): Int {
        val W = bmp.width; val H = bmp.height
        val x0 = (cx + W * 0.08f).toInt().coerceIn(0, W - 2)
        val x1 = (cx + W * 0.19f).toInt().coerceIn(x0 + 1, W)
        val y0 = (cy - H * 0.03f).toInt().coerceIn(0, H - 2)
        val y1 = (cy + H * 0.026f).toInt().coerceIn(y0 + 1, H)
        val w = x1 - x0; val h = y1 - y0
        val yel = BooleanArray(w * h); val red = BooleanArray(w * h)
        for (yy in 0 until h) for (xx in 0 until w) {
            val p = bmp.getPixel(x0 + xx, y0 + yy)
            val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
            if (r > 235 && g > 195 && b < 70) yel[yy * w + xx] = true
            else if (r > 170 && g < 70 && b < 70) red[yy * w + xx] = true
        }
        val minBig = (W * H * 0.0003f).toInt()
        val minCross = (W * H * 0.00012f).toInt()
        val rd = bigBlob(red, w, h, 0)
        if (rd != null) {
            val bw = rd[1] - rd[0] + 1; val bh = rd[3] - rd[2] + 1
            val fill = rd[4].toFloat() / (bw * bh)
            if (rd[4] >= minBig && fill >= 0.85f && bh >= bw) return 3
            val ar = bh.toFloat() / bw
            if (rd[4] >= minCross && fill < 0.8f && ar in 0.75f..1.3f && bw < W * 0.06f) {
                // la lesión es una cruz roja sobre un cuadrado blanco
                var white = 0
                for (yy in rd[2]..rd[3]) for (xx in rd[0]..rd[1]) {
                    val c = bmp.getPixel(x0 + xx, y0 + yy)
                    if (Color.red(c) > 215 && Color.green(c) > 215 && Color.blue(c) > 215) white++
                }
                if (white >= 0.3f * bw * bh) return 2
            }
        }
        val yl = bigBlob(yel, w, h, (W * 0.012f).toInt())
        if (yl != null && yl[4] >= minBig) {
            val bw = yl[1] - yl[0] + 1; val bh = yl[3] - yl[2] + 1
            val fill = yl[4].toFloat() / (bw * bh)
            val ar = bh.toFloat() / bw
            if (fill < 0.95f || ar < 1.22f) return 4
            // la segunda amarilla asoma más oscura arriba y a la derecha de la primera: se busca ese borde
            val pad = maxOf(4, (W * 0.015f).toInt())
            var loose = 0
            fun isLoose(px: Int, py: Int): Boolean {
                if (px < 0 || py < 0 || px >= W || py >= H) return false
                val c = bmp.getPixel(px, py)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                return r > 195 && g > 150 && b < 120 && r - b > 90 && !(r > 235 && g > 195 && b < 70)
            }
            for (yy in (y0 + yl[2] - pad)..(y0 + yl[3])) for (xx in (x0 + yl[1] + 1)..(x0 + yl[1] + pad)) if (isLoose(xx, yy)) loose++
            for (yy in (y0 + yl[2] - pad) until (y0 + yl[2])) for (xx in (x0 + yl[0])..(x0 + yl[1] + pad)) if (isLoose(xx, yy)) loose++
            return if (loose > yl[4] * 0.05f) 4 else 1
        }
        return 0
    }

    /** OVR de 2 dígitos tolerando confusiones típicas del OCR (O/0, I/1, S/5, B/8). */
    private fun chOvr(raw: String): Int? {
        val t = raw.trim().filter { it.isLetterOrDigit() }
        if (t.length != 2) return null
        val m = t.map { c ->
            when (c) { 'O', 'o', 'D', 'Q' -> '0'; 'I', 'l', 'i' -> '1'; 'S', 's' -> '5'; 'B' -> '8'; else -> c }
        }
        if (!m.all { it.isDigit() }) return null
        if (t.count { it.isDigit() } == 0) return null
        return String(m.toCharArray()).toInt()
    }

    /** Posición de la carta. Se conservan los números (MC0 = MCO) y se corrigen confusiones del OCR. */
    private fun chPos(raw: String): String? {
        var t = java.text.Normalizer.normalize(raw.uppercase(), java.text.Normalizer.Form.NFD)
            .filter { it in 'A'..'Z' || it in '0'..'9' }
        if (t.length < 2 || t.length > 3) return null
        t = t.map { c -> when (c) { '0' -> 'O'; '1' -> 'I'; '5' -> 'S'; '8' -> 'B'; else -> c } }
            .joinToString("")
        if (t in POS) return t
        val near = POS.filter { it.length == t.length && it.indices.count { i -> it[i] != t[i] } == 1 }
        return if (near.size == 1) near[0] else null
    }

    // ---------- registro para diagnóstico (se comparte desde la app) ----------
    private fun chLog(msg: String) {
        try {
            val f = java.io.File(filesDir, "champ_log.txt")
            if (f.exists() && f.length() > 40000) {
                val t = f.readText(); f.writeText(t.substring(t.length / 2))
            }
            val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            f.appendText("$ts $msg\n")
        } catch (e: Throwable) { }
    }

    /** Cartas visibles (OVR + posición + estado) dentro de una franja vertical de la pantalla. */
    private fun chCards(bmp: Bitmap, els: List<Text.Element>, yMin: Float, yMax: Float, bench: Boolean): List<Pc> {
        val W = bmp.width; val H = bmp.height
        val out = ArrayList<Pc>()
        for (e in els) {
            val b = e.boundingBox ?: continue
            val ov = chOvr(e.text) ?: continue
            if (ov < 40) continue
            if (b.centerY() < H * yMin || b.centerY() > H * yMax || b.centerX() > W * 0.95f) continue
            var pos: String? = null
            var bestDy = Int.MAX_VALUE
            for (p in els) {
                val pb = p.boundingBox ?: continue
                val dy = pb.centerY() - b.centerY()
                if (dy <= 0 || dy > H * 0.03f || Math.abs(pb.centerX() - b.centerX()) > W * 0.04f) continue
                val n = chPos(p.text) ?: continue
                if (dy < bestDy) { pos = n; bestDy = dy }
            }
            val ps = pos ?: continue
            val st = chStatus(bmp, b.centerX(), b.centerY())
            val tx = b.centerX() + (W * (if (bench) 0.055f else 0.06f)).toInt()
            val ty = b.centerY() + (H * (if (bench) 0.03f else 0.035f)).toInt()
            out.add(Pc(ov, ps, tx, ty, st))
        }
        return out
    }

    private var chSpacing = 0f   // separación entre cartas del banco (fracción del ancho)

    /** Cartas del banco de izquierda a derecha. Si una no se pudo leer, deja un hueco ("?") para no perder la cuenta de slots. */
    private fun chBench(bmp: Bitmap, els: List<Text.Element>, leftEnd: Boolean): List<Pc> {
        val W = bmp.width; val H = bmp.height
        val v = chCards(bmp, els, 0.70f, 0.84f, true).sortedBy { it.tx }
            .map { if (it.st == 2) it else Pc(it.ovr, it.pos, it.tx, it.ty, 0) }
        if (v.size >= 4) {
            val gaps = (1 until v.size).map { (v[it].tx - v[it - 1].tx).toFloat() / W }
            val mn = gaps.min(); val mx = gaps.max()
            if (mn > 0.08f && mx - mn < 0.2f * mn) {
                chSpacing = gaps.average().toFloat()
                prefs.edit().putFloat("ch_sp", chSpacing).apply()
            }
        }
        if (chSpacing <= 0f) chSpacing = prefs.getFloat("ch_sp", 0f)
        val sp = chSpacing
        if (sp <= 0.08f || v.isEmpty()) return v
        val out = ArrayList<Pc>()
        if (leftEnd) {
            val x0 = prefs.getFloat("ch_x0", 0f)
            if (x0 > 0f) {
                val lead = Math.round((v[0].tx.toFloat() / W - x0) / sp)
                for (i in 0 until minOf(lead, 3)) out.add(Pc(0, "?", ((x0 + sp * i) * W).toInt(), v[0].ty, 0))
            }
        }
        for (i in v.indices) {
            if (i > 0) {
                val g = (v[i].tx - v[i - 1].tx).toFloat() / W
                val n = Math.round(g / sp) - 1
                for (k in 1..minOf(n, 3)) out.add(Pc(0, "?", v[i - 1].tx + (sp * W * k).toInt(), v[i].ty, 0))
            }
            out.add(v[i])
        }
        return out
    }

    private fun chPlay(lines: List<Text.Line>, els: List<Text.Element>) {
        val t0 = now()
        val b = boxOf(lines, els) { it == "JUGAR" }
        if (b != null && t0 - chTapAt > 1500) { tapBox(b); chTapAt = t0 }
        next(800)
    }

    private fun chSwapDone() {
        chSwaps++
        chSquadAt = now()   // el tiempo de la plantilla se cuenta desde el último cambio
        chTried.add(chBenchIdx); chLastKey = chCurKey
        chLog("CAMBIO ${if (chReturning) "VUELTA" else "SALIDA"} campo=$chSlotOvr$chSlotPos slot=$chBenchIdx carta=$chWantOvr$chWantPos")
        val outs = outList()
        val tile = "${chSlotX / 30},${chSlotY / 30}"
        if (chReturning) {
            if (chRetEntry in outs.indices) { outs.removeAt(chRetEntry); saveOut(outs) }
        } else {
            setPref(chSlotOvr, chSlotPos, chBenchIdx)
            val extra = 0
            outs.add(Out(chSlotOvr, chSlotPos, chWantOvr, chWantPos, chDone + extra, chBenchIdx, chSlotFx, chSlotFy, 0, chSlotInj))
            saveOut(outs)
        }
    }

    private fun chRetFail() {
        val outs = outList()
        if (chRetEntry in outs.indices) {
            val o = outs[chRetEntry]; o.tries++
            if (o.inj) o.c = chDone                 // lesionado: se vuelve a mirar después del próximo partido
            else if (o.tries >= 6) outs.removeAt(chRetEntry)
            saveOut(outs)
        }
    }

    /** Lesionado que todavía no se recuperó: se vuelve a mirar después del próximo partido. */
    private fun chRetWait() {
        val outs = outList()
        if (chRetEntry in outs.indices) { outs[chRetEntry].c = chDone; saveOut(outs) }
    }

    /** Posiciones parecidas (aplica a quien no es exactamente la del puesto). */
    private fun similar(slot: String, cand: String): Boolean {
        val mid = setOf("MC", "MCO", "MCD", "MD", "MI", "MDI", "MDD")
        val def = setOf("DFC", "DFI", "DFD", "LI", "LD", "CAI", "CAD", "MCD")
        val att = setOf("DC", "SD", "SDI", "ED", "EI", "MD", "MI", "MP", "MVI", "MVD")
        if (slot == "POR" || cand == "POR") return false
        if (slot in mid && cand in mid) return true
        if (slot in def && cand in def) return true
        if (slot in att && cand in att) return true
        if (slot in setOf("MD", "MI", "MDI", "MDD", "MVI", "MVD") && cand in att) return true
        return false
    }

    /** Lo que ya se aprendió de brillo: 1 sí puede jugar ahí, 0 no, -1 no se sabe. Clave: puesto + carta del banco. */
    private fun glowKnown(slot: String, c: Cand): Int {
        val raw = prefs.getString("ch_glow", "") ?: ""
        val k = "$slot:${c.ovr}${c.pos}"
        for (e in raw.split(";")) { val p = e.split("="); if (p.size == 2 && p[0] == k) return p[1].toIntOrNull() ?: -1 }
        return -1
    }

    private fun glowLearn(slot: String, c: Cand, v: Boolean) {
        val k = "$slot:${c.ovr}${c.pos}"
        val l = ArrayList<String>()
        for (e in (prefs.getString("ch_glow", "") ?: "").split(";")) if (e.isNotEmpty() && !e.startsWith("$k=")) l.add(e)
        l.add("$k=${if (v) 1 else 0}")
        prefs.edit().putString("ch_glow", l.takeLast(120).joinToString(";")).apply()
    }

    /** Suma las cartas de la vista actual (ordenadas de izquierda a derecha) a la lista ordenada del banco. */
    private fun chMerge(view: List<Pc>, page: Int): Int {
        // si lo que se ve ya estaba, en el mismo orden, entre las últimas cartas anotadas, no hay nada nuevo
        if (view.isNotEmpty() && chSeen.isNotEmpty() && chSwipes > 0) {
            val tail = chSeen.takeLast(view.size + 4)
            var t2 = 0; var okAll = true
            for (c in view) {
                while (t2 < tail.size && !(tail[t2].ovr == c.ovr && tail[t2].pos == c.pos)) t2++
                if (t2 >= tail.size) { okAll = false; break }
                t2++
            }
            if (okAll) return 0
        }
        var best = 0
        for (k in minOf(view.size, chSeen.size) downTo 1) {
            var ok = true
            for (j in 0 until k) {
                val a = chSeen[chSeen.size - k + j]; val b = view[j]
                if (a.ovr != b.ovr || a.pos != b.pos) { ok = false; break }
            }
            if (ok) { best = k; break }
        }
        var added = 0
        for (j in best until view.size) { chSeen.add(Cand(view[j].ovr, view[j].pos, view[j].st, page)); added++ }
        return added
    }

    /** En qué slot del banco empieza la vista actual. Tolera cartas mal leídas: gana el desplazamiento con más coincidencias. */
    private fun chAlign(view: List<Pc>): Int {
        if (view.isEmpty() || chSeen.size < view.size) return -1
        var best = -1; var bestScore = -1
        val ref = maxOf(chViewStart, 0)
        for (k in 0..(chSeen.size - view.size)) {
            var sc = 0
            for (j in view.indices) {
                val a = chSeen[k + j]; val b = view[j]
                if (a.pos == "?" || b.pos == "?") continue
                if (a.ovr == b.ovr && a.pos == b.pos) sc++
            }
            if (sc > bestScore || (sc == bestScore && best >= 0 && Math.abs(k - ref) < Math.abs(best - ref))) { best = k; bestScore = sc }
        }
        return if (bestScore >= maxOf(2, (view.size + 1) / 2)) best else -1
    }

    /** Índice dentro de la vista actual del slot idx del banco, o -1 si no se ve. */
    private fun chFindInView(view: List<Pc>, idx: Int, loose: Boolean): Int {
        if (view.isEmpty()) return -1
        for (o in 0..(chSeen.size - view.size)) {
            if (idx < o || idx >= o + view.size) continue
            var ok = true
            for (j in view.indices) {
                if (chSeen[o + j].ovr != view[j].ovr || chSeen[o + j].pos != view[j].pos) { ok = false; break }
            }
            if (ok) return idx - o
        }
        if (loose) {
            val a = chSeen[idx]
            return view.indexOfFirst { it.ovr == a.ovr && it.pos == a.pos }
        }
        return -1
    }

    /** Cuántos píxeles blancos hay en la etiqueta de posición del puesto (brilla cuando el suplente puede jugar ahí). */
    private fun chGlowCount(bmp: Bitmap, lx: Int, ly: Int): Int {
        val W = bmp.width; val H = bmp.height
        val x0 = (lx - W * 0.05f).toInt().coerceIn(0, W - 2)
        val x1 = (lx + W * 0.05f).toInt().coerceIn(x0 + 1, W)
        val y0 = (ly - H * 0.016f).toInt().coerceIn(0, H - 2)
        val y1 = (ly + H * 0.016f).toInt().coerceIn(y0 + 1, H)
        var n = 0
        for (yy in y0 until y1) for (xx in x0 until x1) {
            val p = bmp.getPixel(xx, yy)
            if (Color.red(p) > 205 && Color.green(p) > 205 && Color.blue(p) > 205) n++
        }
        return n
    }

    /** Ordena a quién probar (por slot del banco): misma posición por OVR, después posiciones parecidas por OVR.
     *  Si empatan, gana el slot que ya se usó antes para ese jugador y, si no hay, el que está más a la derecha. */
    private fun chBuildAttempts() {
        val idxs = ArrayList<Int>()
        chRetNotFound = false
        if (chReturning) {
            // el que salió quedó en el slot del banco del que entró su reemplazante. En el campo la carta muestra la
            // posición del puesto, no la natural, así que se busca por slot y por OVR (la posición solo desempata).
            val byTok = chSeen.indices.filter { chSeen[it].ovr == chWantOvr && chSeen[it].pos == chWantPos }
            val byOvr = chSeen.indices.filter { chSeen[it].ovr == chWantOvr }
            // 1) misma carta por OVR y posición (la más cerca del slot recordado); nunca otro jugador con el mismo OVR
            idxs.addAll(byTok.sortedBy { Math.abs(it - chRetIdx) })
            if (idxs.isEmpty() && chRetIdx in chSeen.indices && chSeen[chRetIdx].pos == "?") {
                // 2) su carta no se pudo leer y ese slot quedó como hueco: se usa el slot recordado.
                //    Si el slot muestra a otro jugador (aunque tenga el mismo OVR), no se lo toca.
                idxs.add(chRetIdx)
            }
            val d = idxs.distinct(); idxs.clear(); idxs.addAll(d)
            chRetNotFound = idxs.isEmpty()
            chRetStill = false; chRetUnknown = false
            if (chRetInj) {
                // el signo de lesión se mantiene en el banco hasta que se recupera: solo vuelve si ya no lo muestra
                val real = idxs.filter { chSeen[it].pos != "?" }
                val healed = real.filter { chSeen[it].st < 2 }
                chRetStill = real.any { chSeen[it].st >= 2 }
                idxs.clear(); idxs.addAll(healed)
                if (healed.isEmpty() && !chRetStill) {
                    // no se pudo leer su carta: no se sabe si se recuperó
                    chRetUnknown = true
                    // tras varios partidos sin poder leerla, se prueba igual en ese slot
                    if (chRetTries >= 3 && chRetIdx in chSeen.indices) idxs.add(chRetIdx)
                }
            } else {
                chRetUnknown = idxs.isEmpty()
            }
            chRetNotFound = idxs.isEmpty() && !chRetStill
            chLog("VUELTA busca ${chWantOvr}${chWantPos} slot=$chRetIdx (en ese slot: " +
                (if (chRetIdx in chSeen.indices) "${chSeen[chRetIdx].ovr}${chSeen[chRetIdx].pos}" else "nada") + ") intentos=" + idxs.joinToString(","))
        } else {
            val pref = prefSlot(chSlotOvr, chSlotPos)
            val pend = outList()
            fun pending(i: Int): Boolean = pend.any { o ->
                o.ovr == chSeen[i].ovr && o.pos == chSeen[i].pos &&
                    (o.idx == i || chSeen.count { x -> x.ovr == o.ovr && x.pos == o.pos } == 1)
            }
            // el que tenga más OVR entra primero, sea de la posición exacta o parecida; a igual OVR gana la exacta
            val cmp = compareByDescending<Int> { chSeen[it].ovr }
                .thenByDescending { if (chSeen[it].pos == chSlotPos) 1 else 0 }
                .thenByDescending { if (it == pref) 1 else 0 }
                .thenByDescending { it }
            val ok = chSeen.indices.filter { chSeen[it].st < 2 && !pending(it) && it !in chTried }
            val exact = ok.filter { chSeen[it].pos == chSlotPos }
            val sim = if (chGk) emptyList() else ok.filter {
                chSeen[it].pos != chSlotPos && similar(chSlotPos, chSeen[it].pos)
            }.sortedWith(cmp).take(8)
            // lo aprendido de "no brilla" solo los deja para el final (no se descartan para siempre)
            val all = (exact + sim).sortedWith(cmp)
            idxs.addAll(all.filter { glowKnown(chSlotPos, chSeen[it]) != 0 } + all.filter { glowKnown(chSlotPos, chSeen[it]) == 0 })
        }
        chAttempts = idxs
        chLog("BANCO " + chSeen.indices.joinToString(" ") { "$it:${chSeen[it].ovr}${chSeen[it].pos}/${chSeen[it].st}" } +
            " | intentos " + idxs.joinToString(","))
    }

    private fun champSquad(bmp: Bitmap, lines: List<Text.Line>, els: List<Text.Element>) {
        val W = bmp.width; val H = bmp.height; val t0 = now()
        if (chNeedFinish) {
            if (t0 - chBackAt > 1800) { chBackAt = t0; goBack() }
            next(700); return
        }
        if (chStage != 0 && t0 - chOpAt > 60000) {
            chLog("TIMEOUT operación $chCurKey"); chFailKeys.add(chCurKey); chStage = 0; chReturning = false
        }
        val subBtn = boxOf(lines, els) { it.contains("SUBRES") }
        val benchOpen = subBtn != null && subBtn.centerY() < H * 0.72f
        when (chStage) {
            0 -> {
                if (subBtn != null && benchOpen) { tapBox(subBtn); next(800); return }
                if (chSquadAt == 0L) chSquadAt = t0
                if (chSkip || chSwaps >= 12 || t0 - chSquadAt > 150000) { chPlay(lines, els); return }
                // el OCR a veces se salta cartas: se leen varias capturas seguidas y se juntan
                for (c in chCards(bmp, els, 0.12f, 0.86f, false)) chAgg.getOrPut("${c.tx / 30},${c.ty / 30}") { ArrayList() }.add(c)
                chAggN++
                if (chAggN < 3 || (chAgg.size < 11 && chAggN < 6)) { next(450); return }
                val field = chAgg.values.map { l ->
                    val bads = l.filter { it.bad }
                    if (bads.isNotEmpty() && bads.size >= (l.size + 1) / 2) bads.maxByOrNull { it.st }!! else l.first { !it.bad }
                }
                chAgg.clear(); chAggN = 0
                if (field.isEmpty()) { next(600); return }
                // 1) devolver a los sancionados que ya cumplieron un partido (según el contador de partidos)
                val outs = outList()
                val back = outs.indices.firstOrNull { chDone > outs[it].c && "R${outs[it].ovr}${outs[it].pos}" !in chFailKeys } ?: -1
                if (back >= 0) {
                    val o = outs[back]
                    chCurKey = "R${o.ovr}${o.pos}"; chRescan = 0; chRetTries = o.tries
                    chReturning = true; chRetEntry = back; chRetIdx = o.idx
                    chWantOvr = o.ovr; chWantPos = o.pos; chRetInj = o.inj
                    chSlotOvr = o.sOvr; chSlotPos = o.sPos; chSlotOut = false
                    chSlotFx = o.fx; chSlotFy = o.fy
                    chSlotX = (o.fx * W / 1000f).toInt(); chSlotY = (o.fy * H / 1000f).toInt()
                    chGk = chSlotY > H * 0.66f
                    chOpAt = t0; chStage = if (chGk) 1 else 2
                    next(100); return
                }
                // 2) cambiar a los lesionados / expulsados / con doble amarilla
                chLog("PLANTILLA n=${field.size} " + field.joinToString(" ") { "${it.ovr}${it.pos}/${it.st}" })
                val bad = field.firstOrNull { it.bad && "${it.tx / 30},${it.ty / 30}" !in chFailKeys }
                if (bad != null) {
                    val key = "${bad.tx / 30},${bad.ty / 30}"
                    // si el mismo puesto sigue marcado tras un cambio, ese cambio no se hizo: se prueba con otro suplente
                    if (key == chLastKey) { chRepeat++ } else { chRepeat = 0; chTried.clear() }
                    if (chRepeat >= 3) { chFailKeys.add(key); chLog("DESISTE puesto $key"); next(100); return }
                    chCurKey = key
                    chSlotOvr = bad.ovr; chSlotPos = bad.pos; chSlotOut = bad.out; chSlotInj = bad.st == 2
                    chSlotX = bad.tx; chSlotY = bad.ty
                    chSlotFx = (bad.tx * 1000f / W).toInt(); chSlotFy = (bad.ty * 1000f / H).toInt()
                    chReturning = false
                    chGk = bad.ty > H * 0.66f
                    chOpAt = t0; chStage = if (chGk) 1 else 2
                    next(100); return
                }
                chBackoff.clear()   // todos sanos en el campo
                chPlay(lines, els)
            }
            1 -> {
                // el puesto queda tapado por el banco: se elige primero al jugador del campo
                tap(chSlotX.toFloat(), chSlotY.toFloat())
                chStage = 2; next(800)
            }
            2 -> {
                if (!benchOpen) { if (subBtn != null) tapBox(subBtn); next(900); return }
                // el banco puede abrir ya deslizado: primero se vuelve al principio (slot 1)
                chSeen.clear(); chPrev = ""; chSwipes = 0; chPage = 0
                chRewinding = true; chRewind = 0; chEmpty = 0; chPrevFirst = ""; chRead2 = false; chSame = 0
                chStage = 3; next(500)
            }
            3 -> {
                if (!benchOpen) { chStage = 2; next(300); return }
                var bench = chBench(bmp, els, false)
                var sig = bench.joinToString("|") { "${it.ovr}${it.pos}" }
                if (chRewinding) {
                    if (bench.isEmpty() && chEmpty < 5) { chEmpty++; next(400); return }
                    val first = bench.take(2).joinToString("|") { "${it.ovr}${it.pos}" }
                    val x0ref = prefs.getFloat("ch_x0", 0f)
                    val atLeft = chRewind == 0 && x0ref > 0f && bench.isNotEmpty() && bench[0].pos != "?" &&
                        Math.abs(bench[0].tx.toFloat() / W - x0ref) < 0.025f
                    if (atLeft || first == chPrevFirst || chRewind >= 9 || bench.isEmpty()) {
                        chRewinding = false; chPrev = ""; chPrevFirst = ""; chEmpty = 0
                        bench = chBench(bmp, els, true)
                        sig = bench.joinToString("|") { "${it.ovr}${it.pos}" }
                        if (bench.size >= 4 && bench.none { it.pos == "?" } && chSpacing > 0f)
                            prefs.edit().putFloat("ch_x0", bench[0].tx.toFloat() / W).apply()
                        // ya está al principio; se sigue con esta misma vista
                    } else {
                        chPrevFirst = first; chRewind++
                        chSwipe(W, H, true); next(1000); return
                    }
                }
                if (bench.isEmpty() && chSwipes == 0 && chSeen.isEmpty() && chEmpty < 5) { chEmpty++; next(400); return }
                // si alguna carta no se leyó, se mira una segunda vez y se completa con lo que se logre leer
                if (bench.any { it.pos == "?" } && !chRead2) {
                    chRead2 = true; chPrevView = bench; next(350); return
                }
                if (chRead2) {
                    chRead2 = false
                    val old = chPrevView
                    val filled = bench.map { c ->
                        if (c.pos != "?") c
                        else old.firstOrNull { o2 -> o2.pos != "?" && Math.abs(o2.tx - c.tx) < W * 0.03f } ?: c
                    }
                    bench = filled
                    sig = bench.joinToString("|") { "${it.ovr}${it.pos}" }
                }
                // se recorre el banco UNA vez hacia la derecha numerando los slots
                val added = chMerge(bench, chPage)
                if (chSwipes > 0 && (sig == chPrev || added == 0)) chSame++ else chSame = 0
                val atEnd = (chSwipes > 0 && sig == chPrev && !sig.contains("?")) || chSame >= 2 || chSwipes >= 16 || chSeen.size >= 30
                if (atEnd) {
                    chLog("FIN BANCO swipes=$chSwipes cartas=${chSeen.size}")
                    if (chSame > 0 && chPage >= chSame) chPage -= chSame
                    chBuildAttempts(); chAtt = 0; chMiss = 0; chNav = 0; chViewStart = -1
                    chStage = 4; next(150); return
                }
                chPrev = sig; chSwipes++; chPage++
                chSwipe(W, H, false); next(1000)
            }
            4 -> {
                if (!benchOpen) { chStage = 6; next(300); return }
                if (chAtt >= chAttempts.size) {
                    chLog("SIN CANDIDATOS $chCurKey (volviendo=$chReturning)")
                    if (chReturning && chRetUnknown && chRescan < 2) {
                        // no se pudo leer su carta: se vuelve a leer el banco antes de rendirse
                        chRescan++; chLog("RELECTURA $chRescan"); chStage = 2; next(300); return
                    }
                    if (chReturning) { if (chRetInj && chRetStill) chRetWait() else chRetFail() }
                    chFailKeys.add(chCurKey)
                    chStage = 6; next(200); return
                }
                val idx = chAttempts[chAtt]
                val a = chSeen[idx]
                val view = chBench(bmp, els, false)
                // en qué slot del banco empieza la vista actual (los cuenta por contenido, no por desplazamientos)
                val o = chAlign(view)
                var vi = -1
                if (o >= 0) {
                    chViewStart = o
                    if (idx >= o && idx < o + view.size) vi = idx - o
                    else {
                        // el slot está más a la izquierda o a la derecha de lo que se ve
                        if (++chNav > 22) { chLog("NO LLEGA al slot $idx"); chAtt++; chNav = 0; next(150); return }
                        if (idx < o) chSwipe(W, H, true) else chSwipe(W, H, false)
                        next(1000); return
                    }
                } else {
                    // no se pudo ubicar la vista: se va hacia la página donde se anotó esa carta, sin saltarla
                    chMiss++
                    if (chMiss >= 3) vi = chFindInView(view, idx, true)
                    if (vi < 0) {
                        if (chMiss >= 14) { chLog("NO UBICA slot $idx"); chAtt++; chMiss = 0; chNav = 0 }
                        else if (chPage != a.page && chMiss % 2 == 1) {
                            if (chPage > a.page) { chSwipe(W, H, true); chPage-- } else { chSwipe(W, H, false); chPage++ }
                            next(1000); return
                        }
                        next(400); return
                    }
                }
                val hit = view[vi]
                chMiss = 0; chNav = 0
                chBenchX = hit.tx; chBenchY = hit.ty
                chBenchIdx = idx
                chExact = chReturning || a.pos == chSlotPos || glowKnown(chSlotPos, a) == 1
                chGlowBase = chGlowCount(bmp, chSlotX, chSlotY + (H * 0.055f).toInt())
                if (chGk) {
                    // ya estaba elegido el jugador del campo: al tocar al suplente se intercambian
                    tap(hit.tx.toFloat(), hit.ty.toFloat())
                    chWantOvr = a.ovr; chWantPos = a.pos
                    chVerTries = 0; chStage = 7; next(1000); return
                }
                tap(hit.tx.toFloat(), hit.ty.toFloat())
                chWantOvr = a.ovr; chWantPos = a.pos
                chStage = 5; next(700)
            }
            5 -> {
                // suplente elegido: si la posición del puesto brilla (o es la misma), se toca al del campo
                if (!benchOpen) { chStage = 6; next(300); return }
                val glow = chGlowCount(bmp, chSlotX, chSlotY + (H * 0.055f).toInt()) - chGlowBase >= 60
                chLog("BRILLO diff=${chGlowCount(bmp, chSlotX, chSlotY + (H * 0.055f).toInt()) - chGlowBase} exacto=$chExact")
                if (!chExact && chAtt < chAttempts.size) glowLearn(chSlotPos, chSeen[chAttempts[chAtt]], glow)
                if (chExact || glow) {
                    tap(chSlotX.toFloat(), chSlotY.toFloat())
                    chVerTries = 0; chStage = 7; next(1000); return
                }
                // no brilla: no puede jugar ahí. Se suelta y se prueba el siguiente
                tap(chBenchX.toFloat(), chBenchY.toFloat())
                chAtt++; chMiss = 0; chStage = 4; next(600)
            }
            7 -> {
                // verificar que el cambio se hizo: la carta tocada del banco ya no debe ser la misma
                if (!benchOpen) { chSwapDone(); chStage = 6; next(300); return }
                val view = chBench(bmp, els, false)
                val near = view.filter { it.pos != "?" }.minByOrNull { Math.abs(it.tx - chBenchX) }
                val same = near != null && Math.abs(near.tx - chBenchX) < W * 0.04f &&
                    near.ovr == chWantOvr && near.pos == chWantPos
                if (!same) { chSwapDone(); chStage = 6; next(300); return }
                chLog("CAMBIO NO HECHO ($chVerTries) campo=$chSlotOvr$chSlotPos carta=$chWantOvr$chWantPos")
                if (chVerTries < 2) {
                    chVerTries++
                    if (chGk) tap(chBenchX.toFloat(), chBenchY.toFloat()) else tap(chSlotX.toFloat(), chSlotY.toFloat())
                    next(1000); return
                }
                chFailKeys.add(chCurKey); chStage = 6; next(300)
            }
            else -> {
                // 6: cerrar el banco y volver a revisar la plantilla
                if (subBtn != null && benchOpen) { tapBox(subBtn); next(900); return }
                chStage = 0; chSquadAt = t0; chReturning = false
                next(500)
            }
        }
    }

    private fun analyzeChamp(bmp: Bitmap, t: Text) {
        if (!running) return
        val lines = t.textBlocks.flatMap { it.lines }
        val els = lines.flatMap { it.elements }
        val norms = ArrayList<String>()
        for (l in lines) norms.add(Search.norm(l.text))
        for (e in els) norms.add(Search.norm(e.text))
        fun has(k: String): Boolean = norms.any { it.contains(k) }
        val W = bmp.width; val H = bmp.height
        val t0 = now()

        val onDialog = has("PARTIDAONLINE")
        val onMatch = has("EVENTOS") && (has("CAMPO") || has("PARTIDO"))
        val onSquad = has("CALIFICACION") && has("QUIMICA")
        val onConfirm = has("CANCELAR") && has("ACABAR")
        val onMain = has("TIENDA") && has("ACABAR") && !has("CANCELAR")
        val onDone = has("CHAMPIONESTERMINADA") || has("MISPACKS")
        val onOnline = has("PENALES") && has("CLANES")
        if (!onSquad) { chAgg.clear(); chAggN = 0 }
        if (!onSquad && chStage != 0) { chStage = 0; chReturning = false }

        if (onDialog) {
            chKnownAt = t0; chFinished = false; chRedSince = 0L; chSquadAt = 0L
            if (t0 - chTapAt > 1500) {
                val b = boxOf(lines, els) { it.contains("PARTIDAONLINE") }
                if (b != null) { tapBox(b); chTapAt = t0 }
            }
            next(700); return
        }

        if (onMatch) {
            chKnownAt = t0; chRedSince = 0L; chSquadAt = 0L
            if (chFinished) {
                if (t0 - chBackAt > 3000) { chBackAt = t0; goBack() }
                next(700); return
            }
            if (!chInMatch) {
                chInMatch = true; chScoreL = -1; chScoreR = -1; chStartSynced = false; chMinute = -1; chMinuteAt = t0; chEventosAt = 0L; chMatchNo = 0
                chSwaps = 0; chSkip = false; chFailKeys.clear(); chTried.clear(); chLastKey = ""; chRepeat = 0
            }
            for (l in lines) {
                if (!Search.norm(l.text).contains("PARTIDO")) continue
                val m = Regex("(\\d+)\\s*/\\s*(\\d+)").find(l.text) ?: continue
                val a1 = m.groupValues[1].toIntOrNull() ?: 0
                val b1 = m.groupValues[2].toIntOrNull() ?: 15
                if (a1 in 1..b1 && b1 in 5..30) { chMatchNo = a1; chMatchTotal = b1 }
                break
            }
            if (chMatchNo == 0) {
                // el contador a veces se lee suelto ("1/15") arriba y al centro
                val cEl = els.firstOrNull { e ->
                    val bb = e.boundingBox
                    bb != null && bb.centerY() < H * 0.12f && bb.centerX() > W * 0.25f && bb.centerX() < W * 0.75f &&
                        Regex("^\\d{1,2}\\s*/\\s*\\d{1,2}$").matches(e.text.trim())
                }
                val m2 = cEl?.let { Regex("(\\d+)\\s*/\\s*(\\d+)").find(it.text) }
                if (m2 != null) {
                    val a1 = m2.groupValues[1].toIntOrNull() ?: 0
                    val b1 = m2.groupValues[2].toIntOrNull() ?: 15
                    if (a1 in 1..b1 && b1 in 5..30) { chMatchNo = a1; chMatchTotal = b1 }
                }
            }
            if (!chStartSynced && chMatchNo > 0) { chDone = chMatchNo - 1; chStartSynced = true }
            val sc = chReadScore(lines, els, W, H)
            if (sc != null) { chScoreL = sc[0]; chScoreR = sc[1] }
            val re = Regex("^\\d{1,3}['’′`´]?$")
            val mEl = els.firstOrNull { e ->
                val b = e.boundingBox
                b != null && b.centerY() > H * 0.14f && b.centerY() < H * 0.20f &&
                    b.centerX() > W * 0.35f && b.centerX() < W * 0.65f && re.matches(e.text.trim())
            }
            val mn = mEl?.text?.filter { it.isDigit() }?.toIntOrNull()
            if (mn != null && mn != chMinute) { chMinute = mn; chMinuteAt = t0 }
            if (chMinute < 90 && t0 - chEventosAt > 8000) {
                val b = boxOf(lines, els) { it == "EVENTOS" }
                if (b != null) { tapBox(b); chEventosAt = t0 }
            }
            if (chMinute >= 90 && t0 - chMinuteAt > 2500) {
                // el minuto quedó quieto en 90 o 120: el partido terminó
                chFinished = true; chBackAt = t0; chInMatch = false
                chRun++; cnt[mi()]++
                // izquierda mayor = ganó; derecha mayor = perdió; empate no suma
                if (chScoreL >= 0 && chScoreR >= 0) {
                    if (chScoreL > chScoreR) wins++ else if (chScoreR > chScoreL) losses++
                }
                updateInfo()
                // partidos terminados: se toma del contador "Partido x/y"; los sancionados vuelven al siguiente squad
                chDone = if (chMatchNo > 0) chMatchNo else chDone + 1
                if (chMatchNo > 0) { if (chMatchNo >= chMatchTotal) chNeedFinish = true }
                else if (chRun >= 15) chNeedFinish = true
                goBack(); next(1200); return
            }
            next(600); return
        }

        if (onConfirm) {
            chKnownAt = t0; chRedSince = 0L
            if (t0 - chTapAt > 1500) {
                val key = if (chNeedFinish) "ACABAR" else "CANCELAR"
                val b = lines.filter { it.boundingBox != null && Search.norm(it.text).contains(key) }
                    .maxByOrNull { it.boundingBox!!.centerY() }?.boundingBox
                if (b != null) {
                    tapBox(b); chTapAt = t0
                    if (chNeedFinish) { chNeedFinish = false; chRun = 0; chMatchNo = 0; chDone = 0; saveOut(emptyList()) }
                }
            }
            next(900); return
        }

        if (onDone) {
            chKnownAt = t0; chRedSince = 0L
            if (t0 - chTapAt > 2500) {
                chDoneTaps++
                // flecha de arriba a la izquierda; si no responde, "Atrás" del sistema
                if (chDoneTaps % 2 == 1) tap(W * 0.072f, H * 0.072f) else goBack()
                chTapAt = t0
            }
            next(800); return
        }

        if (onOnline) {
            chKnownAt = t0; chRedSince = 0L
            if (t0 - chTapAt > 1800) {
                val b = boxOf(lines, els) { it == "CHAMPIONS" }
                if (b != null) { tapBox(b); chTapAt = t0 }
            }
            next(800); return
        }

        if (onMain) {
            chKnownAt = t0; chFinished = false; chRedSince = 0L; chSquadAt = 0L
            if (t0 - chTapAt > 1800) {
                val key = if (chNeedFinish) "ACABAR" else "JUGAR"
                val b = boxOf(lines, els) { it == key }
                if (b != null) { tapBox(b); chTapAt = t0 }
            }
            next(800); return
        }

        if (onSquad) {
            chKnownAt = t0; chFinished = false; chRedSince = 0L
            champSquad(bmp, lines, els)
            return
        }

        // Pantalla desconocida: pantalla roja de carga, avisos o cargando
        if (isRedScreen(bmp)) {
            if (chRedSince == 0L) chRedSince = t0
            if (t0 - chRedSince > 10000) {
                // más de 10 s en la pantalla roja: volver atrás y repetir JUGAR > PARTIDA ONLINE
                chRedSince = 0L; chKnownAt = t0; chInMatch = false; chFinished = false
                goBack(); next(2500); return
            }
        } else chRedSince = 0L
        val pop = boxOf(lines, els) { it == "ACEPTAR" || it == "CONTINUAR" || it == "CONFIRMAR" || it == "OK" }
        if (pop != null && t0 - chTapAt > 1500) { tapBox(pop); chTapAt = t0; next(900); return }
        if (t0 - chKnownAt > 45000) { chKnownAt = t0; goBack(); next(2000); return }
        next(500)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    // Android lo llama en cambios de pantalla/foco en algunos equipos: antes frenaba el auto-pick solo.
    override fun onInterrupt() { }

    override fun onDestroy() {
        stop()
        stopFg()
        instance = null
        recognizer.close()
        super.onDestroy()
    }
}
