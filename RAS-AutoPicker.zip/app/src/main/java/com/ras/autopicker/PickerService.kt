package com.ras.autopicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.random.Random

class PickerService : AccessibilityService() {

    companion object { var instance: PickerService? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val EMERALD = Color.parseColor("#2ECC71")
    private val RED = Color.parseColor("#E53935")

    // Posiciones por defecto (fracción de pantalla), medidas en tus capturas
    private val defaults = arrayOf(
        floatArrayOf(0.274f, 0.26f),  // carta 1
        floatArrayOf(0.725f, 0.26f),  // carta 2
        floatArrayOf(0.500f, 0.60f),  // carta 3
        floatArrayOf(0.739f, 0.752f)  // NEXT PACK
    )

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val pointers = ArrayList<TextView>()
    private val pParams = ArrayList<WindowManager.LayoutParams>()
    private lateinit var playBtn: TextView
    private lateinit var info: TextView

    var running = false
        private set
    var packs = 0
        private set
    private var lastCardTap = 0L
    private var sizePx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs by lazy { getSharedPreferences("ras", MODE_PRIVATE) }

    private fun overlayParams(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun ring(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.TRANSPARENT)
        setStroke(dp(3), color)
    }

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = wm.currentWindowMetrics.bounds.height()

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sizePx = dp(40)
        val labels = arrayOf("1", "2", "3", "N")
        for (i in 0..3) {
            val p = overlayParams(sizePx, sizePx, 0, 0)
            val v = TextView(this).apply {
                text = labels[i]; textSize = 11f; gravity = Gravity.CENTER
                setTextColor(IVORY)
                background = ring(if (i == 3) EMERALD else GOLD)
            }
            makeDraggable(v, p) { savePos(i) }
            pointers.add(v); pParams.add(p)
            wm.addView(v, p)
        }
        loadPositions()
        buildPanel()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(v: View, p: WindowManager.LayoutParams, onDrop: () -> Unit) {
        var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = p.x - e.rawX; dy = p.y - e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (e.rawX + dx).toInt(); p.y = (e.rawY + dy).toInt(); moved = true
                    wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> if (moved) onDrop() else v.performClick()
            }
            true
        }
    }

    private fun buildPanel() {
        val p = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(8), dp(90))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6000000")); cornerRadius = dp(28).toFloat(); setStroke(dp(2), GOLD)
            }
        }
        playBtn = TextView(this).apply {
            text = "▶"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(IVORY)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(EMERALD) }
            setOnClickListener { if (running) stop() else start() }
        }
        panel.addView(playBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        eyeBtn = TextView(this).apply {
            text = "👁"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(IVORY)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(2), GOLD) }
            setOnClickListener { togglePointers() }
        }
        panel.addView(eyeBtn, LinearLayout.LayoutParams(dp(38), dp(38)).apply { leftMargin = dp(6) })
        val offBtn = TextView(this).apply {
            text = "⏻"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(IVORY)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(2), RED) }
            setOnClickListener { shutdown() }
        }
        panel.addView(offBtn, LinearLayout.LayoutParams(dp(38), dp(38)).apply { leftMargin = dp(6) })
        info = TextView(this).apply {
            textSize = 11f; setTextColor(IVORY); setPadding(dp(8), 0, 0, 0)
            text = "RAS · detenido"
        }
        panel.addView(info)
        makeDraggable(panel, p) {}
        wm.addView(panel, p)
    }

    private lateinit var eyeBtn: TextView
    private var pointersHidden = false

    /** Oculta/muestra los punteros; siguen funcionando igual (solo se vuelven invisibles). */
    fun togglePointers() {
        pointersHidden = !pointersHidden
        for (v in pointers) v.visibility = if (pointersHidden) View.INVISIBLE else View.VISIBLE
        eyeBtn.alpha = if (pointersHidden) 0.45f else 1f
    }

    /** Detiene el auto-pick, quita todo de la pantalla y desactiva el servicio. */
    fun shutdown() {
        stop()
        disableSelf()
    }

    // ---------- posiciones ----------
    private fun center(i: Int): IntArray {
        val loc = IntArray(2); pointers[i].getLocationOnScreen(loc)
        return intArrayOf(loc[0] + sizePx / 2, loc[1] + sizePx / 2)
    }

    private fun savePos(i: Int) {
        val c = center(i)
        prefs.edit().putFloat("x$i", c[0].toFloat() / screenW()).putFloat("y$i", c[1].toFloat() / screenH()).apply()
    }

    private fun loadPositions() {
        for (i in 0..3) {
            val fx = prefs.getFloat("x$i", defaults[i][0])
            val fy = prefs.getFloat("y$i", defaults[i][1])
            pParams[i].x = (fx * screenW()).toInt() - sizePx / 2
            pParams[i].y = (fy * screenH()).toInt() - sizePx / 2
            wm.updateViewLayout(pointers[i], pParams[i])
        }
    }

    fun resetPositions() {
        prefs.edit().clear().apply()
        loadPositions()
    }

    private fun setPointersTouchable(t: Boolean) {
        val base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        for (i in 0..3) {
            pParams[i].flags = if (t) base else base or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(pointers[i], pParams[i])
        }
    }

    // ---------- ciclo ----------
    private fun start() {
        running = true
        lastCardTap = 0L
        setPointersTouchable(false)
        playBtn.text = "■"
        (playBtn.background as GradientDrawable).setColor(RED)
        info.text = "RAS · en marcha"
        handler.post { step() }
    }

    private fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (pointers.isNotEmpty()) setPointersTouchable(true)
        if (::playBtn.isInitialized) {
            playBtn.text = "▶"
            (playBtn.background as GradientDrawable).setColor(EMERALD)
            info.text = "RAS · detenido · packs: $packs"
        }
    }

    private fun next(ms: Long) { if (running) handler.postDelayed({ step() }, ms) }

    private fun step() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hw?.recycle(); r.hardwareBuffer.close()
                if (bmp == null) { next(350); return }
                recognizer.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener { t -> analyze(bmp, t) }
                    .addOnFailureListener { next(400) }
            }
            override fun onFailure(errorCode: Int) { next(350) }
        })
    }

    private fun norm(s: String) = s.uppercase().replace(" ", "").trim()

    private fun analyze(bmp: Bitmap, t: Text) {
        if (!running) return
        val lines = t.textBlocks.flatMap { it.lines }
        val elements = lines.flatMap { it.elements }

        // 1) Bonus: tocar OK donde esté (izquierda o derecha)
        if (lines.any { norm(it.text) == "BONUS" }) {
            val ok = lines.firstOrNull { norm(it.text) == "OK" }?.boundingBox
                ?: elements.firstOrNull { norm(it.text) == "OK" }?.boundingBox
            if (ok != null) {
                tap(ok.exactCenterX(), ok.exactCenterY())
                info.text = "RAS · bonus cerrado"
                next(900); return
            }
        }

        // 2) NEXT PACK
        val np = lines.firstOrNull { norm(it.text).contains("NEXTPACK") }?.boundingBox
        if (np != null) {
            tap(np.exactCenterX(), np.exactCenterY())
            packs++
            info.text = "RAS · packs: $packs"
            lastCardTap = 0L
            next(900); return
        }

        // 3) Leer las 3 cartas
        val cards = (0..2).map { readCard(it, bmp, elements) }
        if (cards.all { it.first != null }) {
            val chosen = choose(cards)
            val c = center(chosen)
            flash(chosen)
            tap(c[0].toFloat(), c[1].toFloat())
            val c0 = cards[chosen]
            info.text = "RAS · carta ${chosen + 1} (${c0.first}${if (c0.second) " NEW" else ""}) · packs: $packs"
            lastCardTap = SystemClock.uptimeMillis()
            next(800); return
        }

        // 4) Respaldo: si tocamos carta y el texto NEXT PACK no se lee, usar puntero N
        if (lastCardTap != 0L && SystemClock.uptimeMillis() - lastCardTap > 2500) {
            val c = center(3)
            tap(c[0].toFloat(), c[1].toFloat())
            packs++
            lastCardTap = 0L
            info.text = "RAS · NEXT PACK (puntero N) · packs: $packs"
            next(900); return
        }
        next(300)
    }

    /** Devuelve (OVR, tieneNew) */
    private fun readCard(i: Int, bmp: Bitmap, elements: List<Text.Element>): Pair<Int?, Boolean> {
        val c = center(i)
        val bw = (bmp.width * 0.28f).toInt()
        val bh = (bmp.height * 0.17f).toInt()
        val left = c[0] - bw / 2; val top = c[1] - bh / 2
        val ovrZone = Rect(left, top, left + bw * 50 / 100, top + bh * 42 / 100)
        val newZone = Rect(left + bw * 58 / 100, top, left + bw, top + bh * 38 / 100)

        val ovr = elements.filter { e ->
            val b = e.boundingBox
            b != null && e.text.trim().matches(Regex("\\d{2}")) && ovrZone.contains(b.centerX(), b.centerY())
        }.minByOrNull { it.boundingBox!!.top }?.text?.trim()?.toInt()

        val newText = elements.any { e ->
            val b = e.boundingBox
            b != null && norm(e.text) == "NEW" && newZone.contains(b.centerX(), b.centerY())
        }
        return Pair(ovr, newText || redPixels(bmp, newZone) >= 60)
    }

    private fun redPixels(bmp: Bitmap, z: Rect): Int {
        val r0 = Rect(z); if (!r0.intersect(0, 0, bmp.width, bmp.height)) return 0
        var n = 0
        var y = r0.top
        while (y < r0.bottom) {
            var x = r0.left
            while (x < r0.right) {
                val p = bmp.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (r > 170 && g < 120 && b < 110 && r - g > 80) n++
                x += 2
            }
            y += 2
        }
        return n
    }

    private fun choose(cards: List<Pair<Int?, Boolean>>): Int {
        val idx = (0..2).toList()
        val news = idx.filter { cards[it].second }
        val pool = if (news.isNotEmpty()) news else idx
        val best = pool.maxOf { cards[it].first!! }
        val tied = pool.filter { cards[it].first == best }
        return tied[Random.nextInt(tied.size)]
    }

    private fun flash(i: Int) {
        val v = pointers[i]
        v.background = ring(EMERALD)
        handler.postDelayed({ v.background = ring(GOLD) }, 400)
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }

    override fun onDestroy() {
        stop()
        instance = null
        recognizer.close()
        super.onDestroy()
    }
}
