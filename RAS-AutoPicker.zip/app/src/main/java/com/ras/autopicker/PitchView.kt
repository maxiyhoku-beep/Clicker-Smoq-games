package com.ras.autopicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

/** Cancha con los puestos de la formación. Toca un puesto para cargar al jugador. */
class PitchView(
    ctx: Context,
    private val slots: List<Formations.Slot>,
    private val info: (Int) -> Pair<String, String>?,
    private val onTap: (Int) -> Unit
) : View(ctx) {
    private val gold = Color.parseColor("#D4AF37")
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dens = ctx.resources.displayMetrics.density

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        setMeasuredDimension(width, (width * 1.18f).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        // césped con franjas
        val clip = RectF(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#2C7A33"); c.drawRoundRect(clip, 18 * dens, 18 * dens, p)
        p.color = Color.parseColor("#27702E")
        val bands = 10
        for (i in 0 until bands step 2) c.drawRect(0f, h * i / bands, w, h * (i + 1) / bands, p)
        // líneas
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * dens; p.color = Color.argb(190, 255, 255, 255)
        val m = 8 * dens
        c.drawRect(m, m, w - m, h - m, p)
        c.drawLine(m, h / 2, w - m, h / 2, p)
        c.drawCircle(w / 2, h / 2, w * 0.14f, p)
        c.drawRect(w * 0.24f, m, w * 0.76f, h * 0.15f, p)
        c.drawRect(w * 0.24f, h * 0.85f, w * 0.76f, h - m, p)
        c.drawRect(w * 0.38f, m, w * 0.62f, h * 0.06f, p)
        c.drawRect(w * 0.38f, h * 0.94f, w * 0.62f, h - m, p)
        // puestos
        val r = w * 0.068f
        for ((i, s) in slots.withIndex()) {
            val cx = s.x * w; val cy = s.y * h
            val d = info(i)
            p.style = Paint.Style.FILL
            p.color = if (d != null) gold else Color.parseColor("#E6101010")
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2 * dens
            p.color = if (d != null) Color.parseColor("#FFF3C4") else gold
            c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            if (d != null) {
                p.color = Color.parseColor("#1A1405"); p.textSize = r * 0.85f
                c.drawText(d.first.ifBlank { s.label }, cx, cy + r * 0.12f, p)
                p.textSize = r * 0.42f; p.color = Color.parseColor("#1A1405")
                c.drawText(s.label, cx, cy + r * 0.62f, p)
                p.color = Color.WHITE; p.textSize = r * 0.55f
                val nm = if (d.second.length > 9) d.second.take(9) + "." else d.second
                c.drawText(nm, cx, cy + r * 1.55f, p)
            } else {
                p.color = gold; p.textSize = r * 0.6f
                c.drawText(s.label, cx, cy + r * 0.22f, p)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) return true
        if (e.action == MotionEvent.ACTION_UP) {
            val w = width.toFloat(); val h = height.toFloat()
            var best = -1; var bd = Float.MAX_VALUE
            for ((i, s) in slots.withIndex()) {
                val dx = e.x - s.x * w; val dy = e.y - s.y * h
                val d = dx * dx + dy * dy
                if (d < bd) { bd = d; best = i }
            }
            if (best >= 0 && bd < (w * 0.1f) * (w * 0.1f)) { performClick(); onTap(best) }
            return true
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean { return super.performClick() }
}
