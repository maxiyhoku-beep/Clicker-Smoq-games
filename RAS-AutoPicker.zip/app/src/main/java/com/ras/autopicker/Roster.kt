package com.ras.autopicker

import com.google.mlkit.vision.text.Text
import java.text.Normalizer

/** Lee los datos de una captura de la pantalla de detalle de una carta: OVR, posición, apellido y posiciones extra. */
object Roster {
    class Parsed(val ovr: String, val pos: String, val extras: List<String>, val name: String)

    val POS = setOf(
        "POR", "DFC", "DFI", "DFD", "LI", "LD", "CAI", "CAD", "MCD", "MC", "MCO",
        "MI", "MD", "MDI", "MDD", "MVI", "MVD", "MP", "EI", "ED", "DC", "SD", "SDI"
    )
    private val STAT = setOf("RIT", "TIR", "PAS", "REG", "DEF", "FIS", "PAC", "SHO", "DRI", "PHY", "DIV", "HAN", "KIC", "REF", "SPE")

    fun posOf(raw: String): String? {
        var t = Normalizer.normalize(raw.uppercase(), Normalizer.Form.NFD).filter { it in 'A'..'Z' || it in '0'..'9' }
        if (t.length < 2 || t.length > 3) return null
        t = t.map { c -> when (c) { '0' -> 'O'; '1' -> 'I'; '5' -> 'S'; '8' -> 'B'; else -> c } }.joinToString("")
        if (t in POS) return t
        val near = POS.filter { it.length == t.length && it.indices.count { i -> it[i] != t[i] } == 1 }
        return if (near.size == 1) near[0] else null
    }

    private fun norm(s: String) = Normalizer.normalize(s.uppercase(), Normalizer.Form.NFD).filter { it in 'A'..'Z' }

    fun parse(t: Text, W: Int, H: Int): Parsed {
        val lines = t.textBlocks.flatMap { it.lines }
        val els = lines.flatMap { it.elements }
        val st = els.filter { norm(it.text) in STAT && it.boundingBox != null }
        val haveStat = st.size >= 3
        val statY = if (haveStat) st.map { it.boundingBox!!.centerY() }.average().toFloat() else H * 0.76f
        val statMin = if (haveStat) st.minOf { it.boundingBox!!.left }.toFloat() else 0f
        val statMax = if (haveStat) st.maxOf { it.boundingBox!!.right }.toFloat() else W.toFloat()
        val rowW = statMax - statMin
        // OVR: el número de 2 dígitos más grande, arriba a la izquierda
        val ovrEl = els.filter { e ->
            val b = e.boundingBox ?: return@filter false
            val s = e.text.trim()
            s.length == 2 && s.all { it.isDigit() } && s.toInt() >= 40 &&
                b.centerY() < statY - 0.1f * (statY) && b.centerX() < statMin + 0.55f * rowW
        }.maxByOrNull { it.boundingBox!!.height() }
        val ob = ovrEl?.boundingBox
        val ovr = ovrEl?.text?.trim() ?: ""
        var pos = ""
        if (ob != null) {
            var bd = Int.MAX_VALUE
            for (e in els) {
                val b = e.boundingBox ?: continue
                val dy = b.centerY() - ob.centerY()
                if (dy <= 0 || dy > ob.height() * 2.6f || Math.abs(b.centerX() - ob.centerX()) > ob.width() * 1.2f) continue
                val p = posOf(e.text) ?: continue
                if (dy < bd) { bd = dy; pos = p }
            }
        }
        val gap = if (ob != null) statY - ob.centerY() else H * 0.5f
        val extras = ArrayList<String>()
        if (ob != null) {
            for (e in els) {
                val b = e.boundingBox ?: continue
                if (b.centerX() < statMin + 0.75f * rowW) continue
                if (b.centerY() < ob.centerY() - 0.7f * gap || b.centerY() > ob.centerY() + 0.4f * gap) continue
                val p = posOf(e.text) ?: continue
                if (p != pos && p !in extras) extras.add(p)
            }
        }
        // apellido: el texto más alto entre el retrato y la fila de estadísticas
        var name = ""
        if (ob != null) {
            val cand = lines.filter { l ->
                val b = l.boundingBox ?: return@filter false
                val s = norm(l.text)
                s.length >= 3 && s !in STAT && b.centerY() > ob.centerY() + 0.4f * gap && b.centerY() < statY - 0.03f * gap
            }.maxByOrNull { it.boundingBox!!.height() }
            name = cand?.text?.trim() ?: ""
        }
        return Parsed(ovr, pos, extras, name)
    }
}
