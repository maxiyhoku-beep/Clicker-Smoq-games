package com.ras.autopicker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.mlkit.vision.text.Text
import java.text.Normalizer

object Search {
    private const val CH = "ras_search"

    class Target(val slot: Int, val name: String, val ovr: Int?, var found: Boolean)

    fun createChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "RAS Auto-Picker", NotificationManager.IMPORTANCE_HIGH))
    }

    fun notify(c: Context, id: Int, title: String, text: String) {
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.star_big_on)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { c.getSystemService(NotificationManager::class.java).notify(id, n) } catch (e: SecurityException) { }
    }

    fun load(c: Context): List<Target> {
        val p = c.getSharedPreferences("ras", Context.MODE_PRIVATE)
        val out = ArrayList<Target>()
        for (i in 0..2) {
            val name = p.getString("t${i}_name", "") ?: ""
            if (norm(name).length < 3) continue
            out.add(Target(i, name, p.getString("t${i}_ovr", "")?.toIntOrNull(), p.getBoolean("t${i}_found", false)))
        }
        return out
    }

    fun setFound(c: Context, slot: Int) {
        c.getSharedPreferences("ras", Context.MODE_PRIVATE).edit().putBoolean("t${slot}_found", true).apply()
    }

    fun norm(s: String): String {
        val n = Normalizer.normalize(s.uppercase(), Normalizer.Form.NFD)
        return n.filter { it in 'A'..'Z' }
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    fun nameMatches(target: String, candidate: String): Boolean {
        val t = norm(target); val c = norm(candidate)
        if (t.length < 3 || c.length < 3) return false
        if (c == t || c.contains(t)) return true
        if (c.length >= 4 && t.contains(c)) return true
        return t.length >= 5 && lev(t, c) <= 1
    }

    private val skip = setOf("PAC", "SHO", "PAS", "DRI", "DEF", "PHY", "RIT", "TIR", "REG", "FIS",
        "NEW", "NUEVO", "BONUS", "BONO", "SELL", "VENDER", "OK", "NEXTPACK", "MYCARDS")

    /** Lee nombre (texto más grande sin números) y OVR (número de 2 cifras más grande) de una captura. */
    fun extract(text: Text): Pair<String, Int?> {
        var best: Text.Line? = null
        for (b in text.textBlocks) for (l in b.lines) {
            val raw = l.text.trim()
            if (raw.any { it.isDigit() }) continue
            val letters = norm(raw)
            if (letters.length < 3 || letters in skip) continue
            if (letters.length <= 3 && raw == raw.uppercase()) continue
            val h = l.boundingBox?.height() ?: 0
            if (best == null || h > (best.boundingBox?.height() ?: 0)) best = l
        }
        var ovr: Int? = null; var oh = 0
        for (b in text.textBlocks) for (l in b.lines) for (e in l.elements) {
            val s = e.text.trim()
            if (s.length == 2 && s.all { it.isDigit() }) {
                val h = e.boundingBox?.height() ?: 0
                if (h > oh) { oh = h; ovr = s.toInt() }
            }
        }
        return Pair(best?.text?.trim() ?: "", ovr)
    }
}
